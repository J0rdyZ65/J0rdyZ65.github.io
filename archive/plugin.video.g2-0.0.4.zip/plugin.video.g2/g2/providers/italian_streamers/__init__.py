# -*- coding: utf-8 -*-

kind = 'providers'
