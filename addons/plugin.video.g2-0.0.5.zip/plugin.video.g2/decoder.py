# -*- coding: utf-8 -*-

'''
AES, CBC classes: Copyright (c) 2010 Marti Raudsepp <marti@juffo.org>
CBCImporter class: Copyright (C) 2016-2017 J0rdyZ65
'''


import os
import uu
import ast
import imp
import sys
import time
import array
import base64
import hashlib
import inspect
import zipfile
import StringIO

import xbmc
import xbmcgui
import xbmcaddon


def _anti_tampering_check():
    addon = xbmcaddon.Addon()
    lastcheck_prop = addon.getAddonInfo('id') + '.secfiles.intchktime'
    lastcheck_time = xbmcgui.Window(10000).getProperty(lastcheck_prop)
    try:
        mimp = None
        # Do not run the anti tampering check more than once every 5 minutes
        if lastcheck_time and ast.literal_eval(lastcheck_time) > time.time() - 300:
            return

        if _HASHES:
            hashes_list = _HASHES
        else:
            # Retrieve the hashes prop name from the _PkgSrcDecImporter importer
            for mimp in sys.meta_path:
                if hasattr(mimp, 'path') and hasattr(mimp, 'hashes'):
                    break
            else:
                raise Exception('_PkgSrcDecImporter')

            # Retrieve the hashes from the prop
            hashes_list = ast.literal_eval(xbmcgui.Window(10000).getProperty(mimp.hashes)).split('\n') #pylint: disable=E1103

        if not hashes_list:
            raise Exception('hashes')

        # Check if the file sha256 hashes still match
        addonpath = addon.getAddonInfo('path').decode('utf-8')
        for line in hashes_list:
            if '  ' in line:
                sha, filename = line.split('  ')
                filename = os.path.join(addonpath, filename)
                if os.path.exists(filename) and sha != hashlib.sha256(open(filename).read()).hexdigest():
                    raise Exception(filename)

        xbmc.log('intchkok', xbmc.LOGNOTICE)
        xbmcgui.Window(10000).setProperty(lastcheck_prop, repr(time.time()))
    except Exception as ex:
        # Avoid the following xbmc.log to be filtered by the buildrepo.sh script
        getattr(xbmc, 'log')('intchkfail: ' + repr(ex), xbmc.LOGERROR)
        # Clear the decoder module source prop so that a fresh download is triggered
        if mimp:
            xbmcgui.Window(10000).clearProperty(getattr(mimp, 'path', ''))
        # Force a decode module reload next time is imported
        if 'decoder' in sys.modules:
            del sys.modules['decoder']
        # Propagate the error upstream to eventually invalidate the source
        raise ex


_HASHES = [
]


pass


# The S-box is a 256-element array, that maps a single byte value to another
# byte value. Since it's designed to be reversible, each value occurs only once
# in the S-box
#
# More information: http://en.wikipedia.org/wiki/Rijndael_S-box

_AES_SBOX = array.array(
    'B',
    '637c777bf26b6fc53001672bfed7ab76'
    'ca82c97dfa5947f0add4a2af9ca472c0'
    'b7fd9326363ff7cc34a5e5f171d83115'
    '04c723c31896059a071280e2eb27b275'
    '09832c1a1b6e5aa0523bd6b329e32f84'
    '53d100ed20fcb15b6acbbe394a4c58cf'
    'd0efaafb434d338545f9027f503c9fa8'
    '51a3408f929d38f5bcb6da2110fff3d2'
    'cd0c13ec5f974417c4a77e3d645d1973'
    '60814fdc222a908846eeb814de5e0bdb'
    'e0323a0a4906245cc2d3ac629195e479'
    'e7c8376d8dd54ea96c56f4ea657aae08'
    'ba78252e1ca6b4c6e8dd741f4bbd8b8a'
    '703eb5664803f60e613557b986c11d9e'
    'e1f8981169d98e949b1e87e9ce5528df'
    '8ca1890dbfe6426841992d0fb054bb16'.decode('hex')
)

# This is the inverse of the above. In other words:
# aes_inv_sbox[aes_sbox[val]] == val

_AES_INV_SBOX = array.array(
    'B',
    '52096ad53036a538bf40a39e81f3d7fb'
    '7ce339829b2fff87348e4344c4dee9cb'
    '547b9432a6c2233dee4c950b42fac34e'
    '082ea16628d924b2765ba2496d8bd125'
    '72f8f66486689816d4a45ccc5d65b692'
    '6c704850fdedb9da5e154657a78d9d84'
    '90d8ab008cbcd30af7e45805b8b34506'
    'd02c1e8fca3f0f02c1afbd0301138a6b'
    '3a9111414f67dcea97f2cfcef0b4e673'
    '96ac7422e7ad3585e2f937e81c75df6e'
    '47f11a711d29c5896fb7620eaa18be1b'
    'fc563e4bc6d279209adbc0fe78cd5af4'
    '1fdda8338807c731b11210592780ec5f'
    '60517fa919b54a0d2de57a9f93c99cef'
    'a0e03b4dae2af5b0c8ebbb3c83539961'
    '172b047eba77d626e169146355210c7d'.decode('hex')
)

# The Rcon table is used in AES's key schedule (key expansion)
# It's a pre-computed table of exponentation of 2 in AES's finite field
#
# More information: http://en.wikipedia.org/wiki/Rijndael_key_schedule

_AES_RCON = array.array(
    'B',
    '8d01020408102040801b366cd8ab4d9a'
    '2f5ebc63c697356ad4b37dfaefc59139'
    '72e4d3bd61c29f254a943366cc831d3a'
    '74e8cb8d01020408102040801b366cd8'
    'ab4d9a2f5ebc63c697356ad4b37dfaef'
    'c5913972e4d3bd61c29f254a943366cc'
    '831d3a74e8cb8d01020408102040801b'
    '366cd8ab4d9a2f5ebc63c697356ad4b3'
    '7dfaefc5913972e4d3bd61c29f254a94'
    '3366cc831d3a74e8cb8d010204081020'
    '40801b366cd8ab4d9a2f5ebc63c69735'
    '6ad4b37dfaefc5913972e4d3bd61c29f'
    '254a943366cc831d3a74e8cb8d010204'
    '08102040801b366cd8ab4d9a2f5ebc63'
    'c697356ad4b37dfaefc5913972e4d3bd'
    '61c29f254a943366cc831d3a74e8cb'.decode('hex')
)


def _galois_multiply(i, j):
    # Galois Field multiplicaiton for AES
    k = 0
    while j:
        if j & 1:
            k ^= i
        i <<= 1
        if i & 0x100:
            i ^= 0x1b
        j >>= 1

    return k & 0xff


# Precompute the multiplication tables for encryption
_GF_MUL_BY_2 = array.array('B', [_galois_multiply(x, 2) for x in range(256)])
_GF_MUL_BY_3 = array.array('B', [_galois_multiply(x, 3) for x in range(256)])
# ... for decryption
_GF_MUL_BY_9 = array.array('B', [_galois_multiply(x, 9) for x in range(256)])
_GF_MUL_BY_11 = array.array('B', [_galois_multiply(x, 11) for x in range(256)])
_GF_MUL_BY_13 = array.array('B', [_galois_multiply(x, 13) for x in range(256)])
_GF_MUL_BY_14 = array.array('B', [_galois_multiply(x, 14) for x in range(256)])


class _AES(object): #pylint: disable=C0111
    def _expand_key(self):
        # Performs AES key expansion on self.key and stores in self.exkey
        #
        # The key schedule specifies how parts of the key are fed into the
        # cipher's round functions. "Key expansion" means performing this
        # schedule in advance. Almost all implementations do this.
        #
        # Here's a description of AES key schedule:
        # http://en.wikipedia.org/wiki/Rijndael_key_schedule

        # The expanded key starts with the actual key itself
        exkey = array.array('B', self.key)

        # extra key expansion steps
        if self.key_size == 16:
            extra_cnt = 0
        elif self.key_size == 24:
            extra_cnt = 2
        else:
            extra_cnt = 3

        # 4-byte temporary variable for key expansion
        word = exkey[-4:]
        # Each expansion cycle uses 'i' once for Rcon table lookup
        for i in xrange(1, 11):

            #### key schedule core:
            # left-rotate by 1 byte
            word = word[1:4] + word[0:1]

            # apply S-box to all bytes
            for j in xrange(4):
                word[j] = _AES_SBOX[word[j]]

            # apply the Rcon table to the leftmost byte
            word[0] ^= _AES_RCON[i]
            #### end key schedule core

            for dummy in xrange(4):
                for j in xrange(4):
                    # mix in bytes from the last subkey
                    word[j] ^= exkey[-self.key_size + j]
                exkey.extend(word)

            # Last key expansion cycle always finishes here
            if len(exkey) >= (self.rounds + 1) * self.block_size:
                break

            # Special substitution step for 256-bit key
            if self.key_size == 32:
                for j in xrange(4):
                    # mix in bytes from the last subkey XORed with S-box of
                    # current word bytes
                    word[j] = _AES_SBOX[word[j]] ^ exkey[-self.key_size + j]
                exkey.extend(word)

            # Twice for 192-bit key, thrice for 256-bit key
            for dummy in xrange(extra_cnt):
                for j in xrange(4):
                    # mix in bytes from the last subkey
                    word[j] ^= exkey[-self.key_size + j]
                exkey.extend(word)

        return exkey

    def __init__(self, key):
        self.block_size = 16
        self.key = key
        self.key_size = len(key)

        if self.key_size == 16:
            self.rounds = 10
        elif self.key_size == 24:
            self.rounds = 12
        elif self.key_size == 32:
            self.rounds = 14
        else:
            raise ValueError("Key length must be 16, 24 or 32 bytes")

        self.exkey = self._expand_key()

    def _add_round_key(self, block, _round):
        # AddRoundKey step. This is where the key is mixed into plaintext

        offset = _round * 16
        exkey = self.exkey

        for i in xrange(16):
            block[i] ^= exkey[offset + i]

    @staticmethod
    def _sub_bytes(block, sbox):
        # SubBytes step, apply S-box to all bytes
        #
        # Depending on whether encrypting or decrypting, a different sbox array is passed in.

        for i in xrange(16):
            block[i] = sbox[block[i]]

    @staticmethod
    def _shift_rows(rows):
        # ShiftRows step in AES.
        #
        # Shifts 2nd row to left by 1, 3rd row by 2, 4th row by 3
        #
        # Since we're performing this on a transposed matrix, cells are numbered
        # from top to bottom first::
        #
        #   0  4  8 12 ->  0  4  8 12  -- 1st row doesn't change
        #   1  5  9 13 ->  5  9 13  1  -- row shifted to left by 1 (wraps around)
        #   2  6 10 14 -> 10 14  2  6  -- shifted by 2
        #   3  7 11 15 -> 15  3  7 11  -- shifted by 3

        rows[1], rows[5], rows[9], rows[13] = rows[5], rows[9], rows[13], rows[1]
        rows[2], rows[6], rows[10], rows[14] = rows[10], rows[14], rows[2], rows[6]
        rows[3], rows[7], rows[11], rows[15] = rows[15], rows[3], rows[7], rows[11]

    @staticmethod
    def _shift_rows_inv(rows):
        # Similar to _shift_rows above, but performed in inverse for decryption.
        rows[5], rows[9], rows[13], rows[1] = rows[1], rows[5], rows[9], rows[13]
        rows[10], rows[14], rows[2], rows[6] = rows[2], rows[6], rows[10], rows[14]
        rows[15], rows[3], rows[7], rows[11] = rows[3], rows[7], rows[11], rows[15]

    @staticmethod
    def _mix_columns(block):
        # MixColumns step. Mixes the values in each column

        # Cache global multiplication tables (see below)
        mul_by_2 = _GF_MUL_BY_2
        mul_by_3 = _GF_MUL_BY_3

        # Since we're dealing with a transposed matrix, columns are already
        # sequential
        for col in xrange(0, 16, 4):
            val0, val1, val2, val3 = block[col:col + 4]

            block[col] = mul_by_2[val0] ^ val3 ^ val2 ^ mul_by_3[val1]
            block[col + 1] = mul_by_2[val1] ^ val0 ^ val3 ^ mul_by_3[val2]
            block[col + 2] = mul_by_2[val2] ^ val1 ^ val0 ^ mul_by_3[val3]
            block[col + 3] = mul_by_2[val3] ^ val2 ^ val1 ^ mul_by_3[val0]

    @staticmethod
    def _mix_columns_inv(block):
        # Similar to _mix_columns above, but performed in inverse for decryption.

        # Cache global multiplication tables (see below)
        mul_9 = _GF_MUL_BY_9
        mul_11 = _GF_MUL_BY_11
        mul_13 = _GF_MUL_BY_13
        mul_14 = _GF_MUL_BY_14

        # Since we're dealing with a transposed matrix, columns are already
        # sequential
        for col in xrange(0, 16, 4):
            val0, val1, val2, val3 = block[col:col + 4]

            block[col] = mul_14[val0] ^ mul_9[val3] ^ mul_13[val2] ^ mul_11[val1]
            block[col + 1] = mul_14[val1] ^ mul_9[val0] ^ mul_13[val3] ^ mul_11[val2]
            block[col + 2] = mul_14[val2] ^ mul_9[val1] ^ mul_13[val0] ^ mul_11[val3]
            block[col + 3] = mul_14[val3] ^ mul_9[val2] ^ mul_13[val1] ^ mul_11[val0]

    # def _encrypt_block(self, block):
    #     # Encrypts a single block. This is the main AES function

    #     # For efficiency reasons, the state between steps is transmitted via a
    #     # mutable array, not returned
    #     self._add_round_key(block, 0)

    #     for round_ in xrange(1, self.rounds):
    #         self._sub_bytes(block, _AES_SBOX)
    #         self._shift_rows(block)
    #         self._mix_columns(block)
    #         self._add_round_key(block, round_)

    #     self._sub_bytes(block, _AES_SBOX)
    #     self._shift_rows(block)
    #     # no _mix_columns step in the last round
    #     self._add_round_key(block, self.rounds)

    def xjggtyssw(self, block):
        # Decrypts a single block. This is the main AES decryption function

        # For efficiency reasons, the state between steps is transmitted via a
        # mutable array, not returned
        self._add_round_key(block, self.rounds)

        # count rounds down from (self.rounds) ... 1
        for _round in xrange(self.rounds - 1, 0, -1):
            self._shift_rows_inv(block)
            self._sub_bytes(block, _AES_INV_SBOX)
            self._add_round_key(block, _round)
            self._mix_columns_inv(block)

        self._shift_rows_inv(block)
        self._sub_bytes(block, _AES_INV_SBOX)
        self._add_round_key(block, 0)
        # no _mix_columns step in the last round


class _CBCMode(object):
    # Cipher Block Chaining(CBC) mode encryption. This mode avoids content leaks.
    #
    # In CBC encryption, each plaintext block is XORed with the ciphertext block
    # preceding it; decryption is simply the inverse.

    # A better explanation of CBC can be found here:
    # http://en.wikipedia.org/wiki/Block_cipher_modes_of_operation#-
    # Cipher-block_chaining_.28CBC.29

    def __init__(self, cipher, IV):
        self.cipher = cipher
        self.block_size = cipher.block_size
        self.ivec = array.array('B', IV)

    # def encrypt(self, data):
    #     # Encrypt data in CBC mode

    #     block_size = self.block_size
    #     if len(data) % block_size != 0:
    #         raise ValueError("Plaintext length must be multiple of 16")

    #     data = array.array('B', data)
    #     ivec = self.ivec

    #     for offset in xrange(0, len(data), block_size):
    #         block = data[offset:offset + block_size]

    #         # Perform CBC chaining
    #         for i in xrange(block_size):
    #             block[i] ^= ivec[i]

    #         self.cipher._encrypt_block(block) #pylint: disable=W0212
    #         data[offset:offset + block_size] = block
    #         ivec = block

    #     self.ivec = ivec
    #     return data.tostring()

    def jmpp(self, data):
        # Decrypt data in CBC mode

        block_size = self.block_size
        if len(data) % block_size != 0:
            raise ValueError("Ciphertext length must be multiple of 16")

        data = array.array('B', data)
        ivec = self.ivec

        for offset in xrange(0, len(data), block_size):
            ctext = data[offset:offset + block_size]
            block = ctext[:]
            self.cipher.xjggtyssw(block) #pylint: disable=W0212

            # Perform CBC chaining
            #for i in xrange(block_size):
            #    data[offset + i] ^= IV[i]
            for i in xrange(block_size):
                block[i] ^= ivec[i]
            data[offset:offset + block_size] = block

            ivec = ctext
            #data[offset : offset+block_size] = block

        self.ivec = ivec
        return data.tostring()


class CBCImporter(object): #pylint: disable=C0111
    def __init__(self, fullname, cbc_file):
        self.path = os.path.dirname(cbc_file)
        self._cbc_file = cbc_file
        self._basepath = fullname.replace('.', os.sep)
        self._sources = {}
        self._mtime = 0

    def _decode(self, path, source):
        xbmc.log('CBCImporter._decode(%s, %d)' % (path, len(source)), xbmc.LOGNOTICE)
        parent = os.path.dirname(path)
        ext = '' if not path else os.path.splitext(path)[1]
        if ext == '.py':
            yield path, source

        elif ext == '.zip':
            zipf = zipfile.ZipFile(StringIO.StringIO(source))
            if zipf.testzip():
                raise Exception('corrupted zip file')
            for name in zipf.namelist():
                source = zipf.read(name)
                xbmc.log('CBCImporter._decode: %s[zip]: unzipped %s[%d]' % (path, name, len(source)), xbmc.LOGNOTICE)
                for relpath, nsource in self._decode(name, source):
                    yield os.path.join(parent, relpath), nsource

        elif ext == '.cbc':
            msource = None
            if not msource:
                try:
                    msource = inspect.getsource(sys.modules[__name__])
                    if not msource:
                        raise Exception
                    xbmc.log('CBCImporter._decode: module source length (in memory): %d' % len(msource), xbmc.LOGNOTICE)
                except Exception:
                    pass
            if not msource:
                try:
                    msourcefile = os.path.splitext(__file__)[0]+'.py'
                    with open(msourcefile) as fil:
                        msource = fil.read()
                    if not msource:
                        raise Exception
                    xbmc.log('CBCImporter._decode: module source length (file %s): %d' % (msourcefile, len(msource)), xbmc.LOGNOTICE)
                except Exception:
                    pass
            if not msource:
                try:
                    for mimp in sys.meta_path:
                        if not isinstance(mimp, CBCImporter) and hasattr(mimp, 'path'):
                            msource = ast.literal_eval(xbmcgui.Window(10000).getProperty(mimp.path))
                            xbmc.log('CBCImporter._decode: module source length (property %s): %d' % (mimp.path, len(msource)), xbmc.LOGNOTICE)
                            break
                except Exception:
                    pass
            if not msource:
                raise Exception('missing decoder source')

            keymap = () # This will be filled by the obfuscator
            key = ''.join([msource[k] for k in keymap if k < len(msource)])
            key = hashlib.sha256(key).digest()
            xbmc.log('CBCImporter._decode: KEY(base64): %s' % base64.b64encode(key), xbmc.LOGNOTICE)

            ivec = source[0:16]
            crypto = _CBCMode(_AES(key), ivec)
            source = crypto.jmpp(source[16:])
            pad_length = ord(source[-1])
            if pad_length > 16 or any(ord(p) != pad_length for p in source[-pad_length:]):
                raise Exception('corrupted cbc file')
            source = source[:-pad_length]
            name = ''
            while True:
                header, source = source.split('\n', 1)
                hname, hvalue = header.split(':')
                hname = hname.lower()
                hnext = hvalue[-1]
                hvalue = hvalue[:-1]
                xbmc.log('CBCImporter._decode: %s[cbc]: %s: %s' % (path, hname.capitalize(), hvalue), xbmc.LOGNOTICE)
                if hname == 'version':
                    pass
                elif hname.lower() == 'filename':
                    name = hvalue
                if hnext == '.':
                    break
                if hnext != ';':
                    raise Exception('corrupted cbc header')
            xbmc.log('CBCImporter._decode: %s[cbc]: decrypted %s[%d]' % (path, name, len(source)), xbmc.LOGNOTICE)
            for relpath, source in self._decode(name, source):
                yield os.path.join(parent, relpath), source

        elif ext == '.uu' or source.startswith('begin '):
            uuencoded = StringIO.StringIO(source)
            name = uuencoded.readline().strip().split(' ')[2]
            uuencoded.seek(0)
            uudecoded = StringIO.StringIO()
            uu.decode(uuencoded, uudecoded)
            uudecoded.seek(0)
            source = uudecoded.read()
            xbmc.log('CBCImporter._decode: %s[uu]: decoded %s[%d]' % (path, name, len(source)), xbmc.LOGNOTICE)
            for relpath, source in self._decode(name, source):
                yield os.path.join(parent, relpath), source

        else:
            yield path, source

    @staticmethod
    def _is_package(filename):
        return filename and os.path.basename(filename) == '__init__.py'

    def _path_to_fullname(self, path):
        if self._is_package(path):
            path = os.path.dirname(path)
        return os.path.splitext(path)[0].replace(os.sep, '.')

    def _load_sources(self):
        if os.stat(self._cbc_file).st_mtime == self._mtime:
            return
        self._sources = {}
        with open(self._cbc_file, 'rb') as fil:
            for relpath, source in self._decode(os.path.basename(self._cbc_file), fil.read()):
                path = os.path.join(self._basepath, relpath)
                try:
                    self._sources[path] = source if relpath == '__init__.py' else compile(source, relpath, 'exec')
                except Exception as ex:
                    xbmc.log('CBCImporter._load_sources: %s[%d]: %s' % (path, len(source), repr(ex)), xbmc.LOGNOTICE)
        self._mtime = os.stat(self._cbc_file).st_mtime
        for name, source in self._sources.iteritems():
            if isinstance(source, basestring):
                xbmc.log('CBCImporter._load_sources: %s[%d]' % (name, len(source or [])), xbmc.LOGNOTICE)
            elif source is not None:
                xbmc.log('CBCImporter._load_sources: %s[BC%d]' % (name, len(source.co_code)), xbmc.LOGNOTICE)

    def _fullname_to_path(self, fullname):
        fullname = fullname.split('@')[-1]
        filename = fullname.replace('.', os.sep)
        py_filename = filename + '.py'
        py_package = os.path.join(filename, '__init__.py')
        self._load_sources()
        if py_filename in self._sources:
            return py_filename
        if py_package in self._sources:
            return py_package
        return None

    def find_module(self, fullname, path):
        try:
            path = self._fullname_to_path(fullname)
        except Exception:
            path = None
        if path is None:
            return None
        xbmc.log('CBCImporter.find_module: %s [%s]' % (fullname, path), xbmc.LOGNOTICE)
        return self

    def load_module(self, fullname):
        filename = self._fullname_to_path(fullname)
        self._load_sources()
        if filename not in self._sources:
            raise ImportError(fullname)
        mod = sys.modules.setdefault(fullname, imp.new_module(fullname))
        mod.__file__ = filename
        mod.__loader__ = self
        if self._is_package(filename):
            mod.__path__ = [self.path]
            mod.__package__ = fullname
        else:
            mod.__package__ = fullname.rpartition('.')[0]
        exec self._sources[filename] in mod.__dict__ # pylint: disable=exec-used
        xbmc.log('CBCImporter.load_module: %s: __package__=%s, __file__=%s' % (fullname, mod.__package__, filename), xbmc.LOGNOTICE) #pylint: disable=C0301
        return mod

    def is_package(self, fullname):
        return self._is_package(self._fullname_to_path(fullname))

    def get_source(self, fullname):
        filename = self._fullname_to_path(fullname)
        if not self._is_package(filename) or os.path.dirname(filename) != self._basepath:
            raise IOError
        return self._sources[filename]

    def get_code(self, fullname):
        return compile(self.get_source(fullname), self._cbc_file, 'exec')

    def iter_modules(self, prefix=''):
        self._load_sources()
        for path in sorted(self._sources):
            path = path[len(self._basepath)+len(os.sep):]
            if self._is_package(path):
                if os.path.dirname(path):
                    yield prefix + os.path.dirname(path).replace(os.sep, '.'), True
            elif os.path.splitext(path)[1] == '.py':
                yield prefix + os.path.splitext(path)[0].replace(os.sep, '.'), False
