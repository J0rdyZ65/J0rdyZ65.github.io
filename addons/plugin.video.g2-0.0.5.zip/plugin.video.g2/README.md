G2
======================

About
-----
G2 is the Gio's own version of an once famous addon

Features at glance
------------------
- Sources dialog
  - Show the stream sources as they are found by the providers ordered by user preference
  - Check the sources validity and stream resolution (MP4, FLV and M3U formats)
- Player dialog
  - Automatic bookmarking for playing resume
  - Automatic watched status update
- Movie/TVshow listing
  - Metadata fetching from tmdb, tvdb and imdb
  - Context commands to set/unset the watched status
  - Keep watching directory (list of video bookmarked)
- Kodi video library
  - Watched status sync
  - Play library movie/episode
- Trakt
  - Watched status sync
- Pushbullet
  - Push of imdb, tvdb movie/episode pages to trigger a search through the sources dialog
  - Notification of start/stop video playing including the title, mpaa rating and imdb url
  - Forced stop of the current playing title from any connected device
- Script.extendedinfo
  - Context commands to show movie/TVshow/season/episode/person information and trailer play
- External players integration
  - Net\*\*ix, Rai\*\*ay
- Supported link resolution
  - script.module.urlresolve
  - plugin.video.icarus servers
- Built to be extensible via addon packages

Attributions
---------------------
- Inspired by the original lambda work
- Cloudflare bypass by Icarus and cfscrape | https://github.com/Anorov/cloudflare-scrape
- Fuzzy matching by seatgeek | https://github.com/seatgeek/fuzzywuzzy
- MP4 decoding by charsyam@github | https://github.com/charsyam/mp4parser
- Websocket by Lawouach | https://github.com/Lawouach/WebSocket-for-Python
- Pushbullet by Azelphur | https://github.com/Azelphur/pyPushBullet
- Portalocker by WoLpH | https://github.com/WoLpH/portalocker
- Original Italian translation by Frep | https://twitter.com/frep90

License
-------
This software is released under the [GPL 3.0 license] [1] except where otherwise noted

[1]: http://www.gnu.org/licenses/gpl-3.0.html
