# -*- coding: utf-8 -*-

[@packages] {
    # ==============
    # Addon packages
    # ==============
    'providers.italian_streamers': (
    	'A very small selection of italian streaming services',
        'github://J0rdyZ65/g2.packages/italian_streamers',
    ),
}

[@sites] {
    # =========================
    # Pushed url matching rules
    # =========================
    # This section specifies how to parse the pushed url to retrieve the video ids and let g2 to play the stream.
    #
    # The key is the *two* top level domain elements of the site from which the push is originated.
    # The value is a dict with the following key/value pairs:
    #   'type':     'db'                        -- The only valid value, it means that the video meta is
    #                                              fetched from the dbs modules;
    #   'id_name':  'imdb'|'tmdb'|'tvdb'        -- Which kind of db id is extracted from the pushed url;
    #   'id_value': regexp pattern              -- Regular expression to match the db id from the pushed url.
    #   
    'imdb.com': {
        'type': 'db',
        'id_name': 'imdb',
        'id_value': r'/title/(tt[\d]+)',
    },
    'themoviedb.org': {
        'type': 'db',
        'id_name': 'tmdb',
        'id_value': r'/movie/([\d]+)',
    },
}

[@media] {
    # ======================
    # Resource media mapping
    # ======================
    # This section specifies how to use the images present in specific resource images addons.
    #
    # The key of the top level dictionary is the prefix to the theme name
    # The dictionary item has the following keys:
    #     'addon_id'      Kodi resource image addon id. The empty key is reserved for g2;
    #     'media_path'    relative to the addon path, specified as a list of hierarchical
    #                     folders that will be joined using the os.path.join. If omitted,
    #                     is is assumed to be ['resources', 'media'].
    #     'themes'        if set to 'folder' means that each sub-folder of the :media_path:
    #                     is a different theme whose name is the sub-folder name itself.
    #                     If omitted, the resource is assumed to represent a single theme.
    #     'mappings'      a dictionary mapping the g2 icon name (without suffix) to the
    #                     resource icon name (with or w/o suffix). If the name is the same,
    #                     the entry is not required. This key can be altogether omitted if
    #                     all the names are the same.
    #
    # Entry for the plugin.video.g2 resources/media folder
    '': {
        'themes': 'folder',
    },
    # Entry for the Exodus themes in the script.exodus.artwork addon
    'Exodus': {
        'addon_id': 'script.exodus.artwork',
        'themes': 'folder',
        'mappings': {
            'settings': 'tools.png',
            'cache': 'tools.png',
            'moviesTraktcollection': 'trakt.png',
            'moviesTraktwatchlist': 'trakt.png',
            'moviesTraktrated': 'trakt.png',
            'moviesTraktrecommendations': 'trakt.png',
            'movieUserlists': 'userlists.png',
            'mymenu': 'userlists.png',
            'moviesAdded': 'latest-movies.png',
            'movieSearch': 'search.png',
            'moviePerson': 'people-search.png',
            'movieYears': 'years.png',
            'movieGenres': 'genres.png',
            'movieCertificates': 'certificates.png',
            'moviesTrending': 'featured.png',
            'moviesPopular': 'most-popular.png',
            'moviesViews': 'most-voted.png',
            'moviesBoxoffice': 'box-office.png',
            'moviesOscars': 'oscar-winners.png',
            'moviesTheaters': 'in-theaters.png',
            'tvSearch': 'search.png',
            'tvshowsTrending': 'featured.png',
            'tvshowsPopular': 'most-popular.png',
        },
    },
    # Entry for the Covenant themes in the script.covenant.artwork addon
    'Covenant': {
        'addon_id': 'script.covenant.artwork',
        'themes': 'folder',
        'mappings': {
            'settings': 'tools.png',
            'cache': 'tools.png',
            'moviesTraktcollection': 'trakt.png',
            'moviesTraktwatchlist': 'trakt.png',
            'moviesTraktrated': 'trakt.png',
            'moviesTraktrecommendations': 'trakt.png',
            'movieUserlists': 'userlists.png',
            'mymenu': 'userlists.png',
            'moviesAdded': 'latest-movies.png',
            'movieSearch': 'search.png',
            'moviePerson': 'people-search.png',
            'movieYears': 'years.png',
            'movieGenres': 'genres.png',
            'movieCertificates': 'certificates.png',
            'moviesTrending': 'featured.png',
            'moviesPopular': 'most-popular.png',
            'moviesViews': 'most-voted.png',
            'moviesBoxoffice': 'box-office.png',
            'moviesOscars': 'oscar-winners.png',
            'moviesTheaters': 'in-theaters.png',
            'tvSearch': 'search.png',
            'tvshowsTrending': 'featured.png',
            'tvshowsPopular': 'most-popular.png',
        },
    },
}

[@hosts_icons] {
    'abysstream': 'http://abysstream.com/images/logo.png',
    'akstream': 'http://akvideo.stream/img/logo.png',
    'backin': 'http://backin.net/images/logo_bw.png',
    'flashx': 'https://static.flashx.to/images/logo.png',
    'megadrive': 'https://mega.nz/favicon.ico',
    'movshare': 'http://www.wholecloud.net/images/logo.png',
    'okru': 'http://st.mycdn.me/res/i/p/anonym/logo_48x82.png',
    'openload': 'https://openload.co/assets/img/logo.png',
    'rapidvideo': 'https://www.rapidvideo.com/images/rapidvideo.png',
    'rapidvideo.com': 'https://www.rapidvideo.com/images/rapidvideo.png',
    'speedvideo': 'http://speedvideo.net/img/speed_logo_red.png',
    'streamango': 'http://streamango.com/assets/img/logo.png',
    'streamcherry': 'https://streamcherry.com/assets/img/logo.png',
    'subyshare': 'https://subyshare.com/img/logo.png',
    'thevideome': 'https://vev.io/icons/9cef074a405c1d55b094c0d43055dd73/favicon-32x32.png',
    'tusfiles': 'https://tusfiles.net/i/TFLOGO.png',
    'wstream': 'https://wstream.video/img/logo.png',
    'uploadgig': 'http://uploadgig.com/static/tpl2/img/logo.png',
    'uptobox': 'https://static.uptobox.com/images/logo.png',
    'videowood': 'http://videowood.tv/assets/images/videowood_res.png',
    'vidto': 'http://static.vidto.me/static/images/header-logo.png',
    'netflix': 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Netflix_icon.svg/240px-Netflix_icon.svg.png',
    'raiplay': 'http://www.rai.it/dl/RaiTV/2012/images/ogImage.jpg',
    'youtube': 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/YouTube_icon.png/320px-YouTube_icon.png',
}

[@actions] {
    # Automagically generated: do NOT modify!!!
    'tvshows.menu': {},
    'tvshows.episodes': {'tvdb': 'int', 'season': 'int', 'imdb': 'str'},
    'tvshows.deletebookmark': {'meta': 'dict'},
    'movies.certifications': {},
    'tools.factory_reset': {},
    'auth.pushbullet': {},
    'tvshows.genres': {},
    'tvshows.addtolibrary': {'meta': 'dict', 'title': 'str'},
    'sources.content_language': {},
    'main.menu': {},
    'sources.clearsourcescache': {'meta': 'dict', 'name': 'str'},
    'movies.searchbyperson': {},
    'movies.movielist': {'url': 'str'},
    'player.notify': {},
    'tools.updatemedia': {},
    'auth.tmdb': {},
    'movies.deletebookmark': {'meta': 'dict'},
    'tvshows.tvshowlist': {'url': 'str'},
    'auth.trakt': {},
    'movies.genres': {},
    'sources.play': {'content': 'str', 'meta': 'dict'},
    'movies.bookmarked': {},
    'changelog.show': {},
    'tools.package_manager': {},
    'movies.addtolibrary': {'meta': 'dict', 'title': 'str'},
    'sources.watched': {'content': 'str', 'seen': 'bool', 'meta': 'dict'},
    'tools.clearcache': {},
    'videolibrary.update': {'content': 'str', 'meta': 'dict', 'title': 'str'},
    'tools.advanced_settings': {},
    'tvshows.seasons': {'tvdb': 'int', 'imdb': 'str'},
    'movies.searchbyyear': {},
    'tools.settings': {'category': 'str'},
    'movies.menu': {},
    'movies.searchbytitle': {},
    'tvshows.bookmarked': {},
    'tvshows.searchbytitle': {},
    'tools.menu': {},
    'tvshows.searchbyyear': {},
    'movies.personlist': {'url': 'str'},
}
