[@packages] {
    'providers.italian_streamers': (
    	'A very small selection of italian streaming services',
        'github://J0rdyZ65/g2.packages/italian_streamers'),
}
