# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import print_function

import os
import sys
import pkgutil


_LOG_MODULES = []
"""List of sandboxed modules for which to activate the debug logging.

To activate the debug logging for all modules, insert the '*' identifier.
"""

try:
    import xbmc

    def install(addons_path=None, log_modules=None):
        if not addons_path:
            addons_path = os.path.join(xbmc.translatePath('special://home').decode('utf-8'), 'addons') # decode kodi dirname
        if log_modules:
            _LOG_MODULES.append(log_modules)
        for addon_dir in os.listdir(addons_path):
            addon_path = os.path.join(addons_path, addon_dir)
            if os.path.isdir(addon_path):
                add_path(addon_path)
        if ImpImporterSandbox not in sys.path_hooks:
            sys.path_hooks.append(ImpImporterSandbox)

except ImportError:
    # No other platforms supported
    pass
except Exception as ex:
    print('[%s] %s' % (sys.argv[0], ex))


_HANDLED_PATHS = {}
_SANDBOX_NAMESPACE_SEP = '@'


def _normalize_sandbox_name(name):
    return name.replace('.', '_')


for i, module in enumerate(_LOG_MODULES):
    _LOG_MODULES[i] = _normalize_sandbox_name(module)


def _log(sandbox, msg):
    if '*' in _LOG_MODULES or sandbox in _LOG_MODULES:
        xbmc.log('[%s%s] %s' % (sys.argv[0], '' if len(sys.argv) <= 1 else ':'+sys.argv[1], msg))


def _name_is_sandboxed(fullname):
    return _SANDBOX_NAMESPACE_SEP in fullname


def _name_sandbox(sandbox, fullname):
    if _name_is_sandboxed(fullname) or not sandbox:
        return fullname
    return sandbox+_SANDBOX_NAMESPACE_SEP+fullname


def _name_get_sandbox(fullname):
    return None if not _name_is_sandboxed(fullname) else fullname.split(_SANDBOX_NAMESPACE_SEP, 1)[0]


def _name_desandbox(fullname):
    return fullname if not _name_is_sandboxed(fullname) else fullname.split(_SANDBOX_NAMESPACE_SEP, 1)[1]


def add_path(path):
    sandbox = _normalize_sandbox_name(os.path.basename(path))
    for pat in (path, os.path.realpath(path)):
        if pat not in _HANDLED_PATHS:
            _HANDLED_PATHS[pat] = sandbox
            _log(sandbox, 'importer: imports under path %s handled as %s'%(pat, sandbox))


def walk_packages(path=None, prefix='', onerror=None):
    for package, name, is_pkg in pkgutil.walk_packages(path, prefix, onerror):
        yield package, _name_desandbox(name), is_pkg


class ImpImporterSandbox(pkgutil.ImpImporter):
    """
        The ImpImporterSandbox class enhance the standard import mechanism
        by creating a separate module namespace for each addon.
        This allow the coexistence in the same python thread of different addons
        using the same module namespace regardless of the import model used.

        Usage:
            import sys
            import importer
            importer.add_path(addon_root_directory)
            ...
            sys.path_hooks.append(importer.ImpImporterSandbox)

        NOTE1: specify a path for each addon that requires a separate namespace.
        NOTE2: the ImpImporterSandbox doesn't respect the module reload semantic.
    """
    def __init__(self, path_entry):
        self.sandbox = None
        for hpath, sandbox in _HANDLED_PATHS.items():
            if path_entry.startswith(hpath):
                pkgutil.ImpImporter.__init__(self, path_entry)

                self.sandbox = sandbox
                self._log('ImpImporterSandbox(%s, %s): handled: sandbox=%s'%(self, path_entry, self.sandbox))
                return

        self._log('ImpImporterSandbox(%s, %s): not handled'%(self, path_entry))
        raise ImportError()

    def find_module(self, fullname, path=None):
        self._log('find_module(%s, %s, %s)'%(self, fullname, path))

        if self.sandbox is None:
            self._log('find_module(): sandbox is None')
            return None

        impl = pkgutil.ImpImporter.find_module(self, fullname, path)
        if not impl:
            self._log('find_module(%s, %s, ...): module not found'%(self.path, fullname))
            return None

        self._log('find_module(%s, %s, ...): sandbox=%s, impl.fullname=%s, file=%s, filename=%s, etc=%s'%
                  (self.path, fullname, self.sandbox, impl.fullname, impl.file, impl.filename, impl.etc))

        return ImpLoaderSandbox(_name_sandbox(self.sandbox, impl.fullname), impl.file, impl.filename, impl.etc)

    def iter_modules(self, prefix=''):
        self._log('iter_modules(%s, %s)'%(self, prefix))

        # Standard python packages and modules walking
        for name, is_pkg in pkgutil.ImpImporter.iter_modules(self, prefix):
            self._log('iter_modules(%s, %s): yield: %s, %s'%(self.path, prefix, _name_sandbox(self.sandbox, name), is_pkg))
            yield _name_sandbox(self.sandbox, name), is_pkg

        # Walk packages handled by Importers on meta_path
        mimps = {}
        abspath = os.path.abspath(self.path)
        for mimp in sys.meta_path:
            self._log('iter_modules(%s, %s): %s: path=%s, iter_modules=%s'%
                      (self.path, prefix, mimp, getattr(mimp, 'path', None), getattr(mimp, 'iter_modules', None)))
            # Handle only Importers with an exposed path attribute and iter_modules method
            if not hasattr(mimp, 'path') or not hasattr(mimp, 'iter_modules'):
                continue

            # If the meta_path Importer path is the same as this Importer, then yield all special Importer modules
            minp_abspath = os.path.abspath(mimp.path)
            if minp_abspath == abspath:
                for name, is_pkg in mimp.iter_modules(prefix):
                    self._log('iter_modules(%s, %s): yield special: %s, %s'%
                              (self.path, prefix, _name_sandbox(self.sandbox, name), is_pkg))
                    # Yield the package's modules/sub-packages
                    yield _name_sandbox(self.sandbox, name), is_pkg
                # Here I'm assuming that there is only one special Importer per path
                return

            # If the meta_path Importer path is an immediate children of this Importer, then add it to the list
            # to be checked during the subsequent directory walking
            if os.path.dirname(minp_abspath) == abspath:
                mimps[minp_abspath] = mimp

        if not mimps:
            return

        for name in os.listdir(abspath):
            path = os.path.join(abspath, name)
            if not os.path.isdir(path) or path not in mimps:
                continue
            self._log('iter_modules(%s, %s): yield special: %s, %s'%(self.path, prefix, _name_sandbox(self.sandbox, name), True))
            # Yield the package
            yield _name_sandbox(self.sandbox, prefix + name), True

            for sname, is_pkg in mimps[path].iter_modules():
                self._log('iter_modules(%s, %s): yield special: %s, %s'%
                          (self.path, prefix, _name_sandbox(self.sandbox, prefix + name + '.' + sname), is_pkg))
                # Yield the package's modules/sub-packages
                yield _name_sandbox(self.sandbox, prefix + name + '.' + sname), is_pkg

    def _log(self, msg):
        _log(self.sandbox, msg)


class ImpLoaderSandbox(pkgutil.ImpLoader):
    def __init__(self, fullname, fil, filename, etc):
        self.sandbox = _name_get_sandbox(fullname)

        self._log('ImpLoaderSandbox(%s, %s, %s, %s, %s)'%(self, fullname, fil, filename, etc))

        pkgutil.ImpLoader.__init__(self, fullname, fil, filename, etc)

    def load_module(self, fullname):
        self._log('load_module(%s, %s)'%(self, fullname))

        sandboxfullname = _name_sandbox(self.sandbox, fullname)

        #
        # NOTE: Kodi, before running an addon, seems to load the top level packages found in the
        #   required section of the addon itself (e.g. for the dependency script.module.requests,
        #   Kodi loads the "requests" package found in "addons/script.module.requests/lib/" directory).
        #   This is done before the importer machinery is hooked up by the addon, so the required
        #   top level packages are inserted in sys.modules not sandboxed (e.g. as "requests" not as
        #   "script_module_requests@requests"). This is not a problem from a conflict point of
        #   view as these packages should not conflict at all and, if they are, the module that imports it
        #   can change the import statement. However, subsequently, this importer module fails to find them.
        #   The check below is performed to verify this scenario and eventually patch the sys.modules.
        #
        cleanfullname = _name_desandbox(sandboxfullname)
        grandparent = cleanfullname.split('.')[0]
        if grandparent != cleanfullname:
            sandboxgrandparent = _name_sandbox(self.sandbox, grandparent)
            if sandboxgrandparent in sys.modules:
                self._log('load_module(..., %s): sandboxed grand parent module %s found in the cache: %s'%
                          (fullname, sandboxgrandparent, sys.modules[sandboxgrandparent]))
            elif grandparent in sys.modules:
                self._log('load_module(..., %s): grand parent module %s found in the cache: %s'%
                          (fullname, grandparent, sys.modules[grandparent]))
                # The top level module is already loaded in sys.modules not sandboxed
                sys.modules[sandboxgrandparent] = sys.modules[grandparent]

        if sandboxfullname in sys.modules:
            mod = sys.modules[sandboxfullname]

            self._log('load_module(..., %s): module %s found in the cache: %s'%(fullname, sandboxfullname, mod))
        else:
            self._log('load_module(..., %s): loading module %s...'%(self, sandboxfullname))

            mod = pkgutil.ImpLoader.load_module(self, sandboxfullname)

        if not mod:
            self._log('load_module(..., %s): loading module %s failed'%(fullname, sandboxfullname))
        else:
            self._log('load_module(..., %s): %s loaded: __name__=%s, __file__=%s, __package__=%s, __path__=%s'%
                      (fullname, sandboxfullname, mod.__name__, mod.__file__, mod.__package__,
                       mod.__path__ if hasattr(mod, '__path__') else 'NO ATTRIBUTE'))

        return mod

    def _log(self, msg):
        _log(self.sandbox, msg)
