# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import sys
import time

import xbmc

# NOTE: Do not import local modules before installing the importer!
import importer
importer.install()

from g2.libraries import workers

from g2.platforms import ui
from g2.platforms import log
from g2.platforms import addon
from g2.platforms import actions
from g2.platforms import service
from g2.platforms.language import _


def main():
    current_thread = str(workers.current_thread())
    while True:
        running_instance = addon.prop('service-manager')
        if not running_instance:
            # Set the property and check again in 1s if the property still has the same value.
            # If not, another thread tried to get hold of the lock.
            # The last thread setting the property wins!
            addon.prop('service-manager', current_thread)
            xbmc.sleep(1000)
        elif running_instance == current_thread:
            break
        else:
            log.notice('service manager aborted (instance %s is already running)', running_instance)
            return

    log.notice('service manager started [v%s, py%s]', addon.info('version'), '.'.join([str(i) for i in sys.version_info[0:3]]))

    monitor = xbmc.Monitor()
    service_thread = None
    service_thread_id = 1
    restart_after = time.time()

    try:
        _service_monitor_setup()

        while not monitor.waitForAbort(1):
            if service_thread and service_thread.is_alive():
                if not addon.prop('service') and _shutdown_service_thread(service_thread):
                    service_thread = None
                    restart_after = time.time()

            elif time.time() <= restart_after:
                continue

            else:
                addon.prop('service', True)
                service_thread_name = 'Service-%d' % service_thread_id
                log.notice('service manager: starting the service thread %s...', service_thread_name)
                service_thread = workers.Thread(service.thread, service_thread_name, name=service_thread_name)
                service_thread.start()
                while not service_thread.is_alive() and not service_thread.started:
                    xbmc.sleep(100)
                if service_thread.is_alive():
                    ui.dialog.info(_('{g2} service started', g2=addon.info('name')), time=5000)
                service_thread_id += 1
                restart_after = time.time() + 15

        _shutdown_service_thread(service_thread)
        log.notice('service manager stopped')

    except Exception as ex:
        log.error('service manager stopped (%s)', repr(ex), trace=True)

    finally:
        addon.prop('service-manager', False)


def _shutdown_service_thread(thd):
    if not thd or not thd.is_alive():
        return True
    log.notice('service manager: stopping the service thread %s...', thd.name)
    thd.die = True
    thd.join(timeout=5)
    if thd.is_alive():
        log.notice('service thread %s is still running', thd.name)
    return not thd.is_alive()


def _service_monitor_setup():
    service.monitor('content_language', 'setting', actions.run, 'sources.contentlanguage')
    service.monitor('trakt_enabled', 'setting', actions.run, 'auth.trakt')
    service.monitor('pushbullet_apikey', 'setting', actions.run, 'auth.pushbullet')
    service.monitor('tmdb_user_apikey', 'setting', actions.run, 'auth.tmdb')
    service.monitor('playing', 'player', actions.run, 'player.notify')

    from g2.platforms import settings
    service.monitor('settings.update_skema', 'service',
                    workers.Thread, settings.update_skema)

    from g2 import notifiers
    from g2.actions import push
    service.monitor('notifiers.events', 'service',
                    notifiers.events, on_push=push.new, on_push_delete=push.delete,
                    init_arg_name='start')

    from g2.actions.sources import download_hosts_icons
    service.monitor('download_hosts_icons', 'service',
                    workers.Thread, download_hosts_icons)

    def _decoder_reload():
        import decoder
        decoder = reload(decoder)
        log.debug('{m}.{f}: reloaded %s', decoder)

    service.monitor('reload_decoder', 'cron',
                    workers.Thread, _decoder_reload,
                    frequency=5)

    from g2.actions import videolibrary
    service.monitor('videolibrary.update', 'service',
                    workers.Thread, videolibrary.update, content='tvshow')

    if addon.exists('metadata.themoviedb.org'):
        from g2.dbs import tmdb
        service.monitor('tmdb.fetch_addon_apikey', 'service',
                        workers.Thread, tmdb.fetch_addon_apikey)


if __name__ == '__main__':
    main()
