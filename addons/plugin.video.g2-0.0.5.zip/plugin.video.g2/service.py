# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import time

import xbmc

# NOTE: Do not import local modules before installing the importer!
import importer
importer.install()

from g2.libraries import log
from g2.libraries import workers
from g2.platforms import addon
from g2.platforms import service
from g2.platforms import portalocker


def main():
    monitor = xbmc.Monitor()

    service_thread = None
    service_thread_id = 1
    next_restart_after = time.time()

    log.notice('service manager started [v{v}]')

    try:
        with portalocker.Lock(addon.info('changelog'), 'r', fail_when_locked=True):
            service_monitor_setup()

            while not monitor.waitForAbort(1):
                if (service_thread and service_thread.is_alive()) or time.time() < next_restart_after:
                    continue
                service_thread_name = 'Service-%d' % service_thread_id
                log.notice('service manager: starting the service thread with id %s...', service_thread_name)
                service_thread = workers.Thread(service.thread, service_thread_name)
                service_thread.start()
                # (fixme) loop until the thread is actually started
                service_thread_id += 1
                next_restart_after = time.time() + 15

            if service_thread and service_thread.is_alive():
                log.notice('service manager: stopping the service thread with id %s...', service_thread.name)
                service_thread.die = True
                service_thread.join(timeout=5)
                if service_thread.is_alive():
                    log.notice('service thread %s is still running', service_thread.name)
    except (portalocker.AlreadyLocked, portalocker.LockException) as ex:
        log.notice('service manager stopped (another instance is already running, %s)', ex)
    except Exception as ex:
        log.error('service manager stopped (%s)', ex, trace=True)
    else:
        log.notice('service manager stopped')


def service_monitor_setup():
    service.monitor('content_language', 'setting', addon.runplugin, 'sources.content_language')
    service.monitor('trakt_enabled', 'setting', addon.runplugin, 'auth.trakt')
    service.monitor('pushbullet_apikey', 'setting', addon.runplugin, 'auth.pushbullet')
    service.monitor('imdb_user', 'setting', addon.runplugin, 'auth.imdb')
    service.monitor('tmdb_user_apikey', 'setting', addon.runplugin, 'auth.tmdb')
    service.monitor('playing', 'player', addon.runplugin, 'player.notify')

    from g2.pkg import update_settings_skema
    service.monitor('update_settings_skema', 'service',
                    workers.Thread, update_settings_skema)

    from g2 import notifiers
    from g2.actions import push
    service.monitor('notifiers.events', 'service',
                    notifiers.events, on_push=push.new, on_push_delete=push.delete,
                    init_arg_name='start')

    from g2.platforms.ui.dialog.sources import download_servers_icons
    service.monitor('download_servers_icons', 'service',
                    workers.Thread, download_servers_icons)

    def _decoder_reload():
        import decoder
        decoder = reload(decoder)
        log.debug('{m}.{f}: reloaded %s', decoder)

    service.monitor('reload_decoder', 'cron',
                    workers.Thread, _decoder_reload,
                    frequency=5)

    from g2.actions import videolibrary
    service.monitor('videolibrary.update', 'cron',
                    workers.Thread, videolibrary.update, content='tvshow',
                    frequency=1440)

    if addon.exists('metadata.themoviedb.org'):
        from g2.dbs import tmdb
        service.monitor('tmdb.fetch_addon_apikey', 'service',
                        workers.Thread, tmdb.fetch_addon_apikey)


if __name__ == '__main__':
    main()
