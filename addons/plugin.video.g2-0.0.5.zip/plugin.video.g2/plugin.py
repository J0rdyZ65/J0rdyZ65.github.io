# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2018 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import sys
import urlparse

import xbmc
import xbmcvfs

import importer
ADDONS_PATH = os.path.join(xbmc.translatePath('special://home'), 'addons')
for addon_dir in xbmcvfs.listdir(ADDONS_PATH)[0]:
    importer.add_path(os.path.join(ADDONS_PATH, addon_dir))
sys.path_hooks.append(importer.ImpImporterSandbox)


def main():
    from g2 import actions

    params = dict(urlparse.parse_qsl(sys.argv[2].replace('?', '')))

    # from g2.libraries import addon
    # from g2.libraries import log
    # log.notice('changelog="%s"', addon.info('changelog'))

    if 'action' not in params:
        actions.execute('changelog.show')
        action = None
    else:
        action = params['action']
        del params['action']

    if not action:
        action = 'main.menu'

    actions.execute(action, params)

    return 0


if __name__ == '__main__':
    main()
