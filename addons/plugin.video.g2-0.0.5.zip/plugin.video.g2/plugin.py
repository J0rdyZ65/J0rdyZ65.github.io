# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import sys
import urlparse

import xbmc
import xbmcvfs

import importer
ADDONS_PATH = os.path.join(xbmc.translatePath('special://home'), 'addons')
for addon_dir in xbmcvfs.listdir(ADDONS_PATH)[0]:
    importer.add_path(os.path.join(ADDONS_PATH, addon_dir))
sys.path_hooks.append(importer.ImpImporterSandbox)

from g2 import actions


def main():
    params = dict(urlparse.parse_qsl(sys.argv[2].replace('?', '')))

    if 'action' not in params:
        actions.execute('changelog.show')
        action = None
    else:
        action = params['action']
        del params['action']

    if not action:
        action = 'main.menu'

    if action == 'service.thread':
        service_monitor_setup()

    actions.execute(action, params)

    return 0


def service_monitor_setup():
    from g2 import pkg

    pkg.update_settings_skema()

    from g2.libraries import addon
    from g2.actions import service

    service.monitor('content_language', 'setting', addon.runplugin, 'sources.content_language')
    service.monitor('trakt_enabled', 'setting', addon.runplugin, 'auth.trakt')
    service.monitor('pushbullet_apikey', 'setting', addon.runplugin, 'auth.pushbullet')
    service.monitor('imdb_user', 'setting', addon.runplugin, 'auth.imdb')
    service.monitor('tmdb_user_apikey', 'setting', addon.runplugin, 'auth.tmdb')
    service.monitor('playing', 'player', addon.runplugin, 'player.notify')

    from g2 import notifiers
    from g2.actions import push
    service.monitor('notifiers.events', 'service', notifiers.events,
                    init_arg_name='start', on_push=push.new, on_push_delete=push.delete)

    from g2.libraries import workers
    from g2.actions.ui.dialog.sources import download_servers_icons
    service.monitor('download_servers_icons', 'service', workers.Thread, download_servers_icons)

    def _import_decoder():
        import decoder
        decoder = reload(decoder)

    service.monitor('import_check', 'cron',
                    workers.Thread, _import_decoder, frequency=6)

    service.monitor('videolibrary.update', 'cron',
                    addon.runplugin, 'videolibrary.update', update_tvshows='true',
                    frequency=1440)

    if addon.exists('metadata.themoviedb.org'):
        from g2.dbs import tmdb
        service.monitor('tmdb.fetch_addon_apikey', 'service',
                        workers.Thread, tmdb.fetch_addon_apikey)


if __name__ == '__main__':
    main()
