# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import abc

from g2.pkg import setting
from g2.resolvers import ResolvedURL


class ProviderBase(object): # pylint: disable=abstract-class-little-used
    """Provider API Abstract Base Class

    This is the base class for a new provider implementation.
    The mandatory attributes / methods to implement are:

    * ``info``
    * ``search(content, language, meta)``
    * ``sources(content, language, url)``

    The optional methods to implement are:

    * ``resolve(url)``

    """
    __metaclass__ = abc.ABCMeta

    def __init__(self, module, provider, package):
        self.module = module
        self.provider = provider
        self.package = package if package is not None else provider.package

    def setting(self, setid):
        """Helper method to retrieve the module settings

        Args:
            setid (str): the last component of the setting identifier

        Returns:
            str: the setting value
        """
        if not self.package or not self.provider:
            return ''
        return setting('providers', self.package['name'], self.provider['name'], setid)

    @property
    @abc.abstractmethod
    def info(self):
        """A [list of] dict describing the module.

        The following key, value pairs are available:

        ``content`` (a list of str, mandatory)
            The content that the module can search for (e.g. ``['movie', 'episode']``).
        ``language`` (a list of str, mandatory)
            The languages for which the module can search content represented using
            the ISO_639_1 2-letters codes (e.g. ``['en', 'it']``).
        ``sources`` (a list of str, optional)
            The list of sources handled by the provider itself without the assistance
            of any resolvers module.
        ``name`` (str, optional, default to the module filename)
            The name of the module; useful for modules that return multiple sub-modules.
        ``enabled`` (bool, optional, default to ``True``)
            The module enabled status; if ``False``, it overrides the user setting.
        ``settings`` (list of dict, optional)
            The per-module settings description using the following key, value pairs:

            ``id``  (str, mandatory)
                The last component of the setting name. The full setting name is built prefixing it with
                the 'providers' string and the package name all separated by ':' (e.g. ``providers:<mypackage>::<myid>``).
            ``label`` (str, optional, default to the ``id``)
                The label shown in the settings dialog.
            ``spec`` (str, mandatory)
                The setting specification including the setting ``type`` tag but excluding
                the setting ``id``, ``label``, ``default``, ``visible``, and ``enable`` tags.
            ``default`` (str, optional, default to '')
                The default value for the setting.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def search(self, language, content, meta):
        """Returns a list of matches for the ``meta`` ``content``.

        Args:
            content (str): any of the content supported by the module (e.g. 'movie', 'episode'...);
            language (str): any of the languages supported by the module (e.g. 'en');
            meta (dict): All known meta data about the content to be searched.

        The **meta** dict contains the content meta tags found in the supported databases
        (IMDB, TMDB and TVDB) including:

            For 'movie' content:

                ``title`` (str, mandatory)
                    The title of the movie.
                ``year`` (int, optional)
                    The movie release year.
                ``imdb``, ``tmdb`` (str, optional)
                    The IMDB, TMDB movie identifiers.

            For 'episode' content:

                ``tvshowtitle`` (str, mandatory)
                    The title of the TV show.
                ``year`` (int, optional)
                    The TV show first season release year.
                ``season`` (str, optional)
                    The episode season number.
                ``episode`` (str, optional)
                    The episode number.
                ``imdb``, ``tmdb``, ``tvdb`` (str, optional)
                    The IMDB, TMDB, TVDB TV show identifiers.

        Returns:
            A list of dict: The content matches

        A match dict contains the following key/value:

            ``url`` (str, mandatory)
                The provider significant *URL* to retrieve the content sources.
            ``title`` (str, optional)
                The title of the content as found by the provider module.
                The title is fuzzy matched against the searched title to filter the valid matches.
                If the provider actually retrieve the content in the sources method, it can be omitted.
                In this case, the sources entries can provide the title to be fuzzy matched.
            ``year`` (str or int, optional)
                The release year of the content as found by the provider module.
                If provided, it is checked with an approximation of +/- 1 year to filter the matches.
            ``info`` (str, optional)
                Any info that could be useful to be displayed to the user for any source found
                at the URL reported by this match.

        The ``search`` method can pass additional info to the ``sources`` method by adding further key/value
        pairs. In order to avoid namespace collisions, the keys should be prefixed with a ``_``.

        """
        raise NotImplementedError

    @abc.abstractmethod
    def sources(self, content, language, match):
        """Return a list of dict describing the ``content`` sources found at ``match``.

        Args:
            content (str): any of the content supported by the module (e.g. 'movie', 'episode'...);
            language (str): any of the languages supported by the module (e.g. 'en');
            match (dict): The match returned by the ref:method:`search` to be used for retrieving the content sources.

        Returns:
            A list of dict: The content sources

        The sources contain the following key/values:

            ``url`` (str, mandatory)
                The content source *URL*.
            ``season`` (str or int, optional)
                The season number if the source is an episode.
                If missing, the source is assumed to be valid for all seasons/episodes.
            ``episode`` (str or int, optional)
                The episode number if the source is an episode.
                If missing, the source is assumed to be valid for all seasons/episodes.
            ``title`` (str, optional)
                The title of the content as found by the provider module.
                The title is fuzzy matched against the searched title to filter the valid matches.
                The title should be returned in the sources only if not returned in the matches by the search method.
            ``source`` (str, optional)
                The source server host.
            ``info`` (str, optional)
                Any useful info retrieved from the provider page to be presented to the user
                (e.g. title, stream quality, 3D, MD, SUB, etc.)

        """
        raise NotImplementedError

    def resolve(self, url): #pylint: disable=no-self-use
        """Resolve provider specific source urls.

        Args:
            url (str): The url to be resolved.

        Returns:
            str or ResolvedURL: the resolved *url* or a *url* to be passed to the resolvers

        The *url* resolution ... (fixme): describe the resolve algorithm.

        Raises:
            ResolvedError: if the resolution throws up some exceptions.

        """
        return ResolvedURL(url)


class Provider(ProviderBase):
    """Dummy Provider class for packages' info property probing"""
    info = {}

    def search(self, content, language, meta):
        return []

    def sources(self, content, language, match):
        return []


def create(module, provider=None, package=None):
    if package is None:
        package = provider.package
    adapterclass = package.get('__adapterclass__')
    if not adapterclass:
        apiclass = module.Provider if module else Provider
    else:
        apiclass = getattr(__import__(package['name'], globals(), locals(), [], -1), adapterclass)
    return apiclass(module, provider, package)
