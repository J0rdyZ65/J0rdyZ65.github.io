# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import re
import time
import datetime

from g2 import pkg
from g2 import defs
from g2 import resolvers

from g2.libraries import workers
from g2.libraries import analytics
from g2.libraries.cache import CacheDB

from g2.platforms import log
from g2.platforms import addon
from g2.platforms.settings import content_setting

from .lib.fuzzywuzzy import fuzz
from .api import create


_MIN_FUZZINESS_VALUE = 84
_CHANNEL_COMMAND_ABORT = '___***abort***___'


class Sources(CacheDB):
    def __init__(self, **kwargs):
        super(Sources, self).__init__(
            'rel_src',
            ('key_video', 'language', 'provider'), ('sources',),
            timestamp=True,
            expire=defs.SOURCE_CACHE_LIFETIME*3600,
            version=1)


class Matches(CacheDB):
    def __init__(self, **kwargs):
        super(Matches, self).__init__(
            'rel_url',
            ('key_video', 'language', 'provider'), ('match',),
            timestamp=True,
            expire=defs.MATCH_CACHE_LIFETIME*3600,
            version=1)


def info(package, module=None):
    nfo = create(module, package=package).info
    nfo = [dict(nfo)] if isinstance(nfo, dict) else list(nfo)
    # API: info[content]: enforce a non empty content.
    # API: info[language]: enforce a non empty language.
    return nfo if not module else [i for i in nfo if i.get('content') and i.get('language')]


def content_sources(content, language, meta, ui_update=(lambda *args, **kwargs: time.sleep(1) or True), providers_filter=None):
    all_providers = pkg.info('providers')
    all_packages = set([mi.package_name() for mi in all_providers.itervalues()])
    selected_providers = {}
    for package in all_packages:
        selected_providers[package] = [mi for mi in all_providers.itervalues() if
                                       (not providers_filter or mi.fullname() in providers_filter) and
                                       mi.package_name() == package and
                                       content in mi['content'] and
                                       content in content_setting(mi.package_name(), mi['name']) and
                                       ('*' in mi['language'] or language in mi['language'])]
        if not selected_providers[package]:
            del selected_providers[package]

    num_selected_providers = sum([len(selected_providers.get(p, [])) for p in all_packages])

    log.debug('{m}.{f}: %s/%s selected %d sources out of %d', content, language, num_selected_providers, len(all_providers))

    if not num_selected_providers:
        return None

    all_resolvers = pkg.info('resolvers', include_disabled=True)

    # API meta[year]: optional, non zero int, if present.
    try:
        if not meta['year']:
            del meta['year']
    except Exception:
        pass

    max_concurrent_threads = addon.max_concurrent_threads()

    channel = {}
    sources = {}
    num_completed_providers = 0
    for package, modulesinfo in sorted(selected_providers.items(),
                                       key=lambda it: int(pkg.setting('providers', it[0], name='priority'))):
        modules = sorted(set([mi.module() for mi in modulesinfo]))
        with modulesinfo[0].context(modules) as mods:
            if not mods:
                continue

            threads = []
            for mod, module in zip(mods, modules):
                threads.extend([workers.Thread(_sources_worker,
                                               channel, # for communications between the main thread and the providers threads
                                               mod, # python module object implementing the provider
                                               sm, # provider name in case multiple providers are implemented by the same module
                                               content, language, meta, # video data
                                               all_resolvers, # available resolvers info
                                               name=sm.fullname())
                                for sm in modulesinfo if sm.module() == module])

            log.debug('{m}.{f}: scheduling %s threads for %s sources', len(threads), content)

            scheduled_threads = set()
            while threads or scheduled_threads:
                num_threads_2run = max_concurrent_threads - len([t for t in scheduled_threads if t.is_alive()])
                if num_threads_2run > 0:
                    scheduled_threads |= set([t.start() for t in threads[:num_threads_2run]])
                    del threads[:num_threads_2run]

                completed_threads = sorted([t for t in scheduled_threads if not t.is_alive()], key=lambda t: t.elapsed)
                new_sources = []
                for thd in completed_threads:
                    if thd.exc:
                        log.debug('{m}.{f}: %s: %s %s', thd.name, repr(thd.exc), thd.exc_traceback)
                    provider_sources = False
                    for src in thd.result or []:
                        if src['url'] not in sources:
                            new_sources.append(src)
                            sources[src['url']] = src
                            provider_sources = True
                    if not provider_sources and thd.name in channel:
                        del channel[thd.name]
                    num_completed_providers += 1
                    scheduled_threads.remove(thd)

                try:
                    running_providers = [t.name for t in scheduled_threads]
                    if not ui_update(num_completed_providers, num_selected_providers,
                                     new_sources, running_providers, channel.keys()):
                        channel[_CHANNEL_COMMAND_ABORT] = True
                        log.notice('{m}.{f}: aborted %d threads for %s', len(scheduled_threads)+len(threads), content)
                        return sources.values()
                except Exception as ex:
                    log.notice('{m}.{f}: %s', repr(ex))

    return sources.values()


def _sources_worker(channel, module, provider, content, language, meta, all_resolvers):
    provider_fullname = provider.fullname()
    key_video = _key_video(**meta) #pylint: disable=E0012
    video_match = None
    imdb = meta.get('imdb', 0)
    log.debug('{m}.{f}: %s: searching %s[%s]', provider_fullname, key_video, language)
    if not imdb:
        sourcesdb = matchesdb = None
    else:
        sourcesdb = Sources()
        try:
            sources = sourcesdb[(key_video, language, provider_fullname)]
            log.debug('{m}.{f}: %s: %d sources fetched from the cache', provider_fullname, len(sources))
            return sources
        except KeyError:
            pass
        matchesdb = Matches()
        try:
            video_match = matchesdb[(key_video, language, provider_fullname)]
            log.debug('{m}.{f}: %s: match %s fetched from the cache', provider_fullname, video_match)
        except KeyError:
            pass

    apii = create(module, provider=provider, resolvers=all_resolvers)

    if video_match:
        confidence = 1
    else:
        if _CHANNEL_COMMAND_ABORT in channel:
            log.debug('{m}.{f}: %s: aborted at search', provider_fullname)
            return []

        try:
            elapsed = datetime.datetime.now()
            video_matches = apii.search(content, language, meta)
            elapsed = datetime.datetime.now() - elapsed
            ex = None
        except Exception as ex:
            log.debug('{m}.{f}: %s.search: %s', provider_fullname, repr(ex), trace=True)
            video_matches = []
            elapsed -= elapsed

        confidence, video_match = _video_matches(provider_fullname, content, meta, video_matches)

        analytics.sample(provider_fullname, 'search', content, language, meta,
                         elapsed=elapsed.seconds + elapsed.microseconds / 1000000.,
                         matches=len(video_matches),
                         best=confidence,
                         exc=repr(ex) if ex else None)

        if not video_match:
            return []

        if matchesdb is not None:
            matchesdb[(key_video, language, provider_fullname)] = video_match

    if _CHANNEL_COMMAND_ABORT in channel:
        log.debug('{m}.{f}: %s: aborted at sources', provider_fullname)
        return []

    # The following statement will signal to the UI that a match has been found
    channel[provider_fullname] = True
    try:
        elapsed = datetime.datetime.now()
        sources = apii.sources(content, language, video_match)
        elapsed = datetime.datetime.now() - elapsed
        ex = None
    except Exception as ex:
        log.debug('{m}.{f}: %s: %s: %s', provider_fullname, video_match, repr(ex), trace=True)
        sources = []
        elapsed -= elapsed

    if not sources:
        sources = []

    log.debug('{m}.{f}: %s: %d sources returned', provider_fullname, len(sources))

    for src in sources:
        if not confidence and src.get('title'):
            # API source[title]| if the match title is missing, check it must be checked in each source
            source_confidence, dummy = _best_match(content, [src], meta)
            if source_confidence < _MIN_FUZZINESS_VALUE:
                log.debug('{m}.{f}: %s: no valid source returned (confidence is %d): "%s"',
                          provider_fullname, source_confidence, src)
                src['url'] = ''
                continue
            # API source[info]| Add the source[title] as info tag
            video_match['info'] = src['title']

        src.update({
            'provider': provider_fullname,
            'info': ' '.join([d['info'] for d in (src, video_match) if d.get('info')]),
            })

    # API: source[url]| The url tag must be non empty
    sources = [s for s in sources if s.get('url')]

    # API: source[season, episode]| season and episode tag must be numbers for episode content
    if content == 'episode':
        sources = [s for s in sources if str(s.get('season', 0)).isdigit() and str(s.get('episode', 0)).isdigit()]

    # API source[host]| Match the source url against all the resolvers to identify the source host;
    for src in sources:
        for resolver in all_resolvers.itervalues():
            if resolvers.match(resolver, src['url']):
                src['host'] = resolver['name']
                break
        else:
            # API source[host]| if no resolver matches, fallback to the host/source tag returned by the provider.
            src['host'] = src.get('host', src.get('source', provider['name']))

    sources_groups = {}
    for src in sources:
        sources_groups.setdefault(_key_video(imdb=imdb, **src), []).append(src)

    filtered_sources = []
    for key, srcs in sources_groups.iteritems():
        # (fixme) [OPT] to speed up the sources' search, only the requested movie/episode is stored in the cache
        # Re-evaluate this choice if some additional episodes could be worth to save for binge watchers!
        if key == key_video or key.endswith('/0/0'):
            filtered_sources = srcs
            if sourcesdb is not None:
                sourcesdb[(key, language, provider_fullname)] = srcs

    analytics.sample(provider_fullname, 'sources', content, language, meta,
                     elapsed=elapsed.seconds + elapsed.microseconds / 1000000.,
                     sources=len(filtered_sources),
                     exc=repr(ex) if ex else None)

    log.debug('{m}.{f}: %s: %d valid sources found', provider_fullname, len(filtered_sources))

    return filtered_sources


def _video_matches(provider_fullname, content, meta, video_matches):
    if not video_matches:
        log.debug('{m}.{f}: %s: no matches returned', provider_fullname)
        return 0, None

    if len(video_matches) > 1 or video_matches[0].get('title'):
        confidence, video_match = _best_match(content, video_matches, meta)
        if video_match:
            # API match[info]| Add the title tag the info tag
            video_match['info'] = ' '.join(([video_match['info']] if video_match.get('info') else []) +
                                           [video_match['title']])
            log.debug('{m}.{f}: %s: %d matches returned; best has confidence %s "%s"',
                      provider_fullname, len(video_matches), confidence, video_match['title'])
    else:
        # API match[title]| If only one match is returned *and* the title tag is missing, check the source[title] instead
        confidence = 0
        video_match = video_matches[0]
        log.debug('{m}.{f}: %s: 1 match without title; title filtering is enforced on the sources', provider_fullname)

    if confidence and confidence < _MIN_FUZZINESS_VALUE:
        log.debug('{m}.{f}: %s: no valid matches found', provider_fullname)
        return 0, None

    return confidence, video_match


def _best_match(content, matches, meta):
    try:
        content_year = int(meta.get('year'))
    except Exception:
        content_year = 0

    def match_check_year(match):
        if not content_year:
            return True
        year = 0
        if not year:
            # API match[year]| Check the year using, first, the tag returned by the provider...
            try:
                year = int(match['year'])
            except Exception:
                pass
        if not year:
            # API match[title]| ...otherwise, check for the '(year)' pattern in the title.
            try:
                year = int(re.search(r'\((\d{4})\)', match['title']).group(1))
            except Exception:
                pass
        return True if not year else content_year-1 <= year <= content_year+1

    def clean_title(title):
        if title:
            title = re.sub(r'(^|\s)\(.*\)(\s|$)', r'\1\2', title)
            title = re.sub(r'\[.*\]', '', title)
            title = re.sub(r'(\W)(HD|ITA|SUB)', r'\1', title)
        return title

    def match_confidence(match):
        mtitle = clean_title(match[1]['title'])
        match[0] = _title_fuzzy_compare(mtitle, title)
        return match[0]

    # API match[url, title]| Consider a match if the url and title are not empty and the year
    # API match[url, title]| if known is almost equal to the year retrieved from the databases.
    matches = [[0, m] for m in matches or [] if
               m['url'].strip() and
               m['title'].strip() and
               match_check_year(m)]
    if not matches:
        return (0, {})

    title = meta['title'] if content == 'movie' else meta['tvshowtitle']

    return max(matches, key=match_confidence)


def _title_fuzzy_compare(title1, title2):
    title1 = title1.translate({8211: '-'})
    title2 = title2.translate({8211: '-'})
    ftsr = fuzz.token_sort_ratio(title1, title2)
    if ('-' in title1) == ('-' in title2):
        pass
    elif '-' in title1:
        ftsr = max(ftsr,
                   fuzz.token_sort_ratio(title1.split('-')[0], title2),
                   fuzz.token_sort_ratio(title1.split('-')[1], title2))
    else:
        ftsr = max(ftsr,
                   fuzz.token_sort_ratio(title1, title2.split('-')[0]),
                   fuzz.token_sort_ratio(title1, title2.split('-')[1]))
    return ftsr


def title_fuzzy_equal(title1, title2):
    """Returns True if the ``title1`` is 'fuzzy' equal to ``title2``.

    Args:
        title1 (str): title to compare
        title2 (str): title to compare

    Returns:
        bool: True if the title1 and title2 are 'fuzzy' equal.title2

    The two titles are compared using the fuzzywuzzy token_sort_ratio
    algorithm and they are considered equal if the result is greater than 84.
    If a '-' is present in the title, the title is broken in two parts and
    each part is matched against the other title. The latter to cope with
    titles that include both the original and translated title.
    """
    return _title_fuzzy_compare(title1, title2) >= _MIN_FUZZINESS_VALUE


def clear_sources_cache(meta):
    key_video = _key_video(**meta)
    cleared = False
    try:
        del Sources()[(key_video,)]
        cleared = True
    except Exception:
        pass
    try:
        del Matches()[(key_video,)]
        cleared = True
    except Exception:
        pass
    return cleared


def check_sources_cache(meta):
    key_video = _key_video(**meta)
    try:
        if (key_video,) in Sources():
            return True
    except Exception:
        pass
    try:
        if (key_video,) in Matches():
            return True
    except Exception:
        pass
    return False


def _key_video(**kwargs):
    return '/'.join([str(kwargs.get(k, 0)) for k in ['imdb', 'season', 'episode']])


def resolve(provider_fullname, url, ui_update=lambda *args, **kwargs: time.sleep(0.1) or True):
    # First try the resolution with the resolvers
    rurl = resolvers.resolve(url, ui_update=ui_update)

    # If the resolvers return 'No resolver for', then try to decode the url with the providers' resolve
    if 'No resolver for' in str(rurl):
        try:
            provider = pkg.info('providers')[provider_fullname]
            with provider.context() as modules:
                elapsed = datetime.datetime.now()
                rurl = create(modules[0], provider=provider).resolve(url)
                elapsed = datetime.datetime.now() - elapsed
                elapsed = elapsed.seconds + elapsed.microseconds/1000000.

            if isinstance(rurl, resolvers.ResolvedURL):
                # If the provider resolve method resolved the url, probe it
                rurl = resolvers.probe(rurl)
                if isinstance(rurl, resolvers.ResolvedURL):
                    rurl.enrich(resolver=provider_fullname, elapsed=elapsed)
            elif isinstance(rurl, basestring):
                # If the provider resolve method returns a basestring, give a try again to the resolvers
                rurl = resolvers.resolve(rurl, ui_update=ui_update)
            if not isinstance(rurl, (resolvers.ResolvedURL, resolvers.ResolverError)):
                rurl = (resolvers.ResolverError('%s: resolved url is %s' % (provider_fullname, repr(rurl))) if not rurl else
                        resolvers.ResolverError('%s: %s' % (provider_fullname, str(rurl))))
        except Exception:
            pass

    analytics.sample(provider_fullname, 'resolve', url,
                     elapsed=getattr(rurl, 'elapsed', None),
                     resolver=getattr(rurl, 'resolver', None),
                     exc=repr(rurl) if not isinstance(rurl, resolvers.ResolvedURL) else None)

    return rurl
