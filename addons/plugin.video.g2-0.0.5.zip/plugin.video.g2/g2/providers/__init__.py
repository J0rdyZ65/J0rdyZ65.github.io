# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import re
import sys
import json
import time
import datetime
try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database

from g2.libraries import fs
from g2.libraries import log
from g2.libraries import addon
from g2.libraries import workers

from g2 import pkg
from g2 import defs
from g2 import resolvers

from .lib.fuzzywuzzy import fuzz
from .api import create


_MIN_FUZZINESS_VALUE = 84
_CHANNEL_COMMAND_ABORT = '___***abort***___'


def info(package, module=None):
    nfo = create(module, package=package).info
    nfo = [dict(nfo)] if type(nfo) == dict else list(nfo)
    # API: info[content]: enforce a non empty content.
    # API: info[language]: enforce a non empty language.
    return nfo if not module else [i for i in nfo if i.get('content') and i.get('language')]


def content_sources(content, language, meta, ui_update=(lambda *args, **kwargs: time.sleep(1) or True), providers_filter=None):
    all_providers = pkg.info('providers')
    all_packages = set([mi.package_name() for mi in all_providers.itervalues()])
    selected_providers = {}
    for package in all_packages:
        selected_providers[package] = [mi for mi in all_providers.itervalues() if
                                       (not providers_filter or mi.fullname() in providers_filter) and
                                       mi.package_name() == package and
                                       content in mi['content'] and
                                       content in pkg.content_setting(mi.package_name(), mi['name']) and
                                       ('*' in mi['language'] or language in mi['language'])]
        if not selected_providers[package]:
            del selected_providers[package]

    num_selected_providers = sum([len(selected_providers.get(p, [])) for p in all_packages])

    try:
        max_concurrent_threads = int(addon.setting('max_concurrent_threads'))
    except Exception:
        max_concurrent_threads = defs.MAX_CONCURRENT_THREADS

    # API meta[year]: optional, non zero int, if present.
    try:
        meta['year'] = int(meta['year'])
        if not meta['year']:
            raise Exception
    except Exception:
        if 'year' in meta:
            del meta['year']

    log.debug('{m}.{f}: selected %d sources out of %d', num_selected_providers, len(all_providers))

    channel = {}
    sources = {}
    num_completed_providers = 0
    for package, modulesinfo in sorted(selected_providers.items(),
                                       key=lambda it: int(pkg.setting('providers', it[0], name='priority'))):
        modules = sorted(set([mi.module() for mi in modulesinfo]))
        with modulesinfo[0].context(modules) as mods:
            if not mods:
                continue

            threads = []
            for mod, module in zip(mods, modules):
                threads.extend([workers.Thread(_sources_worker, channel, mod, sm, content, language, meta, name=sm.fullname())
                                for sm in modulesinfo if sm.module() == module])

            log.debug('{m}.{f}: scheduling %s threads for %s sources', len(threads), content)

            scheduled_threads = set()
            while threads or scheduled_threads:
                num_threads_2run = max_concurrent_threads - len([t for t in scheduled_threads if t.is_alive()])
                if num_threads_2run > 0:
                    scheduled_threads |= set([t.start() for t in threads[:num_threads_2run]])
                    del threads[:num_threads_2run]

                completed_threads = sorted([t for t in scheduled_threads if not t.is_alive()], key=lambda t: t.elapsed)
                new_sources = []
                for thd in completed_threads:
                    provider_sources = False
                    for src in thd.result or []:
                        if src['url'] not in sources:
                            new_sources.append(src)
                            sources[src['url']] = src
                            provider_sources = True
                    if not provider_sources and thd.name in channel:
                        del channel[thd.name]
                    num_completed_providers += 1
                    scheduled_threads.remove(thd)

                try:
                    running_providers = [t.name for t in scheduled_threads]
                    if not ui_update(num_completed_providers, num_selected_providers,
                                     new_sources, running_providers, channel.keys()):
                        # Inform all threads to abort ASAP
                        channel[_CHANNEL_COMMAND_ABORT] = True
                        log.notice('{m}.{f}: aborted %d threads for %s', len(scheduled_threads)+len(threads), content)
                        return sources.values()
                except Exception as ex:
                    log.notice('{m}.{f}: %s', repr(ex))

    return sources.values()


def _sources_worker(channel, module, provider, content, language, meta):
    provider_fullname = provider.fullname()
    key_video = _key_video(**meta) # pylint: disable=star-args
    video_match = None
    imdb = meta.get('imdb', '0')
    if imdb == '0':
        dbcon = None
    else:
        try:
            fs.makeDir(addon.PROFILE_PATH)
            dbcon = database.connect(addon.CACHE_DB_FILENAME, timeout=10)
            dbcon.row_factory = database.Row
            dbcon.execute('CREATE TABLE IF NOT EXISTS rel_url'
                          ' (provider TEXT, key_video TEXT, language TEXT, video_match TEXT,'
                          ' UNIQUE(provider, key_video, language))')
            dbcon.execute('CREATE TABLE IF NOT EXISTS rel_src'
                          ' (provider TEXT, key_video TEXT, language TEXT, sources TEXT, timestamp TEXT,'
                          ' UNIQUE(provider, key_video, language));')
            dbcon.commit()
        except Exception:
            pass

        try:
            # Check if the sources are already cached and still valid
            dbcur = dbcon.execute("SELECT * FROM rel_src WHERE provider = ? AND key_video = ? AND language = ?",
                                  (provider_fullname, key_video, language))
            sqlrow = dbcur.fetchone()

            sql_ts = int(str(sqlrow['timestamp']).translate(None, '- :'))
            now_ts = int(datetime.datetime.now().strftime("%Y%m%d%H%M"))
            if (now_ts - sql_ts) / 3600 < defs.SOURCE_CACHE_LIFETIME:
                sources = json.loads(sqlrow['sources'])
                log.debug('{m}.{f}: %s: %d sources found in the cache', provider_fullname, len(sources))
                return sources
        except Exception:
            pass

        try:
            # Check if the video url is already cached [fixme) no expiration?]
            dbcur = dbcon.execute("SELECT * FROM rel_url WHERE provider = ? AND key_video = ? AND language = ?",
                                  (provider_fullname, key_video, language))
            sqlrow = dbcur.fetchone()
            video_match = json.loads(sqlrow['video_match'])
        except Exception:
            pass

    apii = create(module, provider=provider)

    if video_match:
        confidence = 1
    else:
        if _CHANNEL_COMMAND_ABORT in channel:
            log.debug('{m}.{f}: %s: aborted at search', provider_fullname)
            return []

        try:
            video_matches = apii.search(content, language, meta)
        except Exception as ex:
            log.debug('{m}.{f}: %s.search: %s', provider_fullname, repr(ex), trace=True)
            video_matches = None

        if not video_matches:
            log.debug('{m}.{f}: %s: no matches found', provider_fullname)
            return []

        if len(video_matches) > 1 or video_matches[0].get('title'):
            confidence, video_match = _best_match(content, video_matches, meta)
            if video_match:
                log.debug('{m}.{f}: %s: %d matches found; best has confidence %s "%s"',
                          provider_fullname, len(video_matches), confidence, video_match['title'].decode('utf-8'))
        else:
            # API: if only one match is returned *and* the match[title] is missing, check the source[title] instead
            confidence = None
            video_match = video_matches[0]
            log.debug('{m}.{f}: %s: 1 match without title; title filtering is enforced on the sources', provider_fullname)

        if confidence and confidence < _MIN_FUZZINESS_VALUE:
            log.debug('{m}.{f}: %s: no valid matches found', provider_fullname)
            return []

        if video_match and dbcon:
            try:
                with dbcon:
                    dbcon.execute("DELETE FROM rel_url WHERE provider = ? AND key_video = ? AND language = ?",
                                  (provider_fullname, key_video, language))
                    dbcon.execute("INSERT INTO rel_url (provider, key_video, language, video_match) Values (?, ?, ?, ?)",
                                  (provider_fullname, key_video, language, json.dumps(video_match)))
            except Exception as ex:
                log.notice('{m}.{f}: %s: %s|%s: %s', provider_fullname, key_video, language, repr(ex))

    if _CHANNEL_COMMAND_ABORT in channel:
        log.debug('{m}.{f}: %s: aborted at sources', provider_fullname)
        return []

    sources = []
    if video_match:
        # The following statement will signal to the UI that a match has been found by a provider
        channel[provider_fullname] = True
        try:
            sources = apii.sources(content, language, video_match)
        except Exception as ex:
            log.debug('{m}.{f}: %s: %s: %s', provider_fullname, video_match, repr(ex), trace=True)

        if not sources:
            sources = []

    for src in sources:
        if not confidence and src.get('title'):
            # API: check the source[title] if it is missing in the match
            source_confidence, dummy = _best_match(content, [src], meta)
            if source_confidence < _MIN_FUZZINESS_VALUE:
                log.debug('{m}.{f}: no valid source (confidence is %d): "%s"', source_confidence, src)
                src['url'] = ''
                continue
            # API: add to src[info] the src[title] if fuzzy matched
            video_match['info'] = src['title']
        src.update({
            'provider': provider_fullname,
            'source': src.get('source', provider['name']),
            'info': ' '.join([d['info'] for d in (src, video_match) if d.get('info')]),
            })

    # API: sources[url]: ensure non empty url
    sources = [s for s in sources if s.get('url')]

    sources_groups = _sources_groups(imdb, sources).iteritems()
    sources = []
    for key, srcs in sources_groups:
        if dbcon:
            try:
                with dbcon:
                    log.debug('{m}.{f}.%s: %s: saving %d sources', provider, key, len(srcs))
                    dbcon.execute("DELETE FROM rel_src WHERE provider = ? AND key_video = ? and language = ?",
                                  (provider_fullname, key, language))
                    dbcon.execute('INSERT INTO rel_src (provider, key_video, language, sources, timestamp)'
                                  ' Values (?, ?, ?, ?, ?)',
                                  (provider_fullname, key, language, json.dumps(srcs),
                                   datetime.datetime.now().strftime("%Y-%m-%d %H:%M")))
            except Exception as ex:
                log.notice('{m}.{f}: %s: %s|%s: %s', provider_fullname, key, language, repr(ex))
        # For episodes, the sources method might returns additional seasons/episodes, which are saved as well.
        # However, only the sources for the requested season/episode or the generic ones are returned.
        if key == key_video or key.endswith('/0/0'):
            sources = srcs

    log.debug('{m}.{f}: %s: %s|%s: %d sources found', provider_fullname, key_video, language, len(sources))

    return sources


def _best_match(content, matches, meta):
    try:
        content_year = int(meta.get('year'))
    except Exception:
        content_year = 0

    def match_year(year):
        try:
            match_year = int(year)
            if not match_year:
                raise Exception
        except Exception:
            return True
        return content_year-1 <= match_year <= content_year+1

    # API match[url], match[title], match[year]: Discard the matches if...
    matches = [[0, m] for m in matches or [] if
               m['url'].strip() and # ...the url is empty or...
               m['title'].strip() and # ...the title is empty or...
               (not content_year or match_year(m.get('year'))) # ...the year doesn't match!
              ]
    if not matches:
        return (0, {})

    def cleantitle(title):
        if title:
            # Remove anything within () if preceded/followed by spaces
            title = re.sub(r'(^|\s)\(.*\)(\s|$)', r'\1\2', title)
            # Remove anything within []
            title = re.sub(r'\[.*\]', '', title)
            # Remove known keywords
            title = re.sub(r'(\W)(HD|ITA|SUB)', r'\1', title)
        return title

    title = meta['title'] if content == 'movie' else meta['tvshowtitle']

    def match_confidence(match):
        mtitle = cleantitle(match[1]['title'])
        match[0] = _title_fuzzy_compare(mtitle, title)
        return match[0]

    return max(matches, key=match_confidence)


def _title_fuzzy_compare(title1, title2):
    ftsr = fuzz.token_sort_ratio(title1, title2)
    if ('-' in title1) == ('-' in title2):
        pass
    elif '-' in title1:
        ftsr = max(ftsr,
                   fuzz.token_sort_ratio(title1.split('-')[0], title2),
                   fuzz.token_sort_ratio(title1.split('-')[1], title2))
    else:
        ftsr = max(ftsr,
                   fuzz.token_sort_ratio(title1, title2.split('-')[0]),
                   fuzz.token_sort_ratio(title1, title2.split('-')[1]))
    return ftsr


def title_fuzzy_equal(title1, title2):
    """Returns True if the ``title1`` is 'fuzzy' equal to ``title2``.

    Args:
        title1 (str): title to compare
        title2 (str): title to compare

    Returns:
        bool: True if the title1 and title2 are 'fuzzy' equal.title2

    The two titles are compared using the fuzzywuzzy token_sort_ratio
    algorithm and they are considered equal if the result is greater than 84.
    If a '-' is present in the title, the title is broken in two parts and
    each part is matched against the other title. The latter to cope with
    titles that include both the original and translated title.
    """
    return _title_fuzzy_compare(title1, title2) >= _MIN_FUZZINESS_VALUE


def _sources_groups(imdb, sources):
    groups = {}
    for src in sources:
        key_video = _key_video(imdb=imdb, **src) # pylint: disable=star-args
        if key_video not in groups:
            groups[key_video] = []
        groups[key_video].append(src)

    return groups


# (fixme) derive libraries.database.Database class
def clear_sources_cache(**kwargs):
    try:
        key_video = _key_video(**kwargs)
        fs.makeDir(addon.PROFILE_PATH)
        dbcon = database.connect(addon.CACHE_DB_FILENAME, timeout=10)
        with dbcon:
            dbcon.execute("DELETE FROM rel_src WHERE key_video = ?", (key_video,))
            dbcon.execute("DELETE FROM rel_url WHERE key_video = ?", (key_video,))
        return key_video
    except Exception as ex:
        log.error('{m}.{f}: %s: %s', kwargs, repr(ex))
        return None


# (fixme) derive libraries.database.Database class
# (fixme) handle also season/episode as type(int)
def _key_video(**kwargs):
    return '/'.join([kwargs.get(k) or '0' for k in ['imdb', 'season', 'episode']])


def resolve(provider_fullname, url, ui_update=lambda *args, **kwargs: time.sleep(0.1) or True):
    try:
        provider = pkg.info('providers')[provider_fullname]
    except:
        raise Exception('Provider %s not available' % provider_fullname)

    # First try the resolution with the resolvers
    rurl = resolvers.resolve(url, ui_update=ui_update)

    # If the resolvers have sucessfully resolved the url, then bypass the source resolver
    # If the resolvers return any error other than the 'No resolver for', then stop the resolution
    if isinstance(rurl, basestring) or 'No resolver for' not in str(rurl):
        return rurl

    try:
        # Otherwise, try with the provider's resolver
        with provider.context(ignore_exc=True) as modules:
            start_time = datetime.datetime.now()
            url = create(modules[0], provider=provider).resolve(url)
            if isinstance(url, resolvers.ResolvedURL):
                url = resolvers.probe(url)
                if isinstance(url, resolvers.ResolvedURL):
                    elapsed = datetime.datetime.now() - start_time
                    return url.enrich(resolver=provider_fullname, elapsed=elapsed.seconds+elapsed.microseconds/1000000.)
            elif isinstance(url, basestring):
                # If the providers resolve returns basestring, give a try again to the resolvers
                return resolvers.resolve(url, ui_update=ui_update)

            return (resolvers.ResolverError('%s: resolve value is "%s"' % (provider_fullname, url)) if not url else
                    resolvers.ResolverError('%s: %s' % (provider_fullname, str(url))))
    except Exception:
        # On any failure of the provider resolver, return the error of the first resolvers invocation
        return rurl
