# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


#
# D O N T   G E T   E X C I T E D  ! ! !
# T H I S   M O D U L E   S I M P L Y   O P E N S   T H E
# N E T F L I X   A P P L I C A T I O N   O R   W E B   S I T E ! ! !
#


import os
import subprocess

import xbmc


def run(platform, url):
    url = 'https://www.netflix.com/' + (url if url == 'browse' else 'title/' + url)
    if platform == 'android':
        # NOTE: works on Android/Minix
        xbmc.executebuiltin('StartAndroidActivity(com.netflix.mediaclient,android.intent.action.VIEW,,%s)' % url)
        # NOTE: this might require further tuning depending on Android/Platform version
        # opt1: -a android.intent.action.VIEW -d :url: -n com.netflix.mediaclient.ui.launch.UIWebViewActivity
        # opt2: -a android.intent.action.VIEW -d :url: -n com.netflix.mediaclient/.ui.launch.UIWebViewActivity
        # opt3: -c android.intent.category.LEANBACK_LAUNCHER -a android.intent.action.VIEW -d :url: -f 0x10808000 \
        #       -e source 30 com.netflix.ninja/.MainActivity
        # subprocess.call(['adb', 'shell',
        #                  'am', 'start', '-a', 'android.intent.action.VIEW',
        #                  '-d', url, '-n', 'com.netflix.mediaclient.ui.launch.UIWebViewActivity'])
    elif platform == 'linux':
        with open(os.devnull, 'w') as fil:
            subprocess.call(['python', '-m', 'webbrowser', '-t', url], stdout=fil, stderr=fil)

    elif platform == 'windows':
        with open(os.devnull, 'w') as fil:
            subprocess.call(['explorer', url], stdout=fil, stderr=fil)

    else:
        raise Exception('platform %s not supported' % platform)
