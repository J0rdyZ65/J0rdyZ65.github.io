# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2018 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import ast
import sys
import json
import urllib

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from g2.libraries import log
from g2.libraries import addon
from g2.libraries.language import _

from . import d
from . import dialog
from .dialog import busy as busydialog, idle
from .media import addon_icon, addon_poster, addon_banner, addon_thumb, addon_fanart, addon_next, media, resource_themes


_MONITOR = xbmc.Monitor()


Player = xbmc.Player
sleep = xbmc.sleep


def open_settings(addon_id=addon.info('id'), category='0'):
    xbmc.executebuiltin('Addon.OpenSettings(%s)' % addon_id)
    xbmc.executebuiltin('SetFocus(%i)' % (int(category) + 100))
    return xbmcgui.Window(10140)


def open_textviewer():
    xbmc.executebuiltin('ActivateWindow(10147)')
    return xbmcgui.Window(10147)


def abortRequested(timeout=None): # (fixme) #pylint: disable=C0103
    return _MONITOR.waitForAbort(timeout) if timeout else _MONITOR.abortRequested()


def refresh(action=None, **kwargs):
    return xbmc.executebuiltin('Container.Refresh') if not action else \
           xbmc.executebuiltin('Container.Update(%s)'%addon.itemaction(action, **kwargs))


def player_info():
    return (xbmc.getInfoLabel('VideoPlayer.Title'),
            xbmc.getInfoLabel('VideoPlayer.Year'),
            xbmc.getInfoLabel('VideoPlayer.mpaa'),
            xbmc.getInfoLabel('VideoPlayer.IMDBNumber'))
