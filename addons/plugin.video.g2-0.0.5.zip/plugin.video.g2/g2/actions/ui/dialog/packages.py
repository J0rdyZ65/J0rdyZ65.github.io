# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import json

import xbmcgui

from g2 import pkg

from g2.libraries import log
from g2.libraries import addon
from g2.libraries.language import _

from . import progress_bg, busy, idle, ok, yesno, error
from . import EventHandler


class PackagesDialog(xbmcgui.WindowXMLDialog):
    """(fixme)"""
    evh = EventHandler()

    kinds_list_id = 101
    packages_list_id = 201
    close_button_id = 301

    # (fixme) change the arg names
    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback):
        self.kinds = []
        self.packages = []
        self.kinds_lst = None
        self.packages_lst = None
        self.progress_dialog = None
        self.displayed_kind = None
        self.close_button = None

    def add_package(self, kind, name, desc=None, descriptor=''):
        item = xbmcgui.ListItem()
        item.setProperty('kind', kind)
        item.setProperty('name', name)
        item.setLabel(desc or _('[Orphaned] {package}', package=name))
        item.setProperty('descriptor', json.dumps(descriptor))
        self.packages.append(item)
        if kind not in [i.getProperty('kind') for i in self.kinds]:
            item = xbmcgui.ListItem()
            item.setProperty('kind', kind)
            item.setLabel(kind)
            self.kinds.append(item)

    def onInit(self): # Kodi API # pylint: disable=invalid-name
        self.kinds_lst = self.getControl(self.kinds_list_id)
        self.packages_lst = self.getControl(self.packages_list_id)
        self.close_button = self.getControl(self.close_button_id)
        self.close_button.setLabel(_('Close'))
        self.kinds_lst.reset()
        self.kinds_lst.addItems(sorted(self.kinds, key=lambda i: pkg.kinds()[i.getProperty('kind')]['dialog_order']))

        busy()
        for i in self.packages:
            self._update_package_item(i)
        self._update_packages_list('providers')
        idle()

    def onAction(self, action): # Kodi API # pylint: disable=invalid-name
        self.evh.onaction(action, self)
        xbmcgui.WindowXMLDialog.onAction(self, action)

    def onClick(self, control_id): # Kodi API # pylint: disable=invalid-name
        self.evh.onclick(control_id, self)

    @evh.action(evh.ACTION_FOCUS, kinds_list_id)
    def _show_kind_packages_onfocus(self, dummy_control_id):
        kind = self.kinds_lst.getSelectedItem().getLabel().lower()
        self._update_packages_list(kind)

    @evh.click(close_button_id)
    def _close_button(self, dummy_control_id):
        xbmcgui.WindowXMLDialog.close(self)

    @evh.click(kinds_list_id)
    def _show_kind_packages_onclick(self, dummy_control_id):
        kind = self.kinds_lst.getSelectedItem().getLabel().lower()
        self._update_packages_list(kind)

    @evh.click(packages_list_id)
    def _manage_package(self, dummy_control_id):
        item = self.packages_lst.getSelectedItem()
        descriptor = json.loads(item.getProperty('descriptor'))
        if pkg.status(item.getProperty('kind'), item.getProperty('name')) == 'NotInstalled':
            self._install_package(item.getProperty('kind'), item.getProperty('name'), descriptor)
        else:
            self._uninstall_package(item.getProperty('kind'), item.getProperty('name'), descriptor)

        self._update_package_item(item)
        self._update_packages_list(force=True)

    def _update_packages_list(self, kind=None, force=False):
        if self.displayed_kind != kind or force:
            if not kind:
                kind = self.displayed_kind
            self.packages_lst.reset()
            self.packages_lst.addItems([i for i in self.packages if i.getProperty('kind') == kind])
            self.displayed_kind = kind

    @staticmethod
    def _update_package_item(item):
        status = pkg.status(item.getProperty('kind'), item.getProperty('name'))
        item.setInfo('video', {
            'overlay': 5 if status != 'NotInstalled' else 4,
        })
        # Indicator in the Package Manager that the package has raised some exceptions
        item.setLabel2(_('[COLOR red]ERR[/COLOR]') if status == 'RaiseException' else
                       # Indicator in the Package Manager that the package has been disabled by the user
                       _('[COLOR orange]DIS[/COLOR]') if status == 'Disabled' else
                       '' if status == 'NotInstalled' else str(status))

    @staticmethod
    def _install_package(kind, name, descriptor):
        try:
            fullname = kind + '.' + name
            progress_dialog = progress_bg()
            progress_dialog.create(fullname)

            def update_progress_dialog(curitem, numitems=1):
                progress_dialog.update(curitem*100/(numitems if numitems else 1))

            update_progress_dialog(0)
            package = pkg.install(kind, name, descriptor, ui_update=update_progress_dialog)
            progress_dialog.close()

            if not package:
                raise Exception('package %s not installed' % fullname)

            try:
                notice = package['notice'].get(addon.language(), package['notice'].get('en', ''))
                if notice:
                    if isinstance(notice, basestring):
                        notice = [notice]
                    ok(_('PACKAGE MANAGER'), [l.format(package_kind=package['kind'].capitalize(),
                                                       package_name=package['name'].capitalize()) for l in notice])
            except Exception:
                pass

            busy()
            pkg.info(package['kind'], package['name'], force_refresh=True)
            idle()

        except Exception as ex:
            idle()
            progress_dialog.close()
            if 'addons missing' not in str(ex):
                log.error('{m}: %s: %s', fullname, repr(ex))
                error(_('Package installation failed'))
            else:
                ok(_('PACKAGE MANAGER'),
                   [_('The {package_name} package requires these addons:', package_name=fullname),
                    str(ex).split(':')[-1],
                    _('Please, install the missing addons')])

    @staticmethod
    def _uninstall_package(kind, name, descriptor):
        fullname = kind + '.' + name
        if not yesno(_('PACKAGE MANAGER'),
                     [_('About to remove the {package_name} package', package_name=fullname),
                      _('Are you sure?'),
                      '' if descriptor else
                      _('Please note that this package is missing from the packages directory')]):
            return

        try:
            pkg.uninstall(kind, name)

        except Exception as ex:
            log.error('{m}: %s: %s', fullname, repr(ex))
            error(_('Package removal failed'))
