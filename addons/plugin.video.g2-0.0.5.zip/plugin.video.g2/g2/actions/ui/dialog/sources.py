# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2018 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import urlparse

import xbmc
import xbmcgui

from g2 import pkg

from g2.libraries import log
from g2.libraries import addon
from g2.libraries import client
from g2.libraries import workers
from g2.libraries.language import _, xgettext

from ..media import addon_poster
from . import EventHandler, info, busy, idle


class SourcesDialog(xbmcgui.WindowXMLDialog):
    evh = EventHandler()

    title_label_id = 201
    progress_id = 202
    elapsed_label_id = 203
    progress_label_id = 204
    left_image_id = 301
    left_label_id = 302
    sources_list_id = 303
    info_label_id = 402
    counter_label_id = 501
    play_button_id = 502
    start_stop_button_id = 503
    close_button_id = 504

    search_and_resolve_thread_id = 'search&resolve'

    def __init__(self, *_args, **kwargs):
        super(SourcesDialog, self).__init__(self)
        self.dialog_id = None
        self.title_label = None
        self.progress = None
        self.elapsed_label = None
        self.progress_label = None
        self.sources_list = None
        self.counter_label = None
        self.info_label = None
        self.play_button = None
        self.start_stop_button = None
        self.close_button = None

        self.items = []
        self.selected = None
        self.busyresolver = True

        self.content_name = kwargs.get('content_name')
        self.sources_generator = kwargs.get('sources_generator')
        self.source_resolve = kwargs.get('source_resolve')
        self.poster_image = kwargs.get('poster_image')
        self.auto_play = kwargs.get('auto_play')

    def doModal(self):
        super(SourcesDialog, self).doModal()
        return None if not self.selected else {
            'exception': self.selected.getProperty('exception')
        } if self.selected.getProperty('exception') else {
            'url': self.selected.getProperty('url'),
            'provider': self.selected.getProperty('source_provider'),
            'host': self.selected.getProperty('source_host'),
            'format': self.selected.getProperty('format'),
        }

    def delete_selected(self):
        if self.selected:
            self.selected.setProperty('source_url', '')
            self.selected.setProperty('url', '')

    def _select_n_close(self, selected):
        self.selected = selected
        self.close()

    def _except_n_close(self, exc):
        self.selected = xbmcgui.ListItem()
        self.selected.setProperty('exception', exc)
        # NOTE: for some reason the self.close() from within a thread doesn't work
        # while executing the builtin Action(Close) works.
        # self.close()
        xbmc.executebuiltin('Action(Close,%d)'%self.dialog_id)

    def close(self):
        self.evh.join(self.search_and_resolve_thread_id, die=True)
        super(SourcesDialog, self).close()

    def onInit(self): #pylint: disable=C0103
        self.selected = None

        self.dialog_id = xbmcgui.getCurrentWindowDialogId()
        self.title_label = self.getControl(self.title_label_id)
        self.sources_list = self.getControl(self.sources_list_id)
        self.counter_label = self.getControl(self.counter_label_id)
        self.info_label = self.getControl(self.info_label_id)
        self.progress = self.getControl(self.progress_id)
        self.elapsed_label = self.getControl(self.elapsed_label_id)
        self.progress_label = self.getControl(self.progress_label_id)

        self.play_button = self.getControl(self.play_button_id)
        self.start_stop_button = self.getControl(self.start_stop_button_id)
        self.close_button = self.getControl(self.close_button_id)
        left_image = self.getControl(self.left_image_id)
        left_label = self.getControl(self.left_label_id)

        left_image.setImage(self.poster_image or addon_poster())
        left_label.setLabel('' if not self.content_name else
                            self.content_name if isinstance(self.content_name, basestring) else
                            '[CR]'.join(self.content_name))

        if not self.sources_generator:
            self._checking_start_stop_button()
        else:
            self._search_sources(self.sources_generator)
            self.sources_generator = None
            self._resolve_sources()

        self._update_dialog(progress='')
        self.play_button.setLabel(_('Play'))
        self.close_button.setLabel(_('Close'))

    def re_init(self, sources_generator):
        self.sources_generator = sources_generator
        self.items = []

    def onClick(self, control_id): #pylint: disable=C0103
        self.evh.onclick(control_id, self)

    def onAction(self, action):
        self.evh.onaction(action, self)
        super(SourcesDialog, self).onAction(action)

    def onFocus(self, control_id): #pylint: disable=C0103
        self.evh.onfocus(control_id, self)

    @evh.click(sources_list_id)
    @evh.busydialog()
    def _source_item_selected(self, _control_id):
        selected = self.sources_list.getSelectedItem()
        self.evh.join(self.search_and_resolve_thread_id, die=True)
        self._resolver(selected)
        self._update_dialog()
        if not selected.getProperty('url'):
            info(_('Source not valid'))
        else:
            self._select_n_close(selected)

    @evh.click(play_button_id)
    @evh.busydialog()
    def _play(self, _control_id):
        while True:
            selected = self.sources_list.getListItem(0)
            if not selected:
                break
            if selected.getProperty('url'):
                self._select_n_close(selected)
                break
            self.evh.join(self.search_and_resolve_thread_id, die=True)
            self._resolver(selected)
            self._update_dialog()

    @evh.click(start_stop_button_id)
    def _check(self, _control_id):
        if self.evh.is_alive(self.search_and_resolve_thread_id):
            self._update_dialog(focus_play_button=True)
            self.start_stop_button.setEnabled(False)
            self.evh.join(self.search_and_resolve_thread_id, die=True)
        else:
            self._resolve_sources()

    @evh.click(close_button_id)
    def _close_button(self, _control_id):
        self.close()

    @evh.action(evh.ACTION_FOCUS, sources_list_id)
    def _show_source_info(self, _action):
        selected_item = self.sources_list.getSelectedItem()
        if selected_item:
            self.info_label.setLabel(selected_item.getProperty('source_info'))

    @evh.focus(play_button_id)
    def _select_top_source(self, _control_id):
        self.sources_list.selectItem(0)

    @evh.thread(search_and_resolve_thread_id)
    def _search_sources(self, sources_generator):
        log.debug('{m}.{f}: searching sources...')

        def ui_update(progress, total, new_results, running_providers, providers_matches):
            # focus_play_button = not self.items and new_results
            for source in new_results:
                provider = source['provider'].split('.')[-1].lower()
                item = xbmcgui.ListItem()
                source['label'] = '[B]%s[/B] | %s' % (provider, source['source'])
                item.setLabel(source['label'])
                icon = server_icon(source['source']) if source['source'] else None
                if icon:
                    item.setIconImage(icon)
                elif source['source']:
                    item.setLabel2(source['source'])

                item.setProperty('source_provider', source['provider'])
                item.setProperty('source_host', source['source'])
                item.setProperty('source_info', source['info'])
                item.setProperty('source_url', source['url'])
                item.setProperty('url', '')
                item.setProperty('resolution', '0')
                item.setProperty('size', '0')
                self.items.append(item)

            lagger_providers = [] if len(running_providers) > 4 or progress+len(running_providers) < total else running_providers
            self._update_dialog(title=', '.join([p.split('.')[-1] for p in lagger_providers]),
                                progress=(progress, total),
                                providers_matches=providers_matches)
                                # focus_play_button=focus_play_button)

            if self.selected or self.evh.should_i_die():
                return False
            xbmc.sleep(500)
            return True

        self._update_dialog(title=_('SEARCHING SOURCES'))
        self.start_stop_button.setLabel(_('Stop Searching'))
        busy()
        pkg.info('providers')
        idle()
        self.start_stop_button.setEnabled(True)
        sources = sources_generator(ui_update)
        if sources is None:
            self._except_n_close('no-sources-providers-selected')
        elif not sources:
            self._except_n_close('no-sources-found')
        else:
            self._checking_start_stop_button()

    @evh.thread(search_and_resolve_thread_id)
    def _resolve_sources(self):
        log.debug('{m}.{f}: resolving sources: %d found, %d already processed (OK/KO: %d/%d)',
                  len(self.items),
                  len([i for i in self.items if i.getProperty('url') or not i.getProperty('source_url')]),
                  len([i for i in self.items if i.getProperty('url')]),
                  len([i for i in self.items if not i.getProperty('source_url')]))

        if not self.items:
            self._update_dialog(title=_('NO SOURCES FOUND'))
            return

        busy()
        pkg.info('resolvers')
        idle()
        self._update_dialog(title=_('CHECKING SOURCES'))
        self.start_stop_button.setLabel(_('Stop Checking'))
        self.start_stop_button.setEnabled(True)
        all_sources_resolved = False
        while not self.selected and not self.evh.should_i_die():
            all_sources_resolved = True
            for index in range(len(self.items)):
                try:
                    item = self.sources_list.getListItem(index)
                except Exception:
                    break
                if item.getProperty('source_url') and not item.getProperty('url'):
                    all_sources_resolved = False
                    break
            if all_sources_resolved:
                break
            self._resolver(item)
            if self.auto_play and item.getProperty('url'):
                self._select_n_close(item)
                break
            self._update_dialog()

        if all_sources_resolved:
            title = _('SELECT SOURCE')
            progress = _('CHECKING COMPLETE')
        else:
            title = None
            progress = _('CHECKING STOPPED')

        log.debug('{m}.{f}: stopped (%s): %d url listed, %d processed (OK/KO: %d/%d)',
                  'DIALOG CLOSED' if self.selected else progress,
                  len(self.items),
                  len([i for i in self.items if i.getProperty('url') or not i.getProperty('source_url')]),
                  len([i for i in self.items if i.getProperty('url')]),
                  len([i for i in self.items if not i.getProperty('source_url')]))

        self._update_dialog(title=title, progress=progress)
        if all_sources_resolved and not [i for i in self.items if i.getProperty('url')]:
            self._except_n_close('no-valid-sources-available')
        else:
            self._checking_start_stop_button()
            if not [i for i in self.items if i.getProperty('source_url') or i.getProperty('url')]:
                self.setFocus(self.close_button)
            elif not [i for i in self.items if i.getProperty('source_url') and not i.getProperty('url')]:
                self.setFocus(self.play_button)

    def _resolver(self, item):
        provider = item.getProperty('source_provider')
        url = item.getProperty('source_url')
        if item.getProperty('url') or not url or not provider:
            return
        label = item.getLabel()
        label_fmt = xgettext('[COLOR FF009933][{resolver}{ellipsis}][/COLOR] {source}')
        def item_label_update(resolver):
            try:
                item_label_update.ellipsis += 1
            except Exception:
                item_label_update.ellipsis = 0
            if not resolver:
                item.setLabel(_(label_fmt, resolver='', ellipsis='', source=label))
            else:
                item.setLabel(_(label_fmt, resolver=resolver.package.get('nick', ''),
                                ellipsis='.'*(item_label_update.ellipsis%3+1)+' '*(2-item_label_update.ellipsis%3),
                                source=label))
                self._update_dialog()
                xbmc.sleep(500)
            return not self.selected

        res = self.source_resolve(provider, url, ui_update=item_label_update)

        if not res or res.startswith('plugin://'):
            item.setProperty('source_url', '')
            item.setLabel(label)
        else:
            url = res
            item.setProperty('url', str(url))
            media_label = '?'
            if hasattr(url, 'meta') and url.meta:
                if url.meta.get('type'):
                    media_label = url.meta['type']
                    item.setProperty('type', media_label)
                if url.meta.get('width') > 0 and url.meta.get('height') > 0:
                    media_label += ' %sx%s'%(url.meta['width'], url.meta['height'])
                    item.setProperty('resolution', str(url.meta['width']*url.meta['height']))
                item.setProperty('format', media_label)

            if hasattr(url, 'size'):
                if url.size > 0:
                    size_mb = int(url.size / (1024*1024))
                    media_label += ' %dMB'%size_mb if size_mb < 1000 else ' %.1fGB'%(size_mb/1024.)
                item.setProperty('size', str(url.size))

            item.setLabel(_(label_fmt, resolver=media_label.upper(), ellipsis='', source=label))

            if hasattr(url, 'resolver'):
                url_resolver = url.resolver.split('.')
                url_resolver = [url_resolver[0], url_resolver[-1]]
                source_info = (item.getProperty('source_info') + ' ' +
                               _('[COLOR orange][{resolver} in {elapsed:.1f} secs][/COLOR]',
                                 resolver='.'.join(url_resolver),
                                 elapsed=url.elapsed))
                item.setProperty('source_info', source_info)

        log.debug('{m}.{f}: %s: %s'%(label, 'OK' if item.getProperty('url') else 'KO'))

    def _update_dialog(self, title=None, progress=None, providers_matches=None, focus_play_button=False):
        total = None
        if progress is None:
            progress = len([i for i in self.items if i.getProperty('url') or not i.getProperty('source_url')])
            total = len(self.items)
        elif isinstance(progress, (list, tuple)):
            progress, total = progress
        if total:
            self.progress.setPercent(100 * progress / total)
            self.progress_label.setLabel('%d / %d' % (progress, total))
        elif progress:
            self.progress_label.setLabel(progress)
        try:
            self.elapsed_label.setLabel('%ds' % workers.current_thread().elapsed())
        except Exception:
            self.elapsed_label.setLabel('')

        items_active = [i for i in self.items if i.getProperty('source_url')]
        items_active.sort(key=lambda i:
                          source_priority(i.getProperty('source_host'),
                                          i.getProperty('source_provider'),
                                          int(i.getProperty('resolution')),
                                          int(i.getProperty('size'))),
                          reverse=True)

        if (len(items_active) != self.sources_list.size() or
                any(newi.getProperty('source_url') != curi.getProperty('source_url') for newi, curi in
                    zip(items_active, [self.sources_list.getListItem(i) for i in range(0, self.sources_list.size())]))):
            selected = self.sources_list.getSelectedItem()
            if selected:
                selected = selected.getProperty('source_url')
            self.sources_list.reset()
            self.sources_list.addItems(items_active)
            if selected:
                for i in range(0, self.sources_list.size()):
                    if self.sources_list.getListItem(i).getProperty('source_url') == selected:
                        self.sources_list.selectItem(i)
                        break

        if self.items and not items_active:
            self.title_label.setLabel('NO VALID SOURCES')
        elif title:
            self.title_label.setLabel(title)

        counter_label = ''
        providers_sources = set([i.getProperty('source_provider') for i in self.items])
        if providers_sources:
            counter_label += '%d/%d' % (len(items_active), len(providers_sources))
        providers_fetching_sources = len(providers_matches or []) - len(providers_sources or [])
        if providers_fetching_sources > 0:
            counter_label += '(%d)' % providers_fetching_sources
        self.counter_label.setLabel(counter_label)
        self.play_button.setEnabled(len(items_active) > 0)
        if focus_play_button:
            self.setFocus(self.play_button)

    def _checking_start_stop_button(self):
        self.start_stop_button.setLabel(_('Check Sources'))
        items_2resolve = [i for i in self.items if not i.getProperty('url') and i.getProperty('source_url')]
        self.start_stop_button.setEnabled(len(items_2resolve) > 0)


def source_priority(host, provider, resolution=0, size=0):
    def priority_weight(pri):
        return 10**(4-pri) if pri in range(1, 5) else 0

    def size_factor(size):
        return size / (100.*1024*1024)

    def resolution_factor(resolution):
        return resolution / (1.*1024*1024)

    priority = 0
    priority += size_factor(size) * priority_weight(1)
    priority += resolution_factor(resolution) * priority_weight(2)

    if host:
        host = host.split('.')[-1].lower()
        for top in range(1, 10):
            pref = pkg.setting('resolvers', name='preferred_resolver_%d'%top)
            if not pref:
                break
            if  pref.lower() == host:
                if size < 0:
                    return (10 - top) * size_factor(2**32) * priority_weight(1)
                priority += (10 - top) * priority_weight(3)

    if provider:
        provider = provider.split('.')[-1].lower()
        for top in range(1, 10):
            pref = pkg.setting('providers', name='preferred_provider_%d'%top)
            if not pref:
                break
            if pref.lower() == provider:
                priority += (10 - top) * priority_weight(4)

    return priority


def server_icon(server):
    server_icons_dir = _server_icons_directory(server)
    if os.path.exists(os.path.join(server_icons_dir, '')):
        try:
            icon_files = [f for f in os.listdir(server_icons_dir) if os.path.isfile(f)]
            return os.path.join(server_icons_dir, icon_files[0])
        except Exception:
            pass
    return None


def _server_icons_directory(server):
    return os.path.join(addon.PROFILE_PATH, 'servers_icons', server.lower(), '')


def download_servers_icons():
    for server, icon_url in addon.advsettings('serversicons').iteritems():
        icons_dir = _server_icons_directory(server)
        try:
            os.makedirs(icons_dir)
        except Exception:
            pass
        try:
            icon_path = os.path.join(icons_dir, urlparse.urlparse(icon_url).path.split('/')[-1])
            # (fixme) force a re-download if the existing file is older than a certain amount of time
            if not os.path.exists(icon_path):
                with open(icon_path, 'wb') as fil:
                    res = client.get(icon_url)
                    fil.write(res.content)
                    log.debug('{m}.{f}: downloaded %s for %s at %s: %d bytes', icon_path, server, icon_url, len(res.content))

        except Exception as ex:
            log.notice('{m}.{f}: %s: %s', server, repr(ex))
