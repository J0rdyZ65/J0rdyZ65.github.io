# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import time
import json
import datetime
import urlparse

from g2 import pkg
from g2 import defs
from g2 import providers
from g2 import resolvers

from g2.libraries import log
from g2.libraries import addon
from g2.libraries import language
from g2.libraries.language import _

from g2.platforms import videolibrary

from . import ui
from .ui.bookmarks import Bookmarks
from .ui.dialog.sources import SourcesDialog
from .ui.dialog.player import PlayerDialog
from .ui import extplayers
from . import action


@action
def content_language():
    lang = addon.language()
    ui.busydialog()
    mis = [mi for mi in pkg.info('providers').itervalues() if set(['*', lang]) & set(mi['language'])]
    ui.idle()
    ui.dialog.ok('Settings',
                 _('Attention, there are no source providers for the [COLOR orange]{language}[/COLOR] language!',
                   language=language.name(lang)) if not mis else
                 _('There are [COLOR orange]{num}[/COLOR] source providers for the [COLOR orange]{language}[/COLOR] language',
                   num=len(mis), language=language.name(lang)))


@action
def playurl(name, url):
    try:
        if not url:
            return

        def ui_cancel(_resolver):
            ui.sleep(500)
            return not ui.abortRequested(1)

        ui.busydialog()
        res = _resolve(None, url, ui_update=ui_cancel)
        ui.idle()

        if not isinstance(res, basestring):
            raise Exception()

        PlayerDialog().run(name, res)

    except Exception as ex:
        if str(ex):
            log.error('{m}.{f}: %s: %s', url, repr(ex))
        ui.dialog.error(_('Not a valid stream'), heading=name)


@action
def play(name, content, url, meta):
    if not url or not isinstance(resolvers.probe(url), basestring):
        if dialog(name, content, meta) > 0:
            ui.refresh()
        return

    meta = {} if not meta else meta if isinstance(meta, dict) else json.loads(meta)
    if _play_source(name, content, url, [], meta) > 0:
        ui.refresh()


@action
def dialog(name, content, meta):
    meta = json.loads(meta)

    poster = meta.get('poster', '0')
    if poster == '0':
        poster = ui.addon_poster()
    if content == 'episode':
        content_name = [meta['tvshowtitle'], name.decode('utf-8')]
    elif poster == ui.addon_poster():
        content_name = [meta['title']]
    else:
        content_name = None

    def sources_generator(ui_update):
        # (fixme) [INTL] language should be a sources.dialog argument based on the current directory content
        return providers.content_sources(content, language=addon.language(), meta=meta, ui_update=ui_update)

    dlg = SourcesDialog('SourcesDialog.xml', addon.PATH, 'Default', '720p',
                        content_name=content_name,
                        sources_generator=sources_generator,
                        source_resolve=_resolve,
                        poster_image=poster,
                        auto_play=addon.setting('auto_play') == 'true')

    ui.idle()

    res = 0
    play_run = 0
    while True:
        sources_cache_exists = providers.check_sources_cache(**meta)
        item = dlg.doModal()
        if not item:
            break

        if 'exception' in item:
            exc = item['exception']
            if 'no-sources-providers-selected' in exc:
                if ui.dialog.yesno(_('SEARCHING SOURCES'),
                                   [_('No sources providers selected, it could be due to a wrong content language setting'),
                                    _('Do you want to open the settings dialog now?')]):
                    addon.runplugin('tools.settings')
            elif 'no-sources-found' in exc:
                ui.dialog.info(_('No sources available'))
            elif 'no-valid-sources-available' in exc:
                if not sources_cache_exists:
                    ui.dialog.info(_('No sources available'))
                elif ui.dialog.yesno(_('SEARCHING SOURCES'),
                                     [_('No valid sources found, it could be due to stale entries in the sources cache'),
                                      _('Do you want to restart the search after clearing the sources cache?')]):
                    providers.clear_sources_cache(**meta)
                    ui.dialog.info(_('Cache cleared for {video}', video=name))
                    dlg.re_init(sources_generator)
                    continue
            else:
                log.error('{m}.{f}: doModal returned unknown exception: %s', item)
                ui.dialog.error(exc)
            break

        url = item.get('url')
        if url.startswith('extplayer://'):
            try:
                app, path = urlparse.urlparse(url)[1:3]
                extplayers.run(app, path)
                ui.sleep(5000)
            except Exception as ex:
                log.notice('{m}: %s: %s', url, repr(ex))
                ui.dialog.error(_('External player error'))
        else:
            if addon.setting('auto_play') == 'true':
                credits_message = []
            else:
                credits_message = [
                    _('~*~ CREDITS ~*~'),
                    _('{video} loaded in {elapsed_time} seconds', video=name, elapsed_time='{elapsed_time}'),
                    _('Source provided by [UPPERCASE][B]{provider}[/B][/UPPERCASE]',
                      provider=item.get('provider', '???').split('.')[-1]),
                    _('Content hosted by [UPPERCASE][COLOR orange]{host}[/COLOR][/UPPERCASE]', host=item.get('host', '???')),
                    _('Media format is [UPPERCASE][COLOR FF009933]{media_format}[/COLOR][/UPPERCASE]',
                      media_format=item.get('format', '???'))
                ]
            res = _play_source(name, content, url, credits_message, meta, play_run)
            play_run += 1
            if res < 0:
                dlg.delete_selected()
            elif res >= 2:
                ui.refresh()
                break

        dlg.show()

    del dlg

    return res


@action
def clearsourcescache(name, **kwargs):
    key_video = providers.clear_sources_cache(**kwargs)
    if key_video:
        ui.dialog.info(_('Cache cleared for {video}', video=name))


def _play_source(name, content, url, credits_message, meta, play_run=0):
    bookmarks = Bookmarks()
    try:
        offset = bookmarks.get(meta, 0)
        if offset and addon.setting('auto_play') != 'true':
            minutes, seconds = divmod(int(offset), 60)
            hours, minutes = divmod(minutes, 60)
            if ui.dialog.yesno(_('Resume from {hours:02d}:{minutes:02d}:{seconds:02d}',
                                 hours=hours, minutes=minutes, seconds=seconds),
                               name,
                               yeslabel=_('Start from beginning'),
                               nolabel=_('Resume')):
                offset = 0
        log.debug('{m}.{f}: %s: bookmark=%d', name, offset)
    except Exception as ex:
        log.debug('{m}.{f}: %s: %s', name, repr(ex))
        offset = 0

    player = PlayerDialog()
    player_status = player.run(name, url, meta, offset=offset, info=credits_message, play_run=play_run)

    log.debug('{m}.{f}: status=%s, elapsed=%s, imdb=%s', player_status, player.elapsed(), meta.get('imdb', '0'))

    if player_status < 0:
        log.notice('{m}.{f}: %s: %s: invalid source', name, url)
        ui.dialog.error(_('Not a valid stream'), heading=name)
        ui.sleep(2000)
        return -1

    elif player_status >= defs.WATCHED_THRESHOLD:
        del bookmarks[meta]
        if not ui.d.is_watched(content, meta):
            ui.d.watched(content, meta, True)
        return 2

    elif player_status >= defs.BOOKMARK_THRESHOLD:
        bookmarks[meta] = (player.elapsed(), url)
        videolibrary.add(content, meta['title'], meta, url=url)
        return 1

    else:
        return 0


def _resolve(provider, url, ui_update=lambda *args, **kwargs: time.sleep(1) or True):
    start_time = datetime.datetime.now()

    def ui_update_and_timeout(*args, **kwargs):
        return (datetime.datetime.now() - start_time).seconds <= defs.RESOLVER_TIMEOUT and ui_update(*args, **kwargs)

    if not provider:
        res = resolvers.resolve(url, ui_update=ui_update_and_timeout)
    else:
        res = providers.resolve(provider, url, ui_update=ui_update_and_timeout)

    elapsed_time = datetime.datetime.now() - start_time
    extrainfo = ''
    if 'UI cancelled' in str(res):
        what = 'timeout after' if elapsed_time.seconds > defs.RESOLVER_TIMEOUT else 'cancelled by the user after'
        res = None
    elif not isinstance(res, basestring):
        what = 'not resolved after'
        extrainfo = ' ' + str(res)
        res = None
    else:
        what = 'successfully resolved in'
        extrainfo = ' by %s, meta: %s' % (
            '???' if not hasattr(res, 'resolver') else res.resolver,
            '???' if not hasattr(res, 'meta') else res.meta)

    log.debug('{m}: %s: %s: %s %.1f secs%s',
              provider, url, what, elapsed_time.seconds + elapsed_time.microseconds / 1000000., extrainfo)

    return res
