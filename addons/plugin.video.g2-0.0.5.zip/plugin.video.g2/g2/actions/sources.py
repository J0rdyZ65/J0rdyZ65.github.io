# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import os
import time
import datetime
import urlparse

from g2 import pkg
from g2 import dbs
from g2 import defs
from g2 import providers
from g2 import resolvers

from g2.libraries import log
from g2.libraries import client
from g2.libraries import language
from g2.libraries import advsettings
from g2.libraries.language import _

from g2.platforms import ui
from g2.platforms import addon
from g2.platforms import actions
from g2.platforms import extplayers
from g2.platforms.ui.dialog.sources import SourcesDialog
from g2.platforms.ui.dialog.player import PlayerDialog
from g2.platforms.actions import action

from .lib.bookmarks import Bookmarks


_SERVERS_ICONS_EXPIRE_TIME = (60*60*24*30) # 30days


@action()
def content_language():
    lang = addon.content_language()
    ui.busydialog()
    mis = [mi for mi in pkg.info('providers').itervalues() if set(['*', lang]) & set(mi['language'])]
    ui.idle()
    ui.dialog.ok('Settings',
                 _('Attention, there are no source providers for the [COLOR orange]{language}[/COLOR] language!',
                   language=language.name(lang)) if not mis else
                 _('There are [COLOR orange]{num}[/COLOR] source providers for the [COLOR orange]{language}[/COLOR] language',
                   num=len(mis), language=language.name(lang)))


@action(str, dict)
def play(content, meta):
    meta = meta or {}
    bookmarks = Bookmarks()
    if meta in bookmarks:
        bookmarktime, url = bookmarks[meta].values()
        if isinstance(resolvers.probe(url), basestring) and _play_source(meta['title'], content, url, [], meta) > 0:
            ui.refresh()
            return
        if url:
            bookmarks[meta] = (bookmarktime, '')

    poster = meta.get('poster') or ui.addon_poster()
    if content == 'episode':
        content_name = [meta['tvshowtitle'], meta['title']]
    elif poster == ui.addon_poster():
        content_name = [meta['title']]
    else:
        content_name = None

    def sources_generator(ui_update):
        # (fixme) [INTL] language should be an argument based on the current directory content language
        return providers.content_sources(content, language=addon.content_language(), meta=meta, ui_update=ui_update)

    dlg = SourcesDialog('SourcesDialog.xml', addon.info('path'), 'Default', '720p',
                        content_name=content_name,
                        sources_generator=sources_generator,
                        source_priority=_source_priority,
                        source_resolve=_source_resolve,
                        poster_image=poster,
                        auto_play=addon.setting('auto_play') == 'true',
                        host_icon=_host_icon)

    ui.idle()

    res = 0
    play_run = 0
    while True:
        sources_cache_exists = providers.check_sources_cache(meta)
        item = dlg.doModal()
        if not item:
            break

        if 'exception' in item:
            exc = item['exception']
            if 'no-sources-providers-selected' in exc:
                if ui.dialog.yesno(_('SEARCHING SOURCES'),
                                   [_('No sources providers selected, it could be due to a wrong content language setting'),
                                    _('Do you want to open the settings dialog now?')]):
                    actions.run('tools.settings')
            elif 'no-sources-found' in exc:
                ui.dialog.info(_('No sources available'))
            elif 'no-valid-sources-available' in exc:
                if not sources_cache_exists:
                    ui.dialog.info(_('No sources available'))
                elif ui.dialog.yesno(_('SEARCHING SOURCES'),
                                     [_('No valid sources found, it could be due to stale entries in the sources cache'),
                                      _('Do you want to restart the search after clearing the sources cache?')]):
                    providers.clear_sources_cache(meta)
                    ui.dialog.info(_('Cache cleared for {video}', video=meta['title']))
                    dlg.re_init(sources_generator)
                    continue
            else:
                log.error('{m}.{f}: doModal returned unknown exception: %s', item)
                ui.dialog.error(exc)
            break

        url = item.get('url')
        if addon.setting('auto_play') == 'true':
            credits_message = []
        else:
            credits_message = [
                _('~*~ CREDITS ~*~'),
                _('{video} loaded in {elapsed_time} seconds', video=meta['title'], elapsed_time='{elapsed_time}'),
                _('Source provided by [UPPERCASE][B]{provider}[/B][/UPPERCASE]',
                  provider=item.get('provider', '???').split('.')[-1]),
                _('Content hosted by [UPPERCASE][COLOR orange]{host}[/COLOR][/UPPERCASE]', host=item.get('host', '???')),
                _('Media format is [UPPERCASE][COLOR FF009933]{media_format}[/COLOR][/UPPERCASE]',
                  media_format=item.get('format', '???'))
            ]
        res = _play_source(meta['title'], content, url, credits_message, meta, play_run)
        play_run += 1
        if res < 0:
            dlg.delete_selected()
        elif res >= 2:
            ui.refresh()
            break

        dlg.show()

    del dlg

    return res


@action(str, dict, bool)
def watched(content, meta, seen):
    dbs.watched(content, meta, seen)
    ui.refresh()


@action(str, dict)
def clearsourcescache(name, meta):
    key_video = providers.clear_sources_cache(meta)
    if key_video:
        ui.dialog.info(_('Cache cleared for {video}', video=name))


def _play_source(name, content, url, credits_message, meta, play_run=0):
    bookmarks = Bookmarks()
    if url.startswith('extplayer://'):
        try:
            extplayers.run(url)
            ui.sleep(5000)
            player_status = defs.BOOKMARK_THRESHOLD
            offset = 0
        except Exception as ex:
            log.error('{m}: %s: %s', url, repr(ex))
            player_status = _('External player error')
    else:
        try:
            offset = bookmarks.get(meta, (0,))['bookmarktime']
            if offset and addon.setting('auto_play') != 'true':
                minutes, seconds = divmod(int(offset), 60)
                hours, minutes = divmod(minutes, 60)
                if ui.dialog.yesno(_('Resume from {hours:02d}:{minutes:02d}:{seconds:02d}',
                                     hours=hours, minutes=minutes, seconds=seconds),
                                   name,
                                   yeslabel=_('Start from beginning'),
                                   nolabel=_('Resume')):
                    offset = 0
            log.debug('{m}.{f}: %s: bookmark=%d', name, offset)
        except Exception as ex:
            offset = 0
            log.debug('{m}.{f}: %s: %s', name, repr(ex))

        player = PlayerDialog()
        player_status = player.run(name, url, meta, offset=offset, info=credits_message, play_run=play_run)
        if player_status >= 0:
            offset = player.elapsed()
        else:
            log.error('{m}: %s: invalid stream', url)
            player_status = _('Not a valid stream')

    if isinstance(player_status, basestring):
        ui.dialog.error(player_status, heading=name)
        ui.sleep(2000)
        return -1

    if player_status >= defs.WATCHED_THRESHOLD:
        del bookmarks[meta]
        dbs.watched(content, meta, True)
        return 2

    if player_status >= defs.BOOKMARK_THRESHOLD:
        bookmarks[meta] = (offset, url)
        return 1

    return 0


def _source_priority(host, provider, resolution=0, size=0):
    def priority_weight(pri):
        return 10**(4-pri) if pri in range(1, 5) else 0

    def size_factor(size):
        return size / (100.*1024*1024)

    def resolution_factor(resolution):
        return resolution / (1.*1024*1024)

    priority = 0
    priority += size_factor(size) * priority_weight(1)
    priority += resolution_factor(resolution) * priority_weight(2)

    if host:
        host = host.split('.')[-1].lower()
        for top in range(1, 10):
            pref = pkg.setting('resolvers', name='preferred_resolver_%d'%top)
            if not pref:
                break
            if  pref.lower() == host:
                if size < 0:
                    return (10 - top) * size_factor(2**32) * priority_weight(1)
                priority += (10 - top) * priority_weight(3)

    if provider:
        provider = provider.split('.')[-1].lower()
        for top in range(1, 10):
            pref = pkg.setting('providers', name='preferred_provider_%d'%top)
            if not pref:
                break
            if pref.lower() == provider:
                priority += (10 - top) * priority_weight(4)

    return priority


def _source_resolve(provider, url, ui_update=lambda *args, **kwargs: time.sleep(1) or True):
    start_time = datetime.datetime.now()

    def ui_update_and_timeout(*args, **kwargs):
        return (datetime.datetime.now() - start_time).seconds <= defs.RESOLVER_TIMEOUT and ui_update(*args, **kwargs)

    if not provider:
        res = resolvers.resolve(url, ui_update=ui_update_and_timeout)
    else:
        res = providers.resolve(provider, url, ui_update=ui_update_and_timeout)

    elapsed_time = datetime.datetime.now() - start_time
    extrainfo = ''
    if 'UI cancelled' in str(res):
        what = 'timeout after' if elapsed_time.seconds > defs.RESOLVER_TIMEOUT else 'cancelled by the user after'
        res = None
    elif not isinstance(res, basestring):
        what = 'not resolved after'
        extrainfo = ' ' + str(res)
        res = None
    else:
        what = 'successfully resolved in'
        extrainfo = ' by %s, meta: %s' % (
            '???' if not hasattr(res, 'resolver') else res.resolver,
            '???' if not hasattr(res, 'meta') else res.meta)

    log.debug('{m}: %s: %s: %s %.1f secs%s',
              provider, url, what, elapsed_time.seconds + elapsed_time.microseconds / 1000000., extrainfo)

    return res


def _host_icon(server):
    icons_dir = _host_icons_directory(server)
    if os.path.exists(os.path.join(icons_dir, '')):
        try:
            icon_files = [f for f in os.listdir(icons_dir) if os.path.isfile(os.path.join(icons_dir, f))]
            return os.path.join(icons_dir, icon_files[0])
        except Exception:
            pass
    return None


def download_hosts_icons():
    for server, icon_url in advsettings.setting('hosts_icons').iteritems():
        icons_dir = _host_icons_directory(server)
        try:
            os.makedirs(icons_dir)
        except Exception:
            pass
        try:
            icon_path = os.path.join(icons_dir, urlparse.urlparse(icon_url).path.split('/')[-1])
            if not os.path.exists(icon_path) or time.time() - os.stat(icon_path).st_mtime > _SERVERS_ICONS_EXPIRE_TIME:
                with open(icon_path, 'wb') as fil:
                    res = client.get(icon_url)
                    fil.write(res.content)
                    log.debug('{m}.{f}: downloaded %s for %s at %s: %d bytes', icon_path, server, icon_url, len(res.content))

        except Exception as ex:
            log.notice('{m}.{f}: %s: %s', server, repr(ex))

def _host_icons_directory(server):
    return os.path.join(addon.info('profile'), 'hosts_icons', server.lower(), '')
