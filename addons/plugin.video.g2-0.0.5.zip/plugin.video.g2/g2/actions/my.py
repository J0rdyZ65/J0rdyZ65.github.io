# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from g2.libraries.language import _
from g2 import dbs

from g2.platforms import ui
from g2.platforms import addon

from . import action


@action
def menu():
    trakt_user = addon.setting('trakt_user')
    if not trakt_user or addon.setting('trakt_enabled') != 'true':
        ui.d.add(_('Configure your Trakt account'), 'moviesTraktcollection', 'DefaultMovies.png',
                 'tools.settings', category=1, is_folder=False)
    else:
        ui.d.add(_('[B]TRAKT[/B] : Collection'), 'moviesTraktcollection', 'DefaultMovies.png',
                 'movies.movielist', url=dbs.resolve('movies_collection{trakt_user_id}', trakt_user_id=trakt_user))
        ui.d.add(_('[B]TRAKT[/B] : Watchlist'), 'moviesTraktwatchlist', 'DefaultMovies.png',
                 'movies.movielist', url=dbs.resolve('movies_watchlist{trakt_user_id}', trakt_user_id=trakt_user))
        ui.d.add(_('[B]TRAKT[/B] : Ratings'), 'moviesTraktrated', 'DefaultMovies.png',
                 'movies.movielist', url=dbs.resolve('movies_ratings{trakt_user_id}', trakt_user_id=trakt_user))
        ui.d.add(_('[B]TRAKT[/B] : Recommendations'), 'moviesTraktrecommendations', 'DefaultMovies.png',
                 'movies.movielist', url=dbs.resolve('movies_recommendations{}'))
        ui.d.add(_('[B]TRAKT[/B] : Lists by {trakt_user}', trakt_user=trakt_user), 'movieUserlists', 'DefaultMovies.png',
                 'movies.lists', kind_user_id='trakt_user_id', kind_list_id='trakt_list_id', user_id=trakt_user)

    imdb_user = addon.setting('imdb_user')
    if not imdb_user:
        ui.d.add(_('Configure your IMDB account'), 'movieUserlists', 'DefaultMovies.png',
                 'tools.settings', category=1, is_folder=False)
    else:
        imdb_nickname = addon.setting('imdb_nickname') or imdb_user
        ui.d.add(_('[B]IMDB[/B] : Lists by {imdb_nickname}', imdb_nickname=imdb_nickname), 'movieUserlists', 'DefaultMovies.png',
                 'movies.lists', kind_user_id='imdb_user_id', kind_list_id='imdb_list_id', user_id=imdb_user)

    ui.d.end()
