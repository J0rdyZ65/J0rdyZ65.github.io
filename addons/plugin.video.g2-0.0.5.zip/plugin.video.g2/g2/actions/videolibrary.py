# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2018-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

from g2.libraries import log
from g2.libraries.language import _

from g2 import dbs

from g2.platforms import videolibrary
from g2.platforms import ui
from g2.platforms.actions import action


@action(str, str, dict)
def update(content, title=None, meta=None):
    meta = meta or {}
    scan = content != 'tvshow'
    if not scan:
        for tvshowtitle, added_episodes in videolibrary.update(content, title, meta, dbs.meta):
            ui.dialog.info(_('TV show {tvshowtitle}: {added_episodes} episode(s) added',
                             tvshowtitle=tvshowtitle, added_episodes=added_episodes), time=3000)
            log.notice('{m}.{f}: tvshow "%s": %s episode(s) added', tvshowtitle, added_episodes)
            scan = True
    if scan:
        videolibrary.scan()
