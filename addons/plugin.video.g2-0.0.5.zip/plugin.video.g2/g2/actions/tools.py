# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import os

from g2 import pkg
from g2.libraries import log
from g2.libraries import cache
from g2.libraries import advsettings
from g2.libraries.language import _
from g2.pkg.instarget import InsTargetNamedSettings

from g2.platforms import ui
from g2.platforms import addon
from g2.platforms.ui.dialog.packages import PackagesDialog

from .lib import action


@action
def menu():
    ui.d.add(_('Settings'), 'settings', 'DefaultAddonProgram.png', 'tools.settings', is_folder=False)
    ui.d.add(_('Advanced Settings'), 'tools', 'DefaultAddonProgram.png', 'tools.advanced_settings', is_folder=False)
    ui.d.add(_('Package Manager'), 'tools', 'DefaultAddonProgram.png', 'tools.package_manager', is_folder=False)
    ui.d.add(_('Clear Cache'), 'cache', 'DefaultAddonProgram.png', 'tools.clearcache', is_folder=False)
    ui.d.add(_('Update library'), 'tools', 'DefaultAddonProgram.png', 'videolibrary.update', content='tvshows', is_folder=False)
    ui.d.add(_('[COLOR red]Factory Reset[/COLOR]'), 'tools', 'DefaultAddonProgram.png', 'tools.factory_reset', is_folder=False)
    ui.d.end()


@action
def settings(category='0'):
    ui.open_settings(category=category)


@action
def advanced_settings():
    site = ui.dialog.keyboard(_('Advanced settings source'), history='advancedsettings-url')
    if not site:
        return
    source = pkg.src.create(site)
    if not source:
        ui.dialog.error(_('Advanced settings source is wrong or not supported'))
        return
    length = InsTargetNamedSettings(source, 'profile').install()
    if not length:
        ui.dialog.error(_('Advanced settings installation failed'))
    else:
        ui.dialog.info(_('Installed advanced settings [{length}]', length=length))

    ui.dialog.busy()
    pkg.update_settings_skema()
    ui.dialog.idle()


@action
def package_manager():
    dlg = PackagesDialog('PackagesDialog.xml', addon.info('path'), 'Default', '720p')

    listed = {}
    for fullname, pkgdesc in advsettings.setting('packages').iteritems():
        try:
            kind, name = fullname.split('.')
            desc, descriptor = pkgdesc

            if kind not in pkg.kinds():
                log.notice('{m}.{f}: package kind not implemented: %s', kind)
                continue

            if not pkg.src.create(descriptor):
                log.notice('{m}.{f}: package descriptor not implemented: %s', descriptor)
                continue

            dlg.add_package(kind, name, desc, descriptor)
            listed[fullname] = True
        except Exception:
            pass

    dlg.doModal()

    del dlg

    ui.dialog.busy()
    pkg.update_settings_skema()
    ui.dialog.idle()


@action
def clearcache():
    if ui.dialog.yesno(_('Clear Cache'),
                       _('Are you sure to clear the entire cache?')):
        try:
            cache.clear()
            ui.dialog.info(_('Cache cleared'))
        except Exception as ex:
            log.error('{m}.{f}: %s', repr(ex))
            ui.dialog.error(_('Cache clearing FAILED'))


@action
def updatemedia():
    appearance = addon.setting('appearance')
    themes = ui.resource_themes()
    if appearance.lower() not in themes:
        appearance = '-'
        addon.setting('appearance', appearance)

    if pkg.settings.update_appearance_setting_skema(themes):
        ui.dialog.info(_('{g2} media setting skema updated', g2=addon.info('name')))

    settings()


@action
def factory_reset():
    def remove(dirname, remove_dir=False):
        for name in os.listdir(dirname):
            if os.path.isdir(os.path.join(dirname, name)):
                remove(os.path.join(dirname, name), remove_dir=True)
            else:
                os.remove(os.path.join(dirname, name))
        if remove_dir:
            os.rmdir(dirname)

    if ui.dialog.yesno(_('[COLOR red]Factory Reset[/COLOR]'),
                       [_('Are you sure to remove all the personal data?'),
                        _('This action will clear all the cached information,'),
                        _('including the metadata, the settings, the bookmarks...'),],
                       yeslabel=_('[COLOR red]Yes[/COLOR]')):
        try:
            remove(addon.info('profile'))
            ui.dialog.info(_('{g2} factory reset completed', g2=addon.info('name')))
        except Exception as ex:
            log.error('{m}.{f}: %s', ex, trace=True)
            ui.dialog.error(_('Factory reset FAILED'))
