# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import os

from g2 import pkg
from g2.libraries import cache
from g2.libraries import advsettings

from g2.platforms import ui
from g2.platforms import log
from g2.platforms import addon
from g2.platforms import settings
from g2.platforms.language import _
from g2.platforms.actions import action
from g2.platforms.ui.dialog.packages import PackagesDialog


@action()
def menu():
    ui.d.add(_('Settings'), 'settings', 'DefaultAddonProgram.png', 'tools.addonsettings', is_folder=False)
    ui.d.add(_('Advanced Settings'), 'tools', 'DefaultAddonProgram.png', 'tools.advancedsettings', is_folder=False)
    ui.d.add(_('Package Manager'), 'tools', 'DefaultAddonProgram.png', 'tools.packagemanager', is_folder=False)
    ui.d.add(_('Clear Cache'), 'cache', 'DefaultAddonProgram.png', 'tools.clearcache', is_folder=False)
    ui.d.add(_('Update library'), 'tools', 'DefaultAddonProgram.png', 'videolibrary.update', content='tvshows', is_folder=False)
    ui.d.add(_('[COLOR red]Factory Reset[/COLOR]'), 'tools', 'DefaultAddonProgram.png', 'tools.factoryreset', is_folder=False)
    ui.d.end()


@action(int)
def addonsettings(category=0):
    ui.dialog.addon_settings(category)


@action()
def advancedsettings():
    site = ui.dialog.keyboard(_('Advanced settings source'), history='advancedsettings-url')
    if site:
        try:
            source = pkg.sources.create(site)
            length = pkg.instargets.create('profile').install(source)
            if not length:
                raise Exception('wrong or unsupported source')
            log.notice('{m}.{f}: %s: installed [%d]', site, length)
            ui.dialog.info(_('Successfully installed advanced settings [{length}]', length=length))
        except Exception as ex:
            log.error('{m}.{f}: %s: %s', site, repr(ex))
            ui.dialog.error(_('Failed advanced settings installation'))
            return

        ui.dialog.busy()
        settings.update_skema()
        ui.dialog.idle()


@action()
def packagemanager():
    dlg = PackagesDialog('PackagesDialog.xml', addon.info('path'), 'Default', '720p')

    listed = {}
    for fullname, pkgdesc in advsettings.setting('packages').iteritems():
        try:
            kind, name = fullname.split('.')
            desc, descriptor = pkgdesc
            pkg.sources.create(descriptor)
            dlg.add_package(kind, name, desc, descriptor)
            listed[fullname] = True
        except Exception as ex:
            log.error('{m}.{f}: %s: %s', fullname, ex, trace=True)

    dlg.doModal()

    del dlg

    ui.dialog.busy()
    settings.update_skema()
    ui.dialog.idle()


@action()
def clearcache():
    if ui.dialog.yesno(_('Clear Cache'),
                       _('Are you sure to clear the entire cache?')):
        try:
            cache.clear()
            ui.dialog.info(_('Cache cleared'))
        except Exception as ex:
            log.error('{m}.{f}: %s', repr(ex))
            ui.dialog.error(_('Cache clearing FAILED'))


@action()
def updatemedia():
    appearance = addon.setting('appearance')
    themes = ui.resource_themes()
    if appearance.lower() not in themes:
        appearance = '-'
        addon.setting('appearance', appearance)

    if settings.update_appearance_skema(themes):
        ui.dialog.info(_('{g2} media setting skema updated', g2=addon.info('name')))

    ui.dialog.addon_settings()


@action()
def factoryreset():
    def remove(dirname, remove_dir=False):
        for name in os.listdir(dirname):
            if os.path.isdir(os.path.join(dirname, name)):
                remove(os.path.join(dirname, name), remove_dir=True)
            else:
                os.remove(os.path.join(dirname, name))
        if remove_dir:
            os.rmdir(dirname)

    if ui.dialog.yesno(_('[COLOR red]Factory Reset[/COLOR]'),
                       [_('Are you sure to remove all the personal data?'),
                        _('This action will clear all the cached information,'),
                        _('including the metadata, the settings, the bookmarks...'),],
                       yeslabel=_('[COLOR red]Yes[/COLOR]')):
        try:
            remove(addon.info('profile'))
            ui.dialog.info(_('{g2} factory reset completed', g2=addon.info('name')))
        except Exception as ex:
            log.error('{m}.{f}: %s', ex, trace=True)
            ui.dialog.error(_('Factory reset FAILED'))
