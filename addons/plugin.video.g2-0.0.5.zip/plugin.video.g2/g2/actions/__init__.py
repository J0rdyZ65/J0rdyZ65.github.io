# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import datetime

from g2.libraries import log
from g2.platforms import addon


def execute(action, kwargs=None):
    kwargs = kwargs or {}

    log.debug('{m}.{f}: ACTION:%s, #ARGS:%d', action, len(kwargs))
    for key, arg in kwargs.iteritems():
        if not isinstance(arg, dict):
            arg = repr(arg)
            log.debug('{m}.{f}: ARG: %s=%.80s%s [%d]', key, arg, '' if len(arg) <= 80 else '...', len(arg))
        else:
            for skey, sarg in arg.iteritems():
                log.debug('{m}.{f}: ARG: %s.%s=%.80s', key, skey, repr(sarg))

    try:
        module, function = action.split('.')
        module = __import__(module, globals(), locals(), [], -1)
        if not hasattr(module, function):
            raise Exception('missing action function')
        function = getattr(module, function)
        if not hasattr(function, 'is_action'):
            raise Exception('action function is not decorated')
        elapsed = datetime.datetime.now()
        function(**kwargs)
        elapsed = datetime.datetime.now() - elapsed
        log.debug('{m}.{f}: ACTION:%s completed in %.2f secs', action, elapsed.seconds + elapsed.microseconds/1000000.)
    except Exception as ex:
        log.error('{m}.{f}: %s: %s', action, ex, trace=True)
