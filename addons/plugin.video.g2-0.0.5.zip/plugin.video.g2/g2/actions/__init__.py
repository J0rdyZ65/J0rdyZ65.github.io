# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import sys

from g2.libraries import log
from g2.libraries import addon

from g2 import pkg

from . import ui


def action(func):
    func.is_action = True
    return func


def busyaction(func):
    def func_wrapper(*args, **kwargs):
        ui.busydialog()
        func(*args, **kwargs)
        ui.idle()
    func_wrapper.is_action = True
    return func_wrapper


def execute(act, kwargs=None):
    """Execute the plugin actions"""
    if kwargs is None:
        kwargs = {}

    log.debug('{m}.{f}: tID:%s, ACTION:%s, #ARGS:%d', sys.argv[1], act, len(kwargs))
    for key, value in kwargs.iteritems():
        if value == addon.URL_EMPTY_ARG:
            kwargs[key] = ''
        elif value == addon.URL_NONE_ARG:
            kwargs[key] = None
        log.debug('{m}.{f}: ARG: %s=%.80s', key, value)

    try:
        module, act = act.split('.')
        mod = __import__(module, globals(), locals(), [], -1)
        if not hasattr(mod, act):
            raise Exception('missing action function')
        function = getattr(mod, act)
        if not hasattr(function, 'is_action'):
            raise Exception('action function is not decorated')
        function(**kwargs) #pylint: disable=E0012
    except Exception as ex:
        log.error('{m}.{f}: %s: %s', act, ex, trace=True)
