# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

from g2 import dbs

from g2.platforms import ui
from g2.platforms import addon
from g2.platforms import actions
from g2.platforms import videolibrary
from g2.platforms.language import _
from g2.platforms.actions import action

from .lib.bookmarks import Bookmarks


@action()
def menu():
    if Bookmarks('episode'):
        ui.d.add(_('Keep Watching'), 'tvshowsUserlists', 'DefaultTVShows.png', 'tvshows.bookmarked')

    ui.d.add(_('Recommendations [[UPPERCASE]{provider}[/UPPERCASE]]',
               provider=dbs.resolve('tvshows_recommendations{}', dbsopt_provider=True)),
             'tvshowsRecommendations', 'DefaultTVShows.png', 'tvshows.tvshowlist', url=dbs.resolve('tvshows_recommendations{}'))

    ui.d.add(_('Search by Title'), 'tvshowSearch', 'DefaultTVShows.png', 'tvshows.searchbytitle', is_folder=False)
    ui.d.add(_('Search by Year'), 'tvshowYear', 'DefaultYear.png', 'tvshows.searchbyyear', is_folder=False)

    ui.d.add(_('Genres'), 'tvshowGenres', 'DefaultGenre.png', 'tvshows.genres')

    ui.d.add(_('Featured'), 'tvshows', 'DefaultTVShows.png',
             'tvshows.tvshowlist', url=dbs.resolve('tvshows_featured{}'))
    ui.d.add(_('People Watching'), 'tvshowsTrending', 'DefaultTVShows.png',
             'tvshows.tvshowlist', url=dbs.resolve('tvshows_trending{}'))
    ui.d.add(_('Most Popular'), 'tvshowsPopular', 'DefaultTVShows.png',
             'tvshows.tvshowlist', url=dbs.resolve('tvshows_popular{}'))
    ui.d.add(_('Most Voted'), 'tvshowsViews', 'DefaultTVShows.png',
             'tvshows.tvshowlist', url=dbs.resolve('tvshows_toprated{}'))
    ui.d.add(_('On Air'), 'tvshowsOnAir', 'DefaultTVShows.png',
             'tvshows.tvshowlist', url=dbs.resolve('tvshows_onair{}'))

    if not addon.setting('trakt_user') or addon.setting('trakt_enabled') != 'true':
        ui.d.add(_('Configure your Trakt account'), 'tvshowsTraktcollection', 'DefaultTVShows.png',
                 'tools.addonsettings', category=1, is_folder=False)

    ui.d.end()


@action()
def bookmarked():
    def elapsed2str(secs):
        mins, secs = divmod(secs, 60)
        hours, mins = divmod(mins, 60)
        return '%d:%02d:%02d' % (hours, mins, secs)

    items = [{
        'imdb': k['imdb'],
        'season': k['season'],
        'episode': k['episode'],
        'bookmarktime': b['bookmarktime'],
        } for k, b in Bookmarks('episode').iteritems()]
    items = items[0:20]

    dbs.meta(items, content='tvshow')
    items = [i for i in items if 'title' in i]

    for i in items:
        i['tvshowtitle'] = i['title']
        i['label.format'] = _('[B][{bookmarktime}][/B] {{label}}', bookmarktime=elapsed2str(i['bookmarktime']))
        i['action'] = actions.url('sources.play', content='episode', meta=i)
        i['commands'] = [(_('Delete bookmark'), actions.plugin('tvshows.deletebookmark', meta=i))]

    # Disable the sort methods so that the latest video watched is shown first
    ui.d.addcontents(items, content='episode', sort_methods=())


@action(dict)
def deletebookmark(meta):
    bookmarks = Bookmarks()
    if meta in bookmarks:
        del bookmarks[meta]
        ui.refresh()


@action()
def searchbytitle():
    query = ui.dialog.keyboard(_('TV show search'), history='tvshow-title')
    if query:
        url = dbs.resolve('tvshows{title}', title=query)
        ui.refresh('tvshows.tvshowlist', url=url)


@action()
def searchbyyear():
    query = ui.dialog.keyboard(_('Year search'), history='tvshow-year')
    if query:
        url = dbs.resolve('tvshows{year}', year=query)
        ui.refresh('tvshows.tvshowlist', url=url)


@action()
def genres():
    items = dbs.genres('tvshow')
    for i in items:
        image = i.get('image')
        if not image:
            image = 'DefaultGenre.png' # (fixme) [UI] Need a table mapping genre 'id' to different icons
        i.update({
            'action': 'tvshows.tvshowlist',
            'url': dbs.resolve('tvshows{genre_id}', genre_id=i['id']),
            'image': image,
        })

    ui.d.adds(items)


@action(str)
def tvshowlist(url):
    items = dbs.tvshows(url)
    if not items:
        ui.dialog.info(_('No results'))
    else:
        dbs.meta(items, content='tvshow')
        for i in items:
            i['action'] = actions.url('tvshows.seasons', tvdb=i.get('tvdb'), imdb=i.get('imdb'))
            i['next_action'] = 'tvshows.tvshowlist'

    ui.d.addcontents(items, content='tvshow')


@action(int, str)
def seasons(tvdb, imdb):
    item = {
        'tvdb': tvdb,
        'imdb': imdb,
    }
    dbs.meta([item], content='tvshow')

    items = item.get('seasons', [])
    if not items:
        ui.dialog.info(_('No seasons'))
    else:
        for i in items:
            i['imdb'] = item['imdb']
            i['action'] = actions.url('tvshows.episodes', tvdb=item.get('tvdb'), imdb=item.get('imdb'), season=i['season'])

    ui.d.addcontents(items, content='season')


@action(int, str, int)
def episodes(tvdb, imdb, season):
    item = {
        'tvdb': tvdb,
        'imdb': imdb,
    }
    dbs.meta([item], content='tvshow')

    items = [e for e in item.get('episodes', []) if e['season'] == season]
    if not items:
        ui.dialog.info(_('No episodes'))
    else:
        for i in items:
            i['imdb'] = item['imdb']
            i['action'] = actions.url('sources.play', content='episode', meta=i)

    ui.d.addcontents(items, content='episode')


@action(str, dict)
def addtolibrary(title, meta):
    meta = meta or {}
    if videolibrary.add('tvshow', title, meta):
        ui.dialog.info(_('TV show {title} added to the library', title=title))
        actions.run('videolibrary.update', content='tvshow', title=title, meta=meta)
