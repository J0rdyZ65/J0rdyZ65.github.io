# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import json

from g2.libraries.language import _

from g2 import dbs

from g2.platforms import ui
from g2.platforms import addon
from g2.platforms import videolibrary

from . import action, busyaction
from .lib.bookmarks import Bookmarks


@action
def menu():
    if Bookmarks('episodes'):
        ui.d.add(_('Keep Watching'), 'tvshowsUserlists', 'DefaultTVShows.png', 'tvshows.bookmarked')

    ui.d.add(_('Search by Title'), 'tvSearch', 'DefaultTVShows.png', 'tvshows.searchbytitle', is_folder=False)
    ui.d.add(_('People Watching'), 'tvshowsTrending', 'DefaultRecentlyAddedEpisodes.png',
             'tvshows.tvshowlist', url=dbs.resolve('tvshows_trending{}'))
    ui.d.add(_('Most Popular'), 'tvshowsPopular', 'DefaultTVShows.png',
             'tvshows.tvshowlist', url=dbs.resolve('tvshows_popular{}'))

    ui.d.end()


@action
def bookmarked():
    def elapsed2str(secs):
        mins, secs = divmod(secs, 60)
        hours, mins = divmod(mins, 60)
        return '%d:%02d:%02d' % (hours, mins, secs)

    items = [{
        'imdb': k['imdb'],
        # (fixme) transition to all unicode!!!
        'season': k['season'].encode('utf-8'),
        'episode': k['episode'].encode('utf-8'),
        # Show the movie watched time in the Keep Watching movies directory
        'bookmarktime': _('[B][{bookmarktime}][/B]', bookmarktime=elapsed2str(b[0])),
        } for k, b in Bookmarks('episodes', reverse=True)]

    dbs.meta(items, content='tvshow')
    items = [i for i in items if 'title' in i]

    for i in items:
        i['tvshowtitle'] = i['title']
        i['name'] = i['bookmarktime'] + ' ' + ui.d.name('episode', i)
        i['action'] = addon.itemaction('sources.play', name=i['name'], content='episode', meta='')

    # Disable the sort methods so that the latest video watched is shown first
    ui.d.addcontents(items, content='episodes', sort_methods=())


@action
def searchbytitle():
    query = ui.dialog.keyboard(_('TV show search'), history='tvshow-title')
    if query:
        url = dbs.resolve('tvshows{title}', title=query)
        ui.refresh('tvshows.tvshowlist', url=url)


@action
def tvshowlist(url):
    items = dbs.tvshows(url)
    if not items:
        ui.dialog.info(_('No results'))
    else:
        dbs.meta(items, content='tvshow')
        for i in items:
            i['name'] = ui.d.name('tvshow', i)
            i['action'] = addon.itemaction('tvshows.seasons', tvdb=i['tvdb'], imdb=i['imdb'])
            i['next_action'] = 'tvshows.tvshowlist'

    ui.d.addcontents(items, content='tvshows')


@action
def seasons(tvdb, imdb):
    item = {
        'tvdb': tvdb,
        'imdb': imdb,
    }
    dbs.meta([item], content='tvshow_seasons')

    items = item.get('seasons', [])
    if not items:
        ui.dialog.info(_('No seasons'))
    else:
        for i in items:
            i['name'] = ui.d.name('season', i)
            i['action'] = addon.itemaction('tvshows.episodes', tvdb=item['tvdb'], imdb=item['imdb'], season=i['season'])

    ui.d.addcontents(items, content='seasons')


@action
def episodes(tvdb, imdb, season):
    item = {
        'tvdb': tvdb,
        'imdb': imdb,
    }
    dbs.meta([item], content='tvshow_episodes')

    items = [e for e in item.get('episodes', []) if e['season'] == season]
    if not items:
        ui.dialog.info(_('No episodes'))
    else:
        for i in items:
            i['imdb'] = item['imdb']
            i['name'] = ui.d.name('episode', i)
            i['action'] = addon.itemaction('sources.play', name=i['name'], content='episode', meta='')

    ui.d.addcontents(items, content='episodes')


@busyaction
def addtolibrary(title, meta):
    meta = json.loads(meta or '{}')
    if videolibrary.add('tvshow', title, meta):
        ui.dialog.info(_('TV show {title} added to the library', title=title))
        addon.runplugin('videolibrary.update', content='tvshow', title=title, meta=json.dumps(meta))


@busyaction
def watched(imdb, season, episode):
    dbs.watched('episode{imdb_id}{season}{episode}', True,
                imdb_id=imdb, season=season, episode=episode)
    ui.refresh()


@busyaction
def unwatched(imdb, season, episode):
    dbs.watched('episode{imdb_id}{season}{episode}', False,
                imdb_id=imdb, season=season, episode=episode)
    ui.refresh()
