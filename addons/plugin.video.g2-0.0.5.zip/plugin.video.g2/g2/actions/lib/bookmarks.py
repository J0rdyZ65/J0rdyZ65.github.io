# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


from g2.libraries.database import Database, DatabaseIterator


class Bookmarks(Database):
    def __init__(self, content=None, reverse=False):
        Database.__init__(self,
                          'settings', 'bookmarks',
                          ('video_key', 'TEXT'),
                          ('bookmarktime', 'INTEGER'),
                          ('url', 'TEXT'),
                          timestamp=True,
                          create='CREATE TABLE IF NOT EXISTS {table} ({columns_def}, UNIQUE(video_key))',
                          select='SELECT {star} FROM {table} WHERE video_key = ?',
                          replace='REPLACE INTO {table} ({columns}) VALUES ({values})',
                          delete='DELETE FROM {table} WHERE video_key = ?',
                          selectall=('SELECT {star} FROM {table} WHERE video_key LIKE "%/0/0"' if content == 'movies' else
                                     'SELECT {star} FROM {table} WHERE video_key NOT LIKE "%/0/0"' if content == 'episodes' else
                                     'SELECT {star} FROM {table}') + ' ORDER BY {timestamp} ' + ('DESC' if reverse else 'ASC'))

    def __contains__(self, keydict):
        row = Database._get(self, (self.video_key(keydict),))
        return bool(row)

    def __getitem__(self, keydict):
        row = Database._get(self, (self.video_key(keydict),))
        if not row:
            raise KeyError
        return (row['bookmarktime'], row['url'])

    def __setitem__(self, keydict, value):
        if not isinstance(value, (list, tuple)):
            bookmarktime = value
            url = None
        elif value:
            bookmarktime = value[0]
            url = None if len(value) <= 1 else value[1]
        Database._set(self, (self.video_key(keydict),), (int(bookmarktime), url))

    def __delitem__(self, keydict):
        Database._del(self, (self.video_key(keydict),))

    def __iter__(self):
        return BookmarksIterator(self._dbconnect(), self.columns_def, self._sql_cmd('selectall'))

    @staticmethod
    def video_key(keydict):
        """Unique identifier for videos in database records"""
        if not isinstance(keydict, dict):
            raise KeyError
        keys = [keydict.get(k) or '0' for k in ['imdb', 'season', 'episode']]
        if not keys[0] or keys[0] == '0':
            raise KeyError
        return '/'.join(keys)


class BookmarksIterator(DatabaseIterator):
    def next(self):
        row = DatabaseIterator.next(self)
        key = row['video_key'].split('/')
        return {k:key.pop(0) for k in ('imdb', 'season', 'episode')}, (row['bookmarktime'], row['url'])
