# -*- coding: utf-8 -*-

"""plugin.video.icarus servers API adapter"""

kind = 'resolvers'

addons = ['plugin.video.icarus']

imports = ['servers']

skip = ['servers.kbagi']

paths = ['lib']

nick = 'icrs'


import os
import json

from g2.libraries import fs
from g2.libraries import log
from g2.libraries import client

from g2.resolvers.api import ResolverBase


class IcarusResolvers(ResolverBase):
    @property
    def info(self):
        if not self.module:
            return {}

        from platformcode import logger # kodi addon # pylint: disable=import-error
        logger.log_enable(False)

        module_path = os.path.splitext(self.module.__dict__['__file__'])[0]
        module_name = os.path.basename(module_path)
        if not hasattr(self.module, 'get_video_url'):
            log.debug('{p}.{f}: %s: missing get_video_url function', module_name)
            return []

        with fs.File(module_path + '.json') as fil:
            server_config = json.loads(fil.read())

        if not server_config.get('active', False):
            log.debug('{p}.{f}: %s: server not active', module_name)
            return []

        url_patterns = server_config.get('find_videos', {}).get('patterns', [])
        url_patterns = [pat['pattern'] for pat in url_patterns if 'pattern' in pat]

        if not url_patterns:
            log.debug('{p}.{f}: %s: url patterns not found', module_name)
            return []                      

        log.debug('{p}.{f}: %s: url patterns: %s', module_name, url_patterns)

        return [{
            'name': module_name,
            'url_patterns': url_patterns,
        }]

    def resolve(self, url):
        urls = self.module.get_video_url(url)
        if not urls:
            return None

        # (fixme) the url resolution might return multiple urls with different stream quality,
        # this should be handled in the resolvers.resolve.
        for url in urls:
            log.debug('{m}.{f}: %s', url)

        return urls[-1][1]
