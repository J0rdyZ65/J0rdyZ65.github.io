# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2018 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import json

from g2.libraries import log
from g2.libraries import client

from g2.resolvers.api import ResolverBase


kind = 'resolvers'

addons = ['plugin.video.icarus']

imports = ['servers']

skip = ['servers.kbagi']

paths = ['lib']

nick = 'icrs'


class IcarusResolvers(ResolverBase):
    @property
    def info(self):
        if not self.module:
            return {}

        from platformcode import logger
        logger.log_enable(False)

        module_path = os.path.splitext(self.module.__dict__['__file__'])[0]
        module_name = os.path.basename(module_path)
        if not hasattr(self.module, 'get_video_url'):
            log.debug('{p}.{f}: %s: missing get_video_url function', module_name)
            return []

        with open(module_path + '.json') as fil:
            server_config = json.loads(fil.read())

        active = server_config.get('active', False)
        if not active:
            log.debug('{p}.{f}: %s: server not active', module_name)

        url_patterns = server_config.get('find_videos', {}).get('patterns', [])
        url_patterns = [pat['pattern'] for pat in url_patterns if 'pattern' in pat]

        if not url_patterns:
            log.debug('{p}.{f}: %s: url patterns not found', module_name)

        log.debug('{p}.{f}: %s: url patterns: %s', module_name, url_patterns)

        return [{
            'name': module_name,
            'url_patterns': url_patterns,
            'enabled': active and url_patterns,
        }]

    def resolve(self, url):
        urls = self.module.get_video_url(url)
        # (fixme) the url resolution might return multiple urls with different stream quality,
        # this should be handled in the resolvers.resolve.
        return urls[-1][1] if urls else None
