# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Based on the original idea/code of boogiekodi@GitHub for his ump plugin
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import re
import struct


def video_resolution(first8bytes, fil, stop_at_bytes, log=None):
    if first8bytes[:3] != "FLV":
        raise Exception('not flv format')

    fil.read(6)
    byte1, byte2, byte3 = struct.unpack("3B", fil.read(3)) # payload size of the 1st packet (typically the metadata header)
    size = (byte1 << 16) + (byte2 << 8) + byte3
    fil.read(7) # Skip the rest of the packet header
    fil.read(4) # Skip first uint32 of the payload content
    header = fil.read(min(size-4, stop_at_bytes))
    width = re.findall(r'width.(........)', header)
    width = 0 if not width else int(struct.unpack(">d", width[0])[0])
    height = re.findall(r'height.(........)', header)
    height = 0 if not height else int(struct.unpack(">d", height[0])[0])

    if callable(log):
        log('{m}.{f}: resolution: %dx%d', width, height)

    return (width, height)
