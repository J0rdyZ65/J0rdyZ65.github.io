# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import os
import re
import sys
import time
import urllib
import urlparse

from g2 import pkg
from g2 import defs

from g2.libraries import log
from g2.libraries import client
from g2.libraries import workers

from .lib import metastream
from .api import create, ResolverError


class ResolvedURL(unicode):
    def enrich(self, **kwargs):
        for key, val in kwargs.iteritems():
            if val is not None:
                setattr(self, key, val)
        return self


def info(package, module=None):
    nfo = create(module, package=package).info
    nfo = [nfo] if isinstance(nfo, dict) else list(nfo)
    # API: info[domains|url_patterns]: enforce a non empty domains|url_patterns
    # (fixme) should we also validate the regex here?!?
    return nfo if not module else [i for i in nfo if i.get('domains') or i.get('url_patterns')]


def resolve(url, ui_update=lambda *args, **kwargs: time.sleep(0.1) or True):
    def resolver_worker(channel, resolver, module, url):
        if 'abort' in channel:
            log.debug('{m}.{f}: %s: aborted at resolve', resolver)
            return None

        res = create(module, resolver=resolver).resolve(url)

        if not isinstance(res, basestring) or not res.split('|')[0].strip():
            return _resolver_error(resolver, 'resolve value is "%s"' % res)

        if 'abort' in channel:
            log.debug('{m}.{f}: %s: aborted at stream validation', resolver)
            return None

        res = probe(res, url)
        if not isinstance(res, ResolvedURL):
            return _resolver_error(resolver, str(res))

        return res.enrich(resolver=resolver.fullname())

    def priority(package):
        try:
            return int(pkg.setting('resolvers', package['name'], name='priority'))
        except Exception:
            try:
                return int(package['priority'])
            except Exception:
                return defs.DEFAULT_PACKAGE_PRIORITY

    if not url:
        return [ResolverError('No resolver for the empty url')]

    resolvers = sorted([r for r in pkg.info('resolvers').itervalues() if match(r, url)],
                       key=lambda r: priority(r.package))

    if not resolvers:
        return [ResolverError('No resolver for %s'%', '.join(_top_domains(url)))]

    log.debug('{m}.{f}: %s: %s', ', '.join([r.fullname() for r in resolvers]), url)

    errors = []
    for resolver in resolvers:
        with resolver.context() as modules:
            if modules:
                channel = []
                thd = workers.Thread(resolver_worker, channel, resolver, modules[0], url)
                thd.start()

                while thd.is_alive():
                    if not ui_update(resolver):
                        # Inform the resolver thread to abort ASAP
                        channel.append('abort')
                        errors.append(_resolver_error(resolver, 'UI cancelled'))
                        break

                if 'abort' in channel:
                    pass
                elif thd.exc:
                    errors.append(_resolver_error(resolver, thd.exc))
                elif isinstance(thd.result, ResolvedURL):
                    return thd.result.enrich(elapsed=thd.elapsed())
                else:
                    errors.append(thd.result)

    return errors


def probe(url, referer=None):
    if not url:
        return ResolverError('empty url')
    if not url.lstrip().startswith('http'):
        return url if isinstance(url, ResolvedURL) else ResolvedURL(url)

    try:
        url, headers = url.split('|')
        if ' ' in headers:
            headers = urllib.quote_plus(headers, '=&')
        headers = dict(urlparse.parse_qsl(headers))
    except Exception:
        url = url.split('|')[0]
        headers = dict()

    if not 'User-Agent' in headers:
        headers['User-Agent'] = client.agent() # (fixme) [FUNC] should we adopt random agent?
    if not 'Referer' in headers and referer:
        headers['Referer'] = referer

    try:
        res = client.get(url, headers=headers, stream=True, timeout=20, debug=log.debugactive())
        res.raise_for_status()

        meta = metastream.video(res.raw)

        if meta.get('type') == 'm3u':
            content_lenght = None
        else:
            content_lenght = int(res.headers.get('Content-Length', '0'))
            if content_lenght < defs.MIN_STREAM_SIZE:
                raise Exception('stream too short')

        return ResolvedURL('%s|%s' % (url, urllib.urlencode(headers))).enrich(
            meta=meta,
            size=content_lenght,
        )
    except Exception as ex:
        return ResolverError(str(ex))


def match(resolver, url):
    res_domains = set(resolver.get('domains', []))
    if '*' in res_domains or res_domains & _top_domains(url):
        return True
    if not hasattr(resolver, 'url_patterns'):
        resolver.url_patterns = {}
    for pattern in resolver.get('url_patterns', []):
        if pattern not in resolver.url_patterns:
            try:
                resolver.url_patterns[pattern] = re.compile(pattern)
            except Exception:
                resolver.url_patterns[pattern] = None
        try:
            if resolver.url_patterns[pattern].search(url):
                return True
        except Exception:
            pass
    return False


def _top_domains(url):
    elements = urlparse.urlparse(url)
    domain = elements.netloc or elements.path
    domain = domain.split('@')[-1].split(':')[0]
    domains = []
    try:
        domains.append(re.search(r'(\w{2,}\.\w{2,})$', domain).group(1))
    except Exception:
        pass
    try:
        domains.append(re.search(r'(\w{2,}\.\w{2,3}\.\w{2})$', domain).group(1))
    except Exception:
        pass
    return set(domains if domains else [domain.lower()])


def _resolver_error(resolver, err):
    return err if not isinstance(err, basestring) and str(err).startswith(resolver.fullname()) \
      else ResolverError('%s: %s'%(resolver, str(err)))
