# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2018-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

kind = 'resolvers'

addons = ['script.module.urlresolver']

imports = 'urlresolver'

nick = 'smu'


import ast

from g2.libraries import log
from g2.resolvers.api import ResolverBase


class SMUResolvers(ResolverBase):
    default_allow_popups = True

    @property
    def info(self):
        if not self.module:
            return {'settings': [{'id': 'allow_popups',
                                  'label': 'Allow popups',
                                  'spec': 'type="bool"',
                                  'default': str(self.default_allow_popups).lower()}]}

        try:
            resolvers = self.module.relevant_resolvers(include_universal=True, include_external=True)
        except Exception as ex:
            log.error('{p}.{f}: %s', repr(ex))
            return []

        nfo = []
        for res in resolvers:
            nfo.append({
                'name': res.name,
                'domains': res.domains,
            })
            log.debug('{m}.{f}: %s: domains: %s', res.name, res.domains)

        return nfo

    def resolve(self, url):
        return self.module.HostedMediaFile(url=url).resolve(allow_popups=self._allow_popups())

    def _allow_popups(self):
        try:
            allow_popups = self.setting('allow_popups')
            allow_popups = ast.literal_eval(allow_popups.capitalize()) if allow_popups else self.default_allow_popups
        except Exception:
            allow_popups = self.default_allow_popups
        return allow_popups
