# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2018-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import os
import re
from io import open

import xbmc

from g2.libraries import advsettings

from . import log
from . import info, addon


_LANGUAGES = advsettings.setting('languages') or {}


def xgettext(msgid):
    return msgid


def _(msgid, *args, **kwargs):
    lmsgid = _lmsg(msgid, 'str')
    try:
        return lmsgid.format(*args, **kwargs)
    except Exception as ex:
        log.notice('{m}.{f}: %s: %s', lmsgid, repr(ex))
        return str(msgid) + '???'


def msgcode(msgid):
    return _lmsg(msgid, 'code')


def name(lang, fmt=None):
    return _LANGUAGES.get(lang, {}).get(fmt or info('language'), lang)


def _lmsg(msgid, nfo='str'):
    if not hasattr(_lmsg, 'msgs'):
        _lmsg.msgs = addon.prop('language', name='msgs')

    if not _lmsg.msgs:
        _lmsg.msgs = _read_msgs()

    lmsgids = _lmsg.msgs.get(msgid, {}).get(nfo)

    return lmsgids[0] if lmsgids else msgid


def _read_msgs():
    msgs = {}
    pofile = os.path.join(addon.info('path'), 'resources', 'language',
                          xbmc.convertLanguage(info('language', 'en'), xbmc.ENGLISH_NAME), 'strings.po')
    with open(pofile, encoding='utf-8') as pof:
        msgid = None
        msgstrs = []
        msgctxts = []
        def close_msgid():
            if msgid:
                msgs[msgid] = {
                    'str': msgstrs,
                    'code': msgctxts,
                }

        for line in pof.read().splitlines():
            try:
                # msgid "General"
                new_msgid = re.match(r'msgid\s*"([^"]+)"', line).group(1)
                if not new_msgid:
                    raise Exception
                msgid = new_msgid
                continue
            except Exception:
                pass
            try:
                # msgstr "Generali"
                msgstr = re.match(r'msgstr\s*"([^"]+)"', line).group(1)
                if not msgstr:
                    raise Exception
                msgstrs.append(msgstr)
                continue
            except Exception:
                pass
            try:
                # msgctxt "#30000"
                msgctxt = re.match(r'msgctxt\s*"#(\d+)"', line).group(1)
                if not msgctxt:
                    raise Exception
                msgctxts.append(msgctxt)
            except Exception:
                pass
            if re.match(r'\s*$', line):
                close_msgid()
                msgid = None
                msgstrs = []
                msgctxts = []

        close_msgid()

    addon.prop('language', msgs, name='msgs')

    return msgs
