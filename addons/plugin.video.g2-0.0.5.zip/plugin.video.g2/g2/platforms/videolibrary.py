# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2018-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import os
import re
import json
import errno

import xbmc
import xbmcvfs

from . import log
from . import info
from . import addon
from . import actions
# (fixme) [CODE] need to find a more portable way for windows
# from . import portalocker


class File(object):
    def __init__(self, filepath, mode='r', ignore_exc=True):
        self.filepath = filepath
        self.mode = mode
        self.ignore_exc = ignore_exc
        self.fil = None

    def __enter__(self):
        try:
            # Not strictly required but this check avoids Kodi to spit out
            # an error message on behalf of the xbmcvfs.File builtin
            if 'r' in self.mode and not xbmcvfs.exists(self.filepath):
                raise OSError(errno.ENOENT, os.strerror(errno.ENOENT), self.filepath)
            self.fil = xbmcvfs.File(self.filepath, self.mode)
        except Exception:
            if not self.ignore_exc:
                raise
        return self.fil

    def __exit__(self, exc_type, exc_value, traceback):
        if self.fil:
            self.fil.close()
        return self.ignore_exc or not exc_value


_NFO_URLS = {
    'movie': (
        'https://www.themoviedb.org/movie/{tmdb}',
        'http://www.imdb.com/title/{imdb}/',
    ),
    'tvshow': (
        'http://thetvdb.com/?tab=series&id={tvdb}',
        'http://www.imdb.com/title/{imdb}/',
    ),
}

_CONTENT_LIBRARY_SETTINGS = {
    'movie': 'videolibrary.movies',
    'tvshow': 'videolibrary.tvshows',
}


def add(content, title, meta):
    folder_path = addon.setting(_CONTENT_LIBRARY_SETTINGS.get(content, '')).decode('utf-8') # decode kodi dirname
    if not folder_path:
        return False
    if content == 'movie':
        movie_dir = _name_format(('{title_} ({year})',), title_=title, meta=meta)
        movie_path = os.path.join(folder_path, movie_dir) if 'year' not in meta else \
                     os.path.join(folder_path, str(meta['year']), movie_dir)
        if not _create_strm(os.path.join(movie_path, 'movie.strm'), content, meta):
            return False
        _create_nfo(os.path.join(movie_path, 'movie.nfo'), content, meta)
        return True
    if content == 'tvshow':
        tvshow_dir = _name_format(('{title_} ({year})',), title_=title, meta=meta)
        tvshow_path = os.path.join(folder_path, tvshow_dir)
        _create_nfo(os.path.join(tvshow_path, 'tvshow.nfo'), content, meta)
        return True

    return False


def update(content, title=None, meta=None, dbs_meta=None):
    folder_path = addon.setting(_CONTENT_LIBRARY_SETTINGS.get(content, '')).decode('utf-8') # decode kodi dirname
    if not folder_path:
        return
    if content == 'tvshow':
        if title:
            tvshows_dirs = [_name_format(('{title_} ({year})',), title_=title, meta=meta)]
        elif xbmcvfs.exists(os.path.join(folder_path, '')):
            tvshows_dirs = [d.decode('utf-8') for d in xbmcvfs.listdir(folder_path)[0]] # decode kodi dirnames
        else:
            return
        # (fixme) [CODE] Review the proper file to lock and handle the timeout scenario
        # with portalocker.Lock(os.path.join(addon.info('profile'), 'settings.xml'), 'r'):
        for tvshow_dir in tvshows_dirs:
            eps_added = _add_tvshow_episodes(os.path.join(folder_path, tvshow_dir), title, meta, dbs_meta)
            if eps_added > 0:
                yield tvshow_dir, eps_added


def scan():
    while xbmc.getCondVisibility('Library.IsScanningVideo'):
        xbmc.sleep(1000)
    xbmc.executebuiltin('UpdateLibrary(video)')


def watched(content, meta, seen):
    if content == 'movie':
        local_content = 'movie'
    elif content in ('tvshow', 'season', 'episode'):
        local_content = 'episode'
    else:
        return None
    videos = _fetch_local_content(local_content, **meta)
    if not videos:
        return None

    if isinstance(seen, set):
        seenlen = len(seen)
        if content == 'movie':
            movie = videos[0]
            seen.update([True] if movie.get('playcount') else [])
        elif content == 'tvshow':
            seen.update([(e['episode'], e['season']) for e in videos if e.get('playcount')])
        elif content == 'season':
            seen.update([(e['episode'], e['season']) for e in videos if e.get('playcount') and
                         e['season'] == meta['season']])
        elif content == 'episode':
            episodes = [e for e in videos if e.get('playcount') and
                        e['season'] == meta['season'] and e['episode'] == meta['episode']]
            seen.update([True] if episodes and episodes[0].get('playcount') else [])
        if seenlen != len(seen):
            log.debug('{m}.{f}: %s %s/%s/%s: %s [%d]',
                      content, meta.get('imdb'), meta.get('season'), meta.get('episode'), seen, len(seen))

    elif content == 'movie':
        movie = videos[0]
        movie['playcount'] = 1 if seen else 0
        res = _update_local_content(local_content, **movie)
        log.debug('{m}.{f}: %s %s: seen=%s, res=%s', content, meta.get('imdb'), seen, res)

    else:
        # (fixme) [FUNC] massive episode playcount update (e.g. entire tvshow and season updates) is disabled
        # for the UI side effect that for each episode update a refresh of the current container is forced.
        if content == 'tvshow':
            episodes = [] # videos
        elif content == 'season':
            episodes = [] # [e for e in videos if e['season'] == meta['season']]
        elif content == 'episode':
            episodes = [e for e in videos if e['season'] == meta['season'] and e['episode'] == meta['episode']]
        for episode in episodes:
            episode['playcount'] = 1 if seen else 0
            res = _update_local_content(local_content, **episode)
            log.debug('{m}.{f}: %s %s/%s/%s: seen=%s, res=%s',
                      content, meta.get('imdb'), episode.get('season'), episode.get('episode'), seen, res)

    return None


def _add_tvshow_episodes(tvshow_path, title=None, meta=None, dbs_meta=None):
    if not meta:
        tvshow_path = xbmc.makeLegalFilename(tvshow_path)
        tvshow_nfo_path = os.path.join(tvshow_path, 'tvshow.nfo')
        if not xbmcvfs.exists(tvshow_nfo_path):
            return 0
        with File(tvshow_nfo_path) as fil:
            meta = _scan_nfo('tvshow', fil.read())

    item = {
        'tvdb': meta.get('tvdb'),
        'imdb': meta.get('imdb'),
    }
    if callable(dbs_meta):
        dbs_meta([item], content='tvshow')
    if not title:
        title = item.get('title')
        if not title:
            return 0

    library_eps = [(e['season'], e['episode']) for e in _fetch_local_content('episode', tvshowtitle=title, **item)]

    return sum([_add_episode(tvshow_path, item, ep)
                for ep in item.get('episodes', []) if (ep.get('season'), ep.get('episode')) not in library_eps])


def _add_episode(tvshow_path, tvshowmeta, meta):
    episode_basename = os.path.join(tvshow_path,
                                    'S{season:02d}'.format(season=meta['season']),
                                    '{season}x{episode:02d} - {title}'.format(
                                        season=meta['season'],
                                        episode=meta['episode'],
                                        title=meta['title']))
    meta.update({t:tvshowmeta[t] for t in ('imdb', 'tmdb', 'year') if t in tvshowmeta and meta.get(t)})
    return _create_strm(episode_basename + '.strm', 'episode', meta, tags=('tvshowtitle', 'season', 'episode'))


def _name_format(fmts, title_, meta):
    for fmt in fmts:
        try:
            return fmt.format(title_=title_, **meta)
        except Exception:
            pass
    return title_


def _create_strm(path, content, meta, tags=()):
    meta = {tag:meta[tag] for tag in ('title', 'year', 'imdb', 'tmdb', 'poster') + tags if tag in meta}
    path = xbmc.makeLegalFilename(path)
    strm_content = actions.url('sources.play', content=content, meta=meta)
    xbmcvfs.mkdirs(os.path.dirname(path))
    with File(path, 'w') as fil:
        fil.write((strm_content + '\n').encode('utf-8')) # unicode encoding of the kodi .strm content
    return 1


def _create_nfo(path, content, meta):
    for url in _NFO_URLS.get(content, ()):
        try:
            nfo_content = url.format(**meta)
            path = xbmc.makeLegalFilename(path)
            xbmcvfs.mkdirs(os.path.dirname(path))
            with File(path, 'w') as fil:
                fil.write((nfo_content + '\n').encode('utf-8'))
            return path
        except Exception:
            pass
    return None


def _scan_nfo(content, nfo):
    meta = {}
    for url in _NFO_URLS.get(content, ()):
        try:
            placeholders = []
            def scan_placeholder(match):
                placeholders.append(match.group(1)) #pylint: disable=W0640
                return '(.*)'

            pat = re.sub(r'\\{([a-zA-Z_]*)\\}', scan_placeholder, re.escape(url))
            match = re.search(pat, nfo)
            if match:
                for value in match.groups():
                    meta.update({placeholders.pop(0): value})
        except Exception:
            pass

    return meta


_JSON_METHODS_TEMPLATES = {
    'movie': [
        '{{"jsonrpc": "2.0", \
            "id": "{_request_id}", \
            "method": "VideoLibrary.GetMovies", \
            "params": {{ \
                "filter": {{"operator": "is", "field": "title", "value": "{title}"}}, \
                "properties": ["file", "year", "playcount"] \
            }} \
        }}',
    ],
    'update.movie': [
        '{{"jsonrpc": "2.0", \
            "id": "{_request_id}", \
            "method": "VideoLibrary.SetMovieDetails", \
            "params": {{ \
                "movieid": {movieid}, \
                "playcount": {playcount} \
            }} \
        }}',
    ],
    'tvshow': [
        '{{"jsonrpc": "2.0", \
            "id": "{_request_id}", \
            "method": "VideoLibrary.GetTVShows", \
            "params": {{ \
                "filter": {{"operator": "is", "field": "title", "value": "{tvshowtitle}"}}, \
                "properties": ["year"] \
            }} \
        }}',
    ],
    'episode': [
        '{{"jsonrpc": "2.0", \
            "id": "{_request_id}", \
            "method": "VideoLibrary.GetEpisodes", \
            "params": {{ \
                "tvshowid": {tvshowid}, \
                "properties": ["file", "season", "episode", "playcount"] \
            }} \
        }}',
    ],
    'update.episode': [
        '{{"jsonrpc": "2.0", \
            "id": "{_request_id}", \
            "method": "VideoLibrary.SetEpisodeDetails", \
            "params": {{ \
                "episodeid": {episodeid}, \
                "playcount": {playcount} \
            }} \
        }}',
    ],
}


def _fetch_local_content(content, **meta):
    year = meta.get('year', 0)
    try:
        if content == 'movie':
            res = _json_rpc(content, **meta)['result']['movies']
            return [i for i in res
                    if not year or not i.get('year') or any(y == i.get('year') for y in range(year-1, year+2))]
        if content == 'episode':
            if not meta.get('tvshowtitle') and meta.get('title'):
                meta['tvshowtitle'] = meta['title']
            res = _json_rpc('tvshow', **meta)['result']
            if 'tvshows' in res:
                res = res['tvshows']
            elif int(info('version.major')) <= 16:
                # Hack to reconciliate the tvdb addon meta fetching in kodi16 which appends
                # the (US) tag to some tvshows titles (e.g. 'Shameless' becomes 'Shameless (US)')
                meta = dict(meta)
                meta['tvshowtitle'] += ' (US)'
                res = _json_rpc('tvshow', **meta)['result']['tvshows']
            tvshowids = [i['tvshowid'] for i in res
                         if not year or not i.get('year') or any(y == i.get('year') for y in range(year-1, year+2))]
            return _json_rpc(content, tvshowid=tvshowids[0], **meta)['result']['episodes']
    except Exception:
        pass
    return []


def _update_local_content(content, **meta):
    try:
        return _json_rpc('update.' + content, **meta)
    except Exception:
        return {}


def _json_rpc(method, **meta):
    for method_template in _JSON_METHODS_TEMPLATES.get(method, []):
        try:
            _json_rpc.request_id += 1
        except Exception:
            _json_rpc.request_id = 1
        try:
            method_instance = method_template.format(_request_id=_json_rpc.request_id, **meta)
            return json.loads(xbmc.executeJSONRPC(method_instance))
        except Exception:
            pass
    return {}
