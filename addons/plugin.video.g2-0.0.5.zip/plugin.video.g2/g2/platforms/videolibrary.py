# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2018 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import re
import json
import errno
import urllib

import xbmc
import xbmcvfs

from g2 import dbs

from . import addon
from . import portalocker


class File(object):
    def __init__(self, filepath, mode='r', ignore_exc=True):
        self.filepath = filepath
        self.mode = mode
        self.ignore_exc = ignore_exc
        self.fil = None

    def __enter__(self):
        try:
            # Not strictly required but this check avoids Kodi to spit out
            # an error message on behalf of the xbmcvfs.File builtin
            if 'r' in self.mode and not xbmcvfs.exists(self.filepath):
                raise OSError(errno.ENOENT, os.strerror(errno.ENOENT), self.filepath)
            self.fil = xbmcvfs.File(self.filepath, self.mode)
        except Exception:
            if not self.ignore_exc:
                raise
        return self.fil

    def __exit__(self, exc_type, exc_value, traceback):
        if self.fil:
            self.fil.close()
        return self.ignore_exc or not exc_value


_NFO_URLS = {
    'movie': (
        'https://www.themoviedb.org/movie/{tmdb}',
        'http://www.imdb.com/title/{imdb}/',
    ),
    'tvshow': (
        'http://thetvdb.com/?tab=series&id={tvdb}',
        'http://www.imdb.com/title/{imdb}/',
    ),
}

_CONTENT_LIBRARY_SETTINGS = {
    'movie': 'videolibrary.movies',
    'tvshow': 'videolibrary.tvshows',
    'episode': 'videolibrary.tvshows',
}


def add(content, title, meta, url=None):
    folder_path = addon.setting(_CONTENT_LIBRARY_SETTINGS.get(content, '')).decode('utf-8')
    if not folder_path:
        return False
    if content == 'movie':
        movie_dir = _name_format(('{title_} ({year})',), title_=title, meta=meta)
        movie_path = os.path.join(folder_path, movie_dir) if 'year' not in meta else \
                     os.path.join(folder_path, meta['year'], movie_dir)
        if not _create_strm(os.path.join(movie_path, title + '.strm'), content, meta, url=url):
            return False
        _create_nfo(os.path.join(movie_path, title + '.nfo'), content, meta)
        return True
    if content == 'tvshow':
        tvshow_dir = _name_format(('{title_} ({year})',), title_=title, meta=meta)
        tvshow_path = os.path.join(folder_path, tvshow_dir)
        _create_nfo(os.path.join(tvshow_path, 'tvshow.nfo'), content, meta)
        return True
    if content == 'episode':
        tvshow_dir = _name_format(('{title_} ({year})',), title_=meta['tvshowtitle'], meta=meta)
        tvshow_path = os.path.join(folder_path, tvshow_dir)
        return _add_episode(tvshow_path, meta['tvshowtitle'], meta.get('year'), meta, season_eps=None, url=url) is not None

    return False


def update(content, title=None, meta=None):
    folder_path = addon.setting(_CONTENT_LIBRARY_SETTINGS.get(content, '')).decode('utf-8')
    if not folder_path:
        return
    if content == 'tvshow':
        if title:
            tvshows_dirs = [_name_format(('{title_} ({year})',), title_=title, meta=meta).encode('utf-8')]
        elif xbmcvfs.exists(os.path.join(folder_path, '')):
            tvshows_dirs = xbmcvfs.listdir(folder_path)[0]
        else:
            return
        # (fixme) Should we lock some other file (e.g. $addon/resources/settings.xml)?!?
        # (fixme) Hanlde the blocking longer than timeout (5 secs) scenario
        with portalocker.Lock(os.path.join(addon.info('profile'), 'settings.xml'), 'r'):
            for tvshow_dir in tvshows_dirs:
                eps_added = _add_tvshow_episodes(os.path.join(folder_path, tvshow_dir.decode('utf-8')), title, meta)
                if eps_added > 0:
                    yield tvshow_dir, eps_added


def scan():
    while xbmc.getCondVisibility('Library.IsScanningVideo'):
        xbmc.sleep(1000)
    xbmc.executebuiltin('UpdateLibrary(video)')


def _add_tvshow_episodes(tvshow_path, title=None, meta=None):
    if not meta:
        tvshow_path = xbmc.makeLegalFilename(tvshow_path)
        tvshow_nfo_path = os.path.join(tvshow_path, 'tvshow.nfo')
        if not xbmcvfs.exists(tvshow_nfo_path):
            return 0
        with File(tvshow_nfo_path) as fil:
            meta = _scan_nfo('tvshow', fil.read())

    item = {
        'tvdb': meta.get('tvdb'),
        'imdb': meta.get('imdb'),
    }
    dbs.meta([item], content='tvshow_seasons')
    if not title:
        # (fixme) this  has to be fixed in tvdb!!!
        title = item.get('title').decode('utf-8')
        if not title:
            return 0

    db_eps = {sn:sorted([int(e.get('episode', '0')) for e in item.get('episodes', [])
                         if e.get('season') == sn])
              for sn in [s['season'] for s in item.get('seasons', []) if s.get('season')]}

    library_eps = _fetch_local_content('episodes', item)

    return sum([
        1 if _add_episode(tvshow_path, title, item.get('year'), ep, db_eps.get(ep.get('season'), [])) else 0
        for ep in item.get('episodes', []) if (int(ep.get('season')), int(ep.get('episode'))) not in library_eps])


def _add_episode(tvshow_path, tvshowtitle, year, meta, season_eps, url=None):
    if not season_eps:
        tvshow_path = xbmc.makeLegalFilename(tvshow_path)
        if not xbmcvfs.exists(os.path.join(tvshow_path, '')):
            return None
        for episode_dir in xbmcvfs.listdir(tvshow_path)[0]:
            season, first_ep, last_ep = re.search(r'S([0-9]+)e([0-9]+)-?([0-9]+)?', episode_dir).groups()
            if int(season) == int(meta['season']) and int(first_ep) <= int(meta['episode']) <= int(last_ep or meta['episode']):
                episode_dirpath = os.path.join(tvshow_path, episode_dir)
                break
        else:
            return None
    elif len(season_eps) >= 2:
        episode_dirpath = os.path.join(tvshow_path,
                                       u'{tvshowtitle} S{season:02d}e{first_ep:02d}-{last_ep:02d}'.format(
                                           tvshowtitle=tvshowtitle,
                                           season=int(meta['season']),
                                           first_ep=int(season_eps[0]),
                                           last_ep=int(season_eps[-1])))
    else:
        episode_dirpath = os.path.join(tvshow_path,
                                       u'{tvshowtitle} S{season:02d}e{episode:02d}'.format(
                                           tvshowtitle=tvshowtitle,
                                           season=int(meta['season']),
                                           episode=int(meta['episode'])))
    episode_basename = os.path.join(episode_dirpath,
                                    u'{tvshowtitle} - {season}x{episode:02d} - {title}'.format(
                                        tvshowtitle=tvshowtitle,
                                        season=meta['season'],
                                        episode=int(meta['episode']),
                                        title=meta['title'].decode('utf-8')))
    if year and 'year' not in meta:
        meta['year'] = year
    return _create_strm(episode_basename + '.strm', 'episode', meta, url=url, tags=('tvshowtitle', 'season', 'episode'))


def _name_format(fmts, title_, meta):
    for fmt in fmts:
        try:
            return fmt.format(title_=title_, **meta)
        except Exception:
            pass
    return title_


def _create_strm(path, content, meta, url=None, tags=()):
    meta = {tag:meta[tag] for tag in ('title', 'year', 'imdb', 'tmdb', 'poster') + tags if tag in meta}
    path = xbmc.makeLegalFilename(path)
    if not url:
        strm_content = addon.itemaction('sources.dialog',
                                        name=urllib.quote_plus(meta['title']),
                                        content=content,
                                        meta=urllib.quote_plus(json.dumps(meta)))
    elif not xbmcvfs.exists(path):
        return None
    else:
        strm_content = addon.itemaction('sources.play',
                                        name=urllib.quote_plus(meta['title']),
                                        content=content,
                                        url=urllib.quote_plus(url),
                                        meta=urllib.quote_plus(json.dumps(meta)))
    xbmcvfs.mkdirs(os.path.dirname(path))
    with File(path, 'w') as fil:
        fil.write(strm_content.encode('utf-8') + '\n')
    return path


def _create_nfo(path, content, meta):
    for url in _NFO_URLS.get(content, ()):
        try:
            nfo_content = url.format(**meta)
            path = xbmc.makeLegalFilename(path)
            xbmcvfs.mkdirs(os.path.dirname(path))
            with File(path, 'w') as fil:
                fil.write(nfo_content + '\n')
            return path
        except Exception:
            pass
    return None


def _scan_nfo(content, nfo):
    meta = {}
    for url in _NFO_URLS.get(content, ()):
        try:
            placeholders = []
            def scan_placeholder(match):
                placeholders.append(match.group(1))
                return '(.*)'

            pat = re.sub(r'\\{([a-zA-Z_]*)\\}', scan_placeholder, re.escape(url))
            match = re.search(pat, nfo)
            if match:
                for value in match.groups():
                    meta.update({placeholders.pop(0): value})
        except Exception:
            pass

    return meta


_JSON_QUERIES = {
    'movies': '{{"jsonrpc": "2.0", \
        "id": "libMovies", \
        "method": "VideoLibrary.GetMovies", \
        "params": {{ \
            "sort": {{"order": "ascending", "method": "title"}}, \
            "filter": {{"operator": "is", "field": "title", "value": "{title}"}}, \
            "properties": ["file", "year"] \
        }} \
    }}',
    'tvshows': '{{"jsonrpc": "2.0", \
        "id": "libTVShows", \
        "method": "VideoLibrary.GetTVShows", \
        "params": {{ \
            "sort": {{"order": "ascending", "method": "title"}}, \
            "filter": {{"operator": "is", "field": "title", "value": "{title}"}}, \
            "properties": ["year"] \
        }} \
    }}',
    'episodes': '{{"jsonrpc": "2.0", \
        "id": "libEpisodes", \
        "method": "VideoLibrary.GetEpisodes", \
        "params": {{ \
            "sort": {{"order": "ascending", "method": "title"}}, \
            "tvshowid": {tvshowid}, \
            "properties": ["file", "season", "episode"] \
        }} \
    }}',
}


def _fetch_local_content(content, meta):
    try:
        year = int(meta['year'])
    except Exception:
        year = 0
    try:
        if content == 'movie':
            query = _JSON_QUERIES['movies'].format(**meta)
            res = _json_rpc(query)['result']['movies']
            return [i['file'] for i in res if not year or any(y == i.get('year') for y in range(year-1, year+2))]

        if content == 'episodes':
            query = _JSON_QUERIES['tvshows'].format(**meta)
            res = _json_rpc(query)['result']['tvshows']
            tvshowid = [i['tvshowid'] for i in res if not year or any(y == i.get('year') for y in range(year-1, year+2))][0]
            query = _JSON_QUERIES['episodes'].format(tvshowid=tvshowid, **meta)
            res = _json_rpc(query)['result']['episodes']
            return [(i['season'], i['episode']) for i in res]

    except Exception:
        pass
    return []


def _json_rpc(method, raise_ex=False):
    try:
        return json.loads(unicode(xbmc.executeJSONRPC(method), 'utf-8', errors='ignore'))
    except Exception as ex:
        if raise_ex:
            raise ex
        return None
