# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import urlparse

from .. import info


def run(url):
    app, path = urlparse.urlparse(url)[1:3]
    __import__(app, globals(), locals(), []).run(info('platform.os'), path)


def probe(url):
    app, _path = urlparse.urlparse(url)[1:3]
    if info('platform.os') == 'ios':
        raise Exception('%s external player not supported on iOS platform' % app)
