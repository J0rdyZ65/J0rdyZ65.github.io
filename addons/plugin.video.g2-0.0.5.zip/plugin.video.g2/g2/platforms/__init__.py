# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2018-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import xbmc
from xbmc import LOGDEBUG, LOGNOTICE, LOGERROR


_PLATFORM_OSES = {
    'android': 'System.Platform.Android',
    'windows': 'System.Platform.Windows',
    'linux': 'System.Platform.Linux',
    'ios': 'System.Platform.IOS',
}

for platform_os, condition in _PLATFORM_OSES.iteritems():
    if xbmc.getCondVisibility(condition):
        _PLATFORM_OS = platform_os
        break
else:
    _PLATFORM_OS = 'unknown'

_PLATFORM_VERSION = xbmc.getInfoLabel('System.BuildVersion').split()[0]
_INFOS = {
    'platform': 'kodi',
    'version': _PLATFORM_VERSION,
    'name': xbmc.getInfoLabel('System.FriendlyName'),
    'language': xbmc.getLanguage(xbmc.ISO_639_1),
    'version.major': _PLATFORM_VERSION.split('.')[0],
    'platform.os': _PLATFORM_OS,
    # (fixme) retrieve the actual platform logging level
    'logging': xbmc.LOGDEBUG if hasattr(xbmc, 'log_file') else xbmc.LOGNOTICE,
}


def info(nfo, default=None):
    return _INFOS.get(nfo, default)


def log(msg, level=LOGNOTICE):
    xbmc.log(msg, level)


def androidapp(app):
    xbmc.executebuiltin('StartAndroidActivity(%s)' % app)
