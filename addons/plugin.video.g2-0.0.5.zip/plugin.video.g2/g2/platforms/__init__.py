# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2018 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import ast

import xbmc
from xbmc import LOGDEBUG, LOGNOTICE, LOGERROR
import xbmcgui

from . import addon


_PLATFORM_VERSION = xbmc.getInfoLabel('System.BuildVersion').split()[0]
_INFOS = {
    'platform': 'kodi',
    'version': _PLATFORM_VERSION,
    'language': xbmc.getLanguage(xbmc.ISO_639_1),
    'version.major': _PLATFORM_VERSION.split('.')[0],
}
_HOME_WINDOW = 10000


def info(nfo, default=None):
    return _INFOS.get(nfo, default)


def log(msg, level=LOGNOTICE):
    xbmc.log(msg, level)


def prop(module='', value=None, name='status'):
    def propname(module, name):
        prop_name = addon.info('id')
        if module:
            prop_name += ('.' if prop_name else '') + module
        if name:
            prop_name += ('.' if prop_name else '') + name
        return prop_name

    prop_name = propname(module, name)
    home_win = xbmcgui.Window(_HOME_WINDOW)
    if value is None:
        value = home_win.getProperty(prop_name)
        try:
            return ast.literal_eval(value or 'None')
        except Exception:
            return None
    elif value == '':
        home_win.clearProperty(prop_name)
    else:
        home_win.setProperty(prop_name, repr(value))

    return prop_name
