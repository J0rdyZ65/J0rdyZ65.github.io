# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2018-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

from collections import OrderedDict

import xbmc


_PLATFORM_OSES = OrderedDict([
    ('android', 'System.Platform.Android'),
    ('ios', 'System.Platform.IOS'),
    ('linux', 'System.Platform.Linux'),
    ('windows', 'System.Platform.Windows'),
])

for platform_os, condition in _PLATFORM_OSES.items():
    if xbmc.getCondVisibility(condition):
        _PLATFORM_OS = platform_os
        break
else:
    _PLATFORM_OS = 'unknown'

_PLATFORM_VERSION = xbmc.getInfoLabel('System.BuildVersion').split()[0]
_INFOS = {
    'platform': 'kodi',
    'version': _PLATFORM_VERSION,
    'version.major': _PLATFORM_VERSION.split('.')[0],
    'platform.os': _PLATFORM_OS,
}


def info(nfo, default=None):
    if nfo == 'name':
        return xbmc.getInfoLabel('System.FriendlyName')
    elif nfo == 'language':
        return xbmc.getLanguage(xbmc.ISO_639_1)
    elif nfo == 'logging':
        # (fixme) [FUNC] retrieve the actual platform logging level
        # NOTE: the Kodi xbmc module doesn't have the set_env method which is instead
        # present in the stub xbmc module for offline testing.
        return xbmc.LOGDEBUG if hasattr(xbmc, 'set_env') else xbmc.LOGNOTICE
    return _INFOS.get(nfo, default)
