# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2018 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import sys

import xbmc
import xbmcaddon


class MonitorSettings(xbmc.Monitor):
    def __init__(self, *args, **kwargs):
        super(MonitorSettings, self).__init__(*args, **kwargs)
        self.addon = None
        self.callbacks = []
        self.onSettingsChanged()

    def onSettingsChanged(self): # Kodi API # pylint: disable=invalid-name
        self.addon = xbmcaddon.Addon()
        for callback in self.callbacks:
            callback()

    def get_setting(self, setid):
        return self.addon.getSetting(setid)

    def set_setting(self, setid, value):
        self.addon.setSetting(setid, value)

    def add_callback(self, callback):
        self.callbacks.append(callback)


_MONITOR_SETTINGS = MonitorSettings()

URL_EMPTY_ARG = '__***Empty***___'
URL_NONE_ARG = '__***None***___'

_ADDON = xbmcaddon.Addon()
_INFOS = {
    'id': _ADDON.getAddonInfo('id'),
    'version': _ADDON.getAddonInfo('version'),
    'path': xbmc.translatePath(_ADDON.getAddonInfo('path')).decode('utf-8'),
    'profile': xbmc.translatePath(_ADDON.getAddonInfo('profile')).decode('utf-8'),
}


def info(nfo, default=None):
    return _INFOS.get(nfo, default)


def on_setting_change(callback):
    _MONITOR_SETTINGS.add_callback(callback)


def setting(setid):
    return _MONITOR_SETTINGS.get_setting(setid)


def itemaction(action, plugin=None, **kwargs):
    return _action('%s?%s'%(plugin or sys.argv[0] or 'plugin://%s/' % info('id'),
                            action if plugin else 'action=%s'%action), **kwargs)


def _action(action, args_sep='&', **kwargs):
    return args_sep.join([action] +
                         ['%s=%s' % (k,
                                     URL_EMPTY_ARG if not str(v) else
                                     URL_NONE_ARG if v is None else v) for k, v in kwargs.iteritems()])
