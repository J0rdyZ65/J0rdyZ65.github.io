# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import xbmc
import xbmcgui

from g2.libraries.database import Database

from ... import addon
from ...language import _

from . import EventHandler


class KeyboardDialog(xbmcgui.WindowXMLDialog):
    evh = EventHandler()
    heading_id = 101
    edit_button_id = 201
    history_buttons_id = [411, 412, 413, 421, 422, 423, 431, 432, 433]
    close_button_id = 501

    def __init__(self, *args, **kwargs):
        super(KeyboardDialog, self).__init__(*args)
        self.default = kwargs.get('default')
        self.heading = kwargs.get('heading', addon.info('id'))
        self.history = kwargs.get('history')
        self.historydb = Database('settings', 'input_history', 'input_type', 'history')
        self.history_buttons_ctl = {}
        self.value = None

    def onInit(self):
        heading_ctl = self.getControl(self.heading_id)
        edit_ctl = self.getControl(self.edit_button_id)
        close_button_ctl = self.getControl(self.close_button_id)

        history = self.historydb.get(self.history, [])
        for button_id in self.history_buttons_id:
            try:
                hist = history.pop(0)
            except Exception:
                hist = ''
            self.history_buttons_ctl[button_id] = self.getControl(button_id)
            self.history_buttons_ctl[button_id].setLabel(hist)

        heading_ctl.setLabel(self.heading)
        edit_ctl.setLabel(self.default or _('Click here to enter a new term'))
        close_button_ctl.setLabel(_('Close'))
        self.setFocus(edit_ctl)

    def onClick(self, control_id):
        self.evh.onclick(control_id, self)

    @evh.click(edit_button_id)
    def _edit_default(self, _control_id):
        self._edit(self.default)

    @evh.click(close_button_id)
    def _close(self, _control_id):
        self.close()

    @evh.click(history_buttons_id)
    def _edit_history(self, control_id):
        self._edit(self.history_buttons_ctl[control_id].getLabel())

    def _edit(self, value):
        keyb = xbmc.Keyboard(value or '', self.heading)
        keyb.doModal()
        if keyb.isConfirmed():
            value = keyb.getText()
            if value:
                self.value = value.decode('utf-8') # decode kodi keyboard input
                history = [self.value] + [h for h in self.historydb.get(self.history, []) if h != self.value]
                self.historydb[self.history] = history[:len(self.history_buttons_id)]
                self.close()

    def isConfirmed(self):
        return self.value is not None

    def getText(self):
        return self.value
