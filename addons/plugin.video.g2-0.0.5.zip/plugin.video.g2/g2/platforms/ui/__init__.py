# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import xbmc
from xbmc import Player, sleep
import xbmcgui

from ..addon import info
from ..actions import url as actionsurl
from . import d
from . import dialog
from .dialog import busy as busydialog, idle
from .media import addon_icon, addon_poster, addon_banner, addon_thumb, addon_fanart, addon_next, media, resource_themes


_ADDON_SETTINGS_WINDOW_ID = 10140
_TEXTVIEWER_WINDOW_ID = 10147

_MONITOR = xbmc.Monitor()


def open_settings(category='0'):
    xbmc.executebuiltin('Addon.OpenSettings(%s)' % info('id'))
    xbmc.executebuiltin('SetFocus(%d)' % (int(category) + 100))
    return xbmcgui.Window(_ADDON_SETTINGS_WINDOW_ID)


def open_textviewer(title, text):
    xbmc.executebuiltin('ActivateWindow(%d)' % _TEXTVIEWER_WINDOW_ID)
    win = xbmcgui.Window(_TEXTVIEWER_WINDOW_ID)

    sleep(300)
    for dummy in range(50):
        try:
            sleep(10)
            win.getControl(1).setLabel(title)
            win.getControl(5).setText(text)
            break
        except Exception:
            pass
    return 


def abortRequested(timeout=None):
    return _MONITOR.waitForAbort(timeout) if timeout else _MONITOR.abortRequested()


def refresh(action=None, **kwargs):
    return xbmc.executebuiltin('Container.Refresh') if not action else \
           xbmc.executebuiltin('Container.Update(%s)'%actionsurl(action, **kwargs))


def player_info():
    return (xbmc.getInfoLabel('VideoPlayer.Title'),
            xbmc.getInfoLabel('VideoPlayer.Year'),
            xbmc.getInfoLabel('VideoPlayer.mpaa'),
            xbmc.getInfoLabel('VideoPlayer.IMDBNumber'))
