# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import os

from g2.libraries import log
from g2.libraries import advsettings

from .. import addon


def addon_banner():
    return media('banner', 'DefaultVideo.png')


def addon_fanart():
    return media('fanart', addon.info('fanart'))


def addon_icon():
    return media('icon', addon.info('icon'))


def addon_next():
    return media('next', 'DefaultFolderBack.png')


def addon_poster():
    return media('poster', 'DefaultVideo.png')


def addon_thumb():
    return media('icon', addon.info('icon'))


def media(icon, icon_default='DefaultFolder.png'):
    if not icon:
        return icon_default

    if '://' in icon:
        return icon

    media.themes = addon.prop('ui', name='themes')

    if not media.themes:
        media.themes = resource_themes()

    appearance = addon.setting('appearance').lower()
    if appearance in ['-', ''] or appearance not in media.themes:
        return icon_default

    theme = media.themes[appearance]
    theme_path = theme['path']
    icon = theme['mappings'].get(icon, icon)

    icon_path = os.path.join(theme_path, icon)
    icon, ext = os.path.splitext(icon)
    if ext and os.path.exists(icon_path):
        return icon_path

    for ext in ['.png', '.jpg']:
        icon_path = os.path.join(theme_path, icon+ext)
        if os.path.exists(icon_path):
            return icon_path

    return icon_default


def resource_themes():
    media_desc = advsettings.setting('media')

    if '' not in media_desc:
        # default entry for the g2 resources/media folder
        media_desc[''] = {
            'themes': 'folder',
        }

    themes = {'-': None}
    default_media_path = ['resources', 'media']
    for res, med in media_desc.iteritems():
        if res == '':
            media_path = os.path.join(addon.info('path'), *default_media_path) #pylint: disable=E0012
        else:
            addon_id = med.get('addon_id')
            if not addon_id or not addon.exists(addon_id):
                continue
            media_path = os.path.join(addon.info2(addon_id, 'path'), *med.get('media_path', default_media_path))

        if med.get('themes') != 'folder':
            # Single theme
            theme_name = res.lower()
            themes[theme_name] = {
                'path': media_path,
                'mappings': med.get('mappings', {}),
            }
        elif os.path.exists(os.path.join(media_path, '')):
            # Multiple themes
            for theme in os.listdir(media_path):
                theme_path = os.path.join(media_path, theme)
                if os.path.isdir(theme_path):
                    theme_name = theme if not res else '%s:%s'%(res, theme)
                    theme_name = theme_name.lower()
                    themes[theme_name] = {
                        'path': theme_path,
                        'mappings': med.get('mappings', {}),
                    }

    log.debug('{m}.{f}: %d themes found: %s', len(themes.keys()), ', '.join(sorted(themes.keys())))

    addon.prop('ui', themes, name='themes')

    return themes
