# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
import ast
import json
import inspect
from six.moves import urllib

import xbmc

from g2.libraries import advsettings

from .addon import info


# (fixme) [KODI18/IDE] find a way to trigger the re-read of the actions annotations without unloading the cached modules
_ANNOTATIONS = advsettings.setting('actions')


def action(*types):
    types = list(types)
    def decorator(func):
        argspec = inspect.getargspec(func)
        args = argspec.args
        if argspec.varargs or argspec.keywords:
            raise Exception('%s: *args or **kwargs not allowed in action functions' % func.__name__)
        if len(args) > len(types):
            raise Exception('%s: the annotation miss %d argument types' % (func.__name__, len(args)-len(types)))
        func.is_action = True
        func.__str_annotation__ = {arg: re.search(r'\'(\w+)\'', repr(typ)).group(1) for arg, typ in zip(args, types)}
        return func
    return decorator


def run(action, **kwargs):
    xbmc.executebuiltin(plugin(action, **kwargs))


def plugin(action, **kwargs):
    return 'RunPlugin(%s)' % url(action, **kwargs)


def script(action, **kwargs):
    return 'RunScript(%s)' % ','.join(
        [action] +
        ['{kwa}={arg}'.format(kwa=kwa,
                              # unicode encoding for script actions
                              arg=urllib.parse.quote_plus(str(arg.encode('utf-8') if isinstance(arg, unicode) else arg)))
         for kwa, arg in kwargs.iteritems() if arg is not None])


def url(action, **kwargs):
    annotation = _ANNOTATIONS.get(action, {})

    args = ['plugin://%s/?action=%s' % (info('id'), action)]

    for kwa, arg in kwargs.iteritems():
        if arg is None:
            continue
        if not annotation.get(kwa):
            pass
        elif annotation[kwa] == 'str':
            if isinstance(arg, str):
                pass # py3 requires an encode
            elif isinstance(arg, unicode):
                arg = arg.encode('utf-8')
            else:
                arg = str(arg)
        elif annotation[kwa] in ('list', 'tuple', 'dict'):
            if kwa == 'meta' and annotation[kwa] == 'dict':
                meta = arg if isinstance(arg, dict) else dict(arg)
                arg = {t:meta[t] for t in (
                    'imdb',
                    'tmdb',
                    'tvdb',
                    'title',
                    'tvshowtitle',
                    'year',
                    'season',
                    'episode',
                    'season_episodes',
                    'poster',
                ) if meta.get(t)}
            arg = json.dumps(arg)
        else:
            arg = repr(arg)

        args.append('{kwa}={arg}'.format(kwa=kwa, arg=urllib.parse.quote_plus(arg)))

    return '&'.join(args)


def parse(action_url):
    kwargs = dict(urllib.parse.parse_qsl(action_url.replace('?', '', 1)))

    action = kwargs.get('action')
    if not action:
        return None, {}
    del kwargs['action']

    annotation = _ANNOTATIONS.get(action)
    if kwargs and not annotation:
        raise Exception('%s: missing annotation' % action)

    for kwa, arg in kwargs.iteritems():
        if annotation[kwa] == 'str':
            kwargs[kwa] = arg.decode('utf-8')
        elif annotation[kwa] in ('list', 'tuple', 'dict'):
            kwargs[kwa] = json.loads(arg)
        else:
            kwargs[kwa] = ast.literal_eval(arg)

    return action, kwargs
