# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2018-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import os
import time
import errno

from . import log

class ExceptionAlreadyLocked(Exception):
    pass

if os.name == 'nt':
    import msvcrt

    def _trylock(fil):
        try:
            msvcrt.locking(fil.fileno(), msvcrt.LK_NBLCK, 1)
        except IOError as ex:
            log.debug('{m}.{f}: %s', repr(ex))
            raise ExceptionAlreadyLocked(str(ex))

    def _unlock(fil):
        msvcrt.locking(fil.fileno(), msvcrt.LK_UNLCK, 1)

elif os.name == 'posix':
    import fcntl

    def _trylock(fil):
        try:
            fcntl.lockf(fil, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except IOError as ex:
            if ex.errno in (errno.EACCES, errno.EAGAIN):
                raise ExceptionAlreadyLocked()

    def _unlock(fil):
        fcntl.lockf(fil, fcntl.LOCK_UN)

class ExclusiveLock(object):
    def __init__(self, filename, sleep=time.sleep):
        self.filename = filename
        self.sleep = sleep
        self.fil = None

    def __enter__(self):
        if not self.fil:
            self.fil = open(self.filename, 'a')
            while True:
                try:
                    _trylock(self.fil)
                    break
                except ExceptionAlreadyLocked as ex:
                    if not self.sleep:
                        raise ExceptionAlreadyLocked(str(ex))

                log.debug('{m}.{f}: %s: already locked, sleeping for 1 seconds...', self.filename)
                self.sleep(1)

        return self.fil

    def __exit__(self, _type, _value, _tb):
        if self.fil:
            _unlock(self.fil)
            self.fil.close()
