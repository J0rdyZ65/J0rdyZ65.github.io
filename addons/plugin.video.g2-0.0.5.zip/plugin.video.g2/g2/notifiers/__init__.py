# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


from g2.libraries import log
from g2.libraries import addon

from g2 import pkg


def info(package, module):
    if not hasattr(module, 'info'):
        nfo = []
    elif callable(module.info):
        nfo = module.info(package, module)
    else:
        nfo = module.info
    nfo = [dict(nfo)] if type(nfo) == dict else list(nfo)
    return nfo


def notices(notes, targets=None, **kwargs):
    if isinstance(notes, basestring):
        notes = [notes]
    if not targets:
        targets = []
    elif isinstance(targets, basestring):
        targets = [targets]

    _all_modules_method('notices', targets, notes, **kwargs)


def events(start, targets=None, **kwargs):
    if start is None:
        start = False
    return _all_modules_method('events', targets, start, **kwargs)


def _all_modules_method(method, targets, *args, **kwargs):
    res = None
    for module in [mi for mi in pkg.info('notifiers').itervalues()
                   if method in mi['methods'] and (not targets or set(mi['targets']) & set(targets))]:
        try:
            with module.context() as modules:
                if modules:
                    res = getattr(modules[0], method)(*args, **kwargs)
        except Exception as ex:
            log.error('{m}: %s.%s: %s', module, method, repr(ex))

    return res
