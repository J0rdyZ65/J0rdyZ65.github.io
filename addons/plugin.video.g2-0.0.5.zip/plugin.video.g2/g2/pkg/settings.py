# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import re

from g2 import defs
from g2.libraries import fs
# from g2.libraries import log
from g2.libraries import addon
from g2.libraries import language
from g2.libraries.language import _, xgettext


_KINDS_DESC = {
    'providers': {
        'id': 'providers',
        'dialog_order': 1,
        'label': language.msgcode('Providers'),
        'settings': [{
            'id': 'preferred_provider_1',
            'label': language.msgcode('1st preferred source provider'),
            'spec': 'type="select" values="-|{modules_names}"',
            'default': '-',
        }, {
            'id': 'preferred_provider_2',
            'label': language.msgcode('2nd preferred source provider'),
            'spec': 'type="select" values="-|{modules_names}"',
            'default': '-',
        }, {
            'id': 'preferred_provider_3',
            'label': language.msgcode('3rd preferred source provider'),
            'spec': 'type="select" values="-|{modules_names}"',
            'default': '-',
        }, {
            'id': 'preferred_provider_4',
            'label': language.msgcode('4th preferred source provider'),
            'spec': 'type="select" values="-|{modules_names}"',
            'default': '-',
        }],
    },
    'resolvers': {
        'id': 'resolvers',
        'dialog_order': 2,
        'label': language.msgcode('Resolvers'),
        'settings': [{
            'id': 'preferred_resolver_1',
            'label': language.msgcode('1st preferred source host'),
            'spec': 'type="select" values="-|{modules_names}"',
            'default': '-',
        }, {
            'id': 'preferred_resolver_2',
            'label': language.msgcode('2nd preferred source host'),
            'spec': 'type="select" values="-|{modules_names}"',
            'default': '-',
        }, {
            'id': 'preferred_resolver_3',
            'label': language.msgcode('3rd preferred source host'),
            'spec': 'type="select" values="-|{modules_names}"',
            'default': '-',
        }, {
            'id': 'preferred_resolver_4',
            'label': language.msgcode('4th preferred source host'),
            'spec': 'type="select" values="-|{modules_names}"',
            'default': '-',
        }],
    },
    'dbs': {
        'id': 'dbs',
        'dialog_order': 3,
    },
    'notifiers': {
        'id': 'notifiers',
        'dialog_order': 4,
    },
}

_CONTENT_INFO = {
    "0": {
        'label': xgettext('None'),
        'content': (),
    },
    "1": {
        'label': xgettext('All'),
        'content': ('movie', 'episode'),
    },
    "2": {
        'label': xgettext('Movies'),
        'content': ('movie',),
    },
    "3": {
        'label': xgettext('TV shows'),
        'content': ('episode',),
    },
    # Add new content combinations here (e.g. Movies&Doc)
}

_RESOURCES_PATH = os.path.join(addon.PATH, 'resources')


def kinds():
    return _KINDS_DESC


def update_appearance_setting_skema(themes):
    themes = sorted([t.capitalize() for t in themes.keys()], key=lambda t: t if ':' in t else ' :'+t)

    settings_skema_path = os.path.join(_RESOURCES_PATH, 'settings.xml')
    old_settings_skema = ''
    new_settings_skema = ''
    with fs.File(settings_skema_path) as fil:
        for line in fil.read().splitlines():
            line += '\n'
            old_settings_skema += line
            if 'id="appearance"' not in line:
                new_settings_skema += line
            else:
                new_settings_skema += re.sub(r' values="[^"]*?" ', ' values="'+'|'.join(themes)+'" ', line)

    if new_settings_skema == old_settings_skema:
        return False
    else:
        with fs.File(settings_skema_path, 'w') as fil:
            fil.write(new_settings_skema)
        return True


def update_settings_skema(info, packages):
    settings_skema_path = os.path.join(_RESOURCES_PATH, 'settings.xml')
    old_settings_skema = ''
    new_settings_skema = ''
    with fs.File(settings_skema_path) as fil:
        suppress_skema = False
        line = ''
        lines = fil.read().splitlines()

    while lines:
        line = lines.pop(0) + '\n'
        old_settings_skema += line
        if any('label="%s"'%k.get('label') in line for k in _KINDS_DESC.itervalues()):
            suppress_skema = True
        if '</settings>' in line:
            break
        if not suppress_skema:
            new_settings_skema += line

    new_settings_skema += _update_settings_skema(info, packages) + '\n'

    new_settings_skema += line
    while lines:
        line = lines.pop(0) + '\n'
        new_settings_skema += line
        old_settings_skema += line

    if new_settings_skema == old_settings_skema:
        return False

    with fs.File(settings_skema_path, 'w') as fil:
        fil.write(new_settings_skema)
    return True


def _update_settings_skema(info, packages):
    settings_skema = []

    def add_setting(kpm, name, label=None, spec='type="text"', default='', enabled=True, visible_indexes=None):
        try:
            add_setting.index += 1
        except Exception:
            add_setting.index = 1

        if visible_indexes is None:
            visible = ''
        elif not visible_indexes:
            visible = 'visible="false" '
        else:
            visible = 'visible="' + '+'.join(['eq(%d,true)' % (i - add_setting.index) for i in visible_indexes]) + '" '

        if kpm is None:
            if name is None:
                settings_skema.append('\t\t<setting type="sep" />')
                name = enable = ''
            settings_skema.append('\t\t<setting type="lsep" label="%s[CR]" %s/>' % (name, visible))
        else:
            setid = _setting_id(kpm[0],
                                '' if len(kpm) < 2 else kpm[1],
                                '' if len(kpm) < 3 else kpm[2],
                                name)
            if not label:
                label = name.capitalize()
            enable = '' if enabled else 'enable="false" '
            settings_skema.append('\t\t<setting id="%s" label="%s" %s default="%s" %s%s/>' %
                                  (setid, label, spec, default, visible, enable))

        return [] if not enabled else [add_setting.index]

    def add_separator(label='', visible_indexes=None):
        add_setting(None, label, visible_indexes=visible_indexes)

    def add_category(label=None):
        settings_skema.append('\t</category>' if not label else '\t<category label="%s">' % label)

    for kindesc in sorted([v for v in _KINDS_DESC.values() if v.get('settings')], key=lambda k: k['dialog_order']):
        # Category settings
        kind = kindesc['id']
        add_category(kindesc['label'])

        kind_modules = set([m.split('.')[-1] for m in info(kind, force_refresh=True, include_disabled=True).iterkeys()])
        if kind == 'resolvers':
            kind_modules |= set(reduce(lambda x, y: x+y,
                                       [m['sources'] for m in info('providers', include_disabled=True).itervalues()
                                        if 'sources' in m], []))
        kind_modules_names = '|'.join(sorted(kind_modules))
        for setinfo in kindesc['settings']:
            add_setting((kind,), setinfo['id'],
                        label=setinfo.get('label'),
                        spec=setinfo.get('spec').format(modules_names=kind_modules_names),
                        default=setinfo.get('default'))

        for dummy, package_name in packages(kind, addons_only=True):
            add_separator(None)

            package = {}
            modules = info(kind, package_name, package=package, include_disabled=True)

            # Packages' standard settings
            visible_indexes = add_setting((kind, package_name), 'enabled',
                                          label=_('[COLOR FF6db9e5]{package_name}[/COLOR]',
                                                  package_name=package_name.replace('_', ' ').title()),
                                          spec='type="bool"',
                                          enabled=package.get('enabled', True),
                                          default='true')

            add_setting((kind, package_name), 'priority',
                        label=language.msgcode('Priority'),
                        spec='subsetting="true" type="number"',
                        default=str(defs.DEFAULT_PACKAGE_PRIORITY),
                        visible_indexes=visible_indexes)

            # Packages' custom settings
            for setinfo in package.get('settings', []):
                add_setting((kind, package_name), setinfo['id'],
                            label=language.msgcode(setinfo.get('label')),
                            spec='subsetting="true" ' + setinfo['spec'],
                            default=setinfo['default'],
                            visible_indexes=visible_indexes)

            if len(modules) >= 5:
                visible_indexes += add_setting((kind, package_name), 'show.modules.settings',
                                               label=language.msgcode('Show modules settings'),
                                               spec='subsetting="true" type="bool"',
                                               default="false",
                                               visible_indexes=visible_indexes)

            for module in sorted(modules.values(), key=lambda m: m['name']):
                # Modules' standard settings
                if kind == 'resolvers':
                    setid = 'enabled'
                    spec = 'subsetting="true" type="bool"'
                    default = 'true'
                elif kind == 'providers':
                    setid = 'content'
                    spec = 'type="enum" lvalues="{lvalues}" entries="{entries}"'
                    options = zip(*[(str(language.msgcode(cs['label'])), cc)
                                    for cc, cs in sorted(_CONTENT_INFO.items(), key=lambda it: int(it[0]))
                                    if set(module['content']) >= set(cs['content'])])
                    spec = spec.format(spec, lvalues='|'.join(options[0]), entries='|'.join(options[1]))
                    default = [cc for cc, cs in _CONTENT_INFO.iteritems() if set(cs['content']) == set(module['content'])]
                    default = '0' if not default else default[0]
                    # (fixme) if the current setting value is different from the allowed values, change it!
                else:
                    break
                add_setting((kind, package_name, module['name']), setid,
                            label=module['name'].capitalize(),
                            spec=spec,
                            default=default,
                            enabled=module.get('enabled', True),
                            visible_indexes=visible_indexes)

                # Modules' custom settings
                for setinfo in module.get('settings', []):
                    add_setting((kind, package_name, module['name']), setinfo['id'],
                                label=language.msgcode(setinfo.get('label')),
                                spec='subsetting="true" ' + setinfo['spec'],
                                default=setinfo['default'],
                                visible_indexes=visible_indexes)

        add_category()

    return '\n'.join(settings_skema)


def setting(kind, package='', module='', name='enabled'):
    return addon.setting(_setting_id(kind, package, module, name))


def content_setting(package, module):
    content = setting('providers', package, module, name='content')
    return _CONTENT_INFO.get(content, {'content': ()})['content']


def _setting_id(kind, package='', module='', name='enabled'):
    return ':'.join([kind, package, module, name])
