# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import os
import abc
import sys
import inspect
import urllib2
import datetime

import importer

from g2.libraries import cache
from g2.libraries import workers

from g2.platforms import log
from g2.platforms import addon

from . import sources
from . import instargets

try:
    from .mimps import install_importers #pylint: disable=E0401
except Exception as ex:
    log.debug('{m}.{f}: %s', ex, trace=True)
    def install_importers(*_args, **_kwargs):
        pass

__all__ = ['packages', 'status', 'install', 'uninstall', 'info', 'setting', 'setting_name']


class ExceptionPackage(Exception):
    pass

class ExceptionPackageCache(Exception):
    pass


# NOTE: This is the path relative to the one present in sys.path.
# Remember to update it if you move the hierarchy around relative to sys.path
_PACKAGES_RELATIVE_PATH = 'g2.'
_PACKAGES_ATTRIBUTES = (
    'kind',
    'addons',
    'imports',
    'skip',
    'paths',
    'nick',
    'notice',
    )


def _kinds():
    return ('dbs', 'notifiers', 'providers', 'resolvers')


def pkgpath(kind='', name=''):
    from .. import __path__
    return os.path.join(__path__[0], kind, name)


def pkgfullname(kind='', name=''):
    fullname = '' if not kind else _PACKAGES_RELATIVE_PATH + kind
    if name:
        fullname += ('' if not fullname else '.') + name
    return fullname


class Context(object):
    lock = workers.Lock()
    locking_owner = {}

    def __init__(self, kind, package_name='', modules_names=None, search_paths=None, ignore_exc=False):
        self.fullname = '' if not kind else (_PACKAGES_RELATIVE_PATH + kind.split('.')[-1])
        if package_name:
            self.fullname += ('' if not self.fullname else '.') + package_name
        self.modules_names = [] if not modules_names or not modules_names[0] else modules_names
        self.modules_names = [str(m) for m in self.modules_names]
        self.search_paths = [] if not search_paths else list(search_paths)
        self.ignore_exc = ignore_exc
        self.sys_path = None
        self.streams = None
        self.urllib2_opener = None

    def __enter__(self):
        self._acquire_lock()
        self.streams = (sys.stdout, sys.stderr)
        self.sys_path = sys.path
        sys.path = self.search_paths + sys.path
        try:
            sys.stdout = open(os.devnull, 'w')
        except Exception:
            pass
        sys.stderr = sys.stdout
        self.urllib2_opener = urllib2._opener # pylint: disable=protected-access
        urllib2.install_opener(None)
        try:
            if not self.modules_names:
                log.debug('{m}.{f}: import %s', self.fullname)
            else:
                log.debug('{m}.{f}: from %s import %s', self.fullname, ', '.join(self.modules_names))
            module = __import__(self.fullname, globals(), locals(), self.modules_names, -1)
        except Exception as ex:
            self.__exit__(None, None, None)
            if not self.modules_names:
                log.error('{m}.{f}: import %s: %s', self.fullname, repr(ex), trace=True)
            else:
                log.error('{m}.{f}: from %s import %s: %s', self.fullname, ', '.join(self.modules_names), repr(ex), trace=True)
            return []

        if not self.modules_names:
            for module_name in self.fullname.split('.')[1:]:
                module = getattr(module, module_name)
            return [module]
        return [getattr(module, module_name) for module_name in self.modules_names]

    def __exit__(self, exc_type, exc_value, traceback):
        urllib2.install_opener(self.urllib2_opener)
        sys.stdout.close()
        sys.path = self.sys_path
        sys.stdout = self.streams[0]
        sys.stderr = self.streams[1]
        self._release_lock()
        if self.ignore_exc or not exc_value:
            return True
        log.debug('{m}.{f}: %s: %s', self.fullname, exc_value, trace=True)
        return False

    def _acquire_lock(self):
        current_thread = workers.current_thread()
        if self.lock.acquire(False):
            pass
        elif self.locking_owner.get('thread') == current_thread:
            if self.locking_owner.get('object') != self:
                log.debug('{m}.{f}: thread %s already own the lock for Context(%s, %s)',
                          current_thread.name, self.fullname, self.modules_names)
                return
            log.error('{m}.{f}: thread %s is re-entering the same Context(%s, %s)!',
                      current_thread.name, self.fullname, self.modules_names, trace=True)
            raise workers.WouldBlockError
        else:
            log.debug('{m}.{f}: thread %s waiting for Context(%s, %s) lock release by %s',
                      current_thread.name, self.fullname, self.modules_names,
                      # There is a small window where the [other] locking thread has acquired the lock and
                      # the locking_onwer has not been updated yet, so let's check it in order to prevent an exception
                      self.locking_owner['thread'].name if self.locking_owner.get('thread') else '---')
            self.lock.acquire(True)
        self.locking_owner['thread'] = current_thread
        self.locking_owner['object'] = self
        log.debug('{m}.{f}: thread %s acquired Context(%s, %s) lock',
                  current_thread.name, self.fullname, self.modules_names)

    def _release_lock(self):
        current_thread = workers.current_thread()
        if self.locking_owner.get('thread') != current_thread or self.locking_owner.get('object') != self:
            return
        self.locking_owner['thread'] = None
        self.locking_owner['object'] = None
        log.debug('{m}.{f}: thread %s released Context(%s, %s) lock',
                  current_thread.name, self.fullname, self.modules_names)
        self.lock.release()


class Module(dict):
    """Class representing an extension package module"""

    def __init__(self, value, package=None):
        dict.__init__(self, value)
        self.package = package or {}

    def __str__(self):
        return self.fullname()

    def kind(self):
        return '' if self.package.get('imports') else self.package['kind']

    def fullname(self):
        fname = '' if not self.package.get('name') else self.package['name'] + '.'
        if not self.package.get('imports'):
            fname += '' if self.module() == self['name'] else self.module() + '.'
        elif isinstance(self.package['imports'], basestring):
            fname += self.package['imports'] + '.'
        else:
            fname += self.package['imports'][self.get('import', 0)] + '.'
        return fname + self['name']

    def module(self):
        return self.get('module', self['name'])

    def package_module(self):
        if not self.package.get('name'):
            return ''
        if not self.package.get('imports'):
            return self.package['name']
        if isinstance(self.package['imports'], basestring):
            return self.package['imports']
        return self.package['imports'][self.get('import', 0)]

    def package_name(self):
        return self.package.get('name', '')

    def context(self, modules=None, ignore_exc=False):
        if self.package.get('name'):
            return Context(self.kind(), self.package_module(), modules or [self.module()],
                           self.package.get('search_paths', []), ignore_exc=ignore_exc)
        return Context(self.kind(), modules or self.module(), ignore_exc=ignore_exc)


def packages(kind=None, addons_only=True):
    """Yield all the modules/packages of a certain :kind:

    If the addons_only: is True, yields only the addon packages, not the integrated modules.
    """
    pkgkinds = [kind] if kind else _kinds()

    install_importers(pkgfullname, pkgpath, pkgkinds)

    for kind in pkgkinds:
        kind = kind.split('.')[-1]
        for dummy_package, name, is_pkg in importer.walk_packages([pkgpath(kind)], onerror=lambda name: True):
            if '.' not in name and name not in ['api', 'lib'] and (is_pkg or not addons_only):
                yield kind, name


def install(kind, name, descriptor, ui_update=None):
    source = sources.create(descriptor)

    instarget = instargets.create(pkgpath(kind, name))
    instarget.uninstall()
    if not instarget.install(source, ui_update):
        raise Exception('package installation failed')

    install_importers(pkgfullname, pkgpath, [kind], name)

    package = _load_attributes(pkgfullname(kind, name))
    if package.get('kind') != kind:
        instarget.uninstall()
        raise Exception('kind package descriptor missing or wrong')
    package['name'] = name

    log.debug('{m}.{f}: %s.%s: %s', kind, name, package)

    return package


def _load_attributes(package):
    if isinstance(package, basestring):
        module = __import__(package, globals(), locals(), [], -1)
        for name in package.split('.')[1:]:
            module = getattr(module, name)
    elif inspect.ismodule(package):
        module = package
    else:
        return {}

    init_source = inspect.getsource(module)
    init_attributes = {}
    exec init_source in init_attributes # pylint: disable=exec-used

    filtered_attributes = {}
    for attr, value in init_attributes.iteritems():
        if attr in _PACKAGES_ATTRIBUTES:
            filtered_attributes[attr] = value
        # NOTE: this test should be True only for the actual implementatio of ABC.
        # If one is found in the __init__.py, it is assumed to be the class adapter
        # for the package modules mapping the g2 API to the modules methods/classes.
        elif isinstance(value, abc.ABCMeta) and '__metaclass__' not in value.__dict__:
            filtered_attributes['__adapterclass__'] = value.__name__

    return filtered_attributes


def uninstall(kind, name):
    instargets.create(pkgpath(kind, name)).uninstall()


def status(kind, name):
    if not os.path.exists(os.path.join(pkgpath(kind, name), '')):
        return 'NotInstalled'

    try:
        modules = _info_cache(kind, name, force_refresh=None)
    except Exception as ex:
        log.error('{m}.{f}: %s: %s', '.'.join([c for c in (kind, name) if c]), repr(ex))
        return 'RaiseException'

    return len(modules) or 'Disabled'


def setting(kind, package='', module='', name='enabled'):
    return addon.setting(setting_name(kind, package, module, name))


def setting_name(kind, package='', module='', name='enabled'):
    return ':'.join([kind, package, module, name])


def info(kind, name=None, **kwargs):
    force_refresh = kwargs.get('force_refresh', False)
    package = kwargs.get('package', None)
    include_disabled = kwargs.get('include_disabled', False)
    verbose = kwargs.get('verbose', False)
    infos_modules = {}
    if name:
        try:
            infos_modules = _info_cache(kind, name, force_refresh, package, include_disabled)
        except Exception as ex:
            log.debug('{m}.{f}: %s.%s: %s', kind, name, repr(ex), trace=True)
    else:
        for kind, name in packages(kind, addons_only=False):
            try:
                infos_modules.update(_info_cache(kind, name, force_refresh, include_disabled=include_disabled))
            except ExceptionPackage as ex:
                if verbose:
                    log.notice('{m}.{f}: %s.%s: %s', kind, name, ex)
            except Exception as ex:
                log.debug('{m}.{f}: %s.%s: %s', kind, name, repr(ex), trace=True)

    return infos_modules


_INFO_CACHE_TYPE = type({})
_INFO_CACHE_VERSION = '0.1.4'


def _info_cache(kind, name, force_refresh=False, package=None, include_disabled=False):
    """Return the modules implemented by a certain :kind:.:name: as a dictionary
    The :force_refresh: can be:
        None    - do not consider the cache validity if present (quick mode used by the UI);
        True    - force a cache refresh even if the cache might still be valid;
        False   - use the cache if still valid and none of the associated paths changed or it is missing.
    If :package: is a dict, it is filled with the package info.
    If :include_disabled: is true also the disabled packages/modules are returned.
    """
    if not include_disabled and setting(kind, name) == 'false':
        return {}

    install_importers(pkgfullname, pkgpath, [kind], name)

    elapsed = datetime.datetime.now()
    kind = kind.split('.')[-1]
    if package is None:
        package = {}

    update_reason = None
    if force_refresh:
        update_needed = 'forced'
    else:
        update_needed = False
        timeout = 0 if force_refresh is None else 24*60
        response_info = {}
        try:
            infos = cache.get(_info, kind, name,
                              cacheopt_expire=timeout, cacheopt_info=response_info, cacheopt_delete_if_none=True)
            if not isinstance(infos, _INFO_CACHE_TYPE) or infos.get('version') != _INFO_CACHE_VERSION:
                raise ExceptionPackageCache('wrong cache type/version: %s, version: %s' %
                                            (type(infos), len(infos) if not isinstance(infos, dict) else infos.get('version')))
            if 'cached' not in response_info:
                update_reason = 'cache miss or expired'
            elif timeout > 0:
                for path, dummy_sha in infos.get('paths', []).iteritems():
                    if not os.path.exists(os.path.join(path, '')):
                        raise ExceptionPackageCache('missing ' + path)
        except ExceptionPackageCache as ex:
            log.debug('{m}.{f}: %s.%s: %s', kind, name, ex)
            update_needed = str(ex)

    if update_needed:
        infos = cache.get(_info, kind, name, cacheopt_expire=-1, cacheopt_delete_if_none=True)
        update_reason = update_needed

    package.update(infos.get('package', {}))

    modules = {}
    for module, nfo in infos['modules'].iteritems():
        if (include_disabled or nfo.get('enabled', True) and setting(kind, name, nfo['name']) != 'false' and
                package.get('enabled', True) and setting(kind, name) != 'false'):
            modules[module] = Module(nfo, package)

    if update_reason:
        elapsed = datetime.datetime.now() - elapsed
        log.debug('{m}.{f}: %s.%s: %d modules (%d disabled) in %.1f secs (%s)', kind, name,
                  len(infos['modules']), len(infos['modules']) - len(modules),
                  elapsed.seconds + elapsed.microseconds/1000000., update_reason)

    return modules


def _info(kind, name):
    infos_paths = {}
    infos_modules = {}

    def add_infos_paths(path):
        infos_paths[path] = ''

    def add_info(nfo, elements):
        fullname = '.'.join(elements)
        if not nfo.get('name'):
            nfo['name'] = elements[-1]
        elif nfo['name'] != elements[-1]:
            fullname += '.' + nfo['name']
        log.debug('{m}.{f}: %s: info: %s', fullname, nfo)
        infos_modules.update({fullname: i})

    package_info = {
        'kind': kind,
        'name': '',
    }

    if os.path.exists(pkgpath(kind, name)+'.py'):
        log.debug('{m}.{f}: fetching info for integrated module %s.%s', kind, name)
        for i in _info_module_or_package(kind, name):
            add_info(i, (name,))

    elif not os.path.exists(os.path.join(pkgpath(kind, name), '')):
        raise ExceptionPackage('missing installation directory')

    else:
        log.debug('{m}.{f}: fetching info for package %s.%s', kind, name)

        with Context(kind, name) as pkgs:
            if not pkgs:
                raise ExceptionPackage('import error')
            package_info.update(_load_attributes(pkgs[0]))

        package_info['name'] = name
        search_paths = []
        addons = package_info.get('addons', [])
        if addons:
            addons = [addons] if isinstance(addons, basestring) else addons
            search_paths = []
            for addon_id in addons:
                if not addon.exists(addon_id):
                    raise ExceptionPackage('missing %s addon' % addon_id)

                addon_paths = addon.info2(addon_id, 'search_paths')
                search_paths.extend(addon_paths)
                add_infos_paths(os.path.join(addon_paths[0], ''))

        if package_info.get('paths'):
            search_paths += [os.path.join(search_paths[0], p) for p in package_info['paths']]
        package_info['search_paths'] = search_paths[:1] + list(set(search_paths[1:]))

        log.debug('{m}.{f}: %s.%s: %s', kind, name, package_info)

        add_infos_paths(os.path.join(pkgpath(kind, name), ''))

        # The absence of the :imports: attribute means that the package's modules have been downloaded
        if not package_info.get('imports'):
            log.debug('{m}.{f}: fetching modules info for package %s.%s at %s', kind, name, pkgs[0].__path__)
            _info_module_or_package(kind, '', package_info, fetch_package_info=True)
            for dummy_pkg, sname, is_pkg in importer.walk_packages(pkgs[0].__path__, onerror=lambda name: True):
                if not is_pkg and '.' not in sname:
                    log.debug('{m}.{f}: fetching modules info for %s.%s.%s', kind, name, sname)
                    for i in _info_module_or_package(kind, sname, package_info):
                        add_info(i, (name, sname))

        # For imported modules/libraries the :addons: attribute is mandatory
        elif not package_info.get('addons'):
            raise ExceptionPackage('missing addons attribute')

        # If the :imports: attribute is not a string, then it is a list of packages to import
        elif not isinstance(package_info['imports'], basestring):
            skip_modules = package_info.get('skip', [])
            for index, pname in enumerate(package_info['imports']):
                log.debug('{m}.{f}: fetching modules info for package %s.%s at %s',
                          kind, name, [os.path.join(package_info['search_paths'][0], pname)])
                _info_module_or_package(kind, '', package_info, pname, fetch_package_info=True)
                for _pkg, sname, is_pkg in importer.walk_packages([os.path.join(package_info['search_paths'][0], pname)],
                                                                  onerror=lambda name: True):
                    if '%s.%s'%(pname, sname) in skip_modules:
                        log.debug('{m}.{f}: skipped %s.%s.%s.%s module', kind, name, pname, sname)
                        continue

                    log.debug('{m}.{f}: fetching modules info for %s.%s.%s at %s',
                              kind, name, sname, os.path.join(package_info['search_paths'][0], pname, sname))
                    if not is_pkg and '.' not in sname:
                        for i in _info_module_or_package(kind, sname, package_info, pname):
                            i['import'] = index
                            add_info(i, (name, pname, sname))

        # If the :imports: attribute is a string, then it is a library to import
        else:
            _info_module_or_package(kind, '', package_info, package_info['imports'], fetch_package_info=True)
            log.debug('{m}.{f}: fetching modules info for %s.%s from imported addon %s.%s',
                      kind, name, package_info['addons'][0], package_info['imports'])
            for i in _info_module_or_package(kind, '', package_info, package_info['imports']):
                add_info(i, (name, package_info['imports']))

    log.debug('{m}.{f}: %s.%s: %d paths, %d modules, %s', kind, name, len(infos_paths), len(infos_modules), package_info)

    return {
        'version': _INFO_CACHE_VERSION,
        'paths': infos_paths,
        'modules': infos_modules,
        'package': package_info,
    }


def _info_module_or_package(kind, module_name, package_info=None, import_module_name=None, fetch_package_info=False):
    if package_info is None:
        package_info = {}
    infos = []
    try:
        kind_fullname = '' if not kind else (_PACKAGES_RELATIVE_PATH + kind.split('.')[-1])
        kind_name = kind_fullname if not import_module_name else ''
        package_name = import_module_name or package_info.get('name', '')
        with Context(kind_name, package_name, [module_name], package_info.get('search_paths', [])) as modules:
            kind_module = __import__(kind_fullname, globals(), locals(), [])
            for name in kind_fullname.split('.')[1:]:
                kind_module = getattr(kind_module, name)

            if fetch_package_info:
                infos = kind_module.info(package_info, None)
                for i in infos:
                    package_info.update(i)

            elif modules:
                infos = kind_module.info(package_info, modules[0])
                for i in infos:
                    if not module_name:
                        i['module'] = ''
                    elif not i.get('name'):
                        i['name'] = module_name
                    elif i['name'] != module_name:
                        i['module'] = module_name
    except Exception as ex:
        log.error('{m}.{f}: %s.%s.%s: %s', kind_fullname, package_info.get('name'), module_name, repr(ex), trace=True)

    return infos
