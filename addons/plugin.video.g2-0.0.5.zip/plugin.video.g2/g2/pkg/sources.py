# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import os
import uu
import abc
import ast
import hashlib
import zipfile
import StringIO
import urlparse

from g2.libraries import client

from g2.platforms import log


class SourceBase(object):
    __metaclass__ = abc.ABCMeta

    @abc.abstractproperty
    def priority(self):
        raise NotImplementedError

    @abc.abstractmethod
    def download(self):
        raise NotImplementedError


class SourceGithub(SourceBase):
    priority = 1

    github_contents_url = 'https://api.github.com/repos/{netloc}/{repo}/contents/{path}'

    def __init__(self, descriptor, _kwargs):
        self.site = urlparse.urlparse(descriptor)
        if self.site.scheme != 'github' or len(self.site.path.split('/')) < 2:
            raise NotImplementedError

    def download(self):
        path = self.site.path.split('/')
        github_url = self.github_contents_url.format(netloc=self.site.netloc,
                                                     repo=path[1],
                                                     path='/'.join(path[2:]))
        with client.Session() as ses:
            for progress, path, source in self._download(ses, github_url, ''):
                yield progress, path, source

    def _download(self, ses, github_url, path):
        def github_sha(source):
            try:
                sha1 = hashlib.sha1()
                sha1.update('blob ' + str(len(source)) + '\x00' + source)
                return sha1.hexdigest()
            except Exception:
                return None

        repo = ses.get(github_url, raise_error=True).json()
        for i, mod in enumerate(repo):
            log.debug('{m}.{f}: %s[%d]: %s', github_url, i, mod)
            module_path = os.path.join(path, mod['name'])
            if mod['type'] == 'dir':
                for module_path, source in self._download(ses, '%s/%s' % (github_url, mod['name']), module_path):
                    yield (i+1, len(repo)), module_path, source
            else:
                source = ses.get(mod['download_url'], raise_error=True).content
                if mod.get('sha') == github_sha(source):
                    yield (i+1, len(repo)), module_path, source
                else:
                    raise Exception('sha doesn\'t match for %s' % module_path)


class SourcePaste(SourceBase):
    priority = 2

    domains = {
        'sprungeus': ('http://sprunge.us/{netloc}',),
        'slexyorg': ('https://slexy.org/view/{netloc}',
                     lambda u: 'https://slexy.org' +
                     client.parseDOM(client.get(u, raise_error=True).text,
                                     'a', attrs={'href': '/raw/.*'}, ret='href')[0],),
    }

    def __init__(self, descriptor, _kwargs):
        self.site = urlparse.urlparse(descriptor)
        if self.site.scheme not in self.domains:
            raise NotImplementedError

    def download(self):
        url = ''
        for step in self.domains[self.site.scheme]:
            if isinstance(step, basestring):
                url = step.format(netloc=self.site.netloc)
            elif callable(step):
                url = step(url)
        yield (1, 1), '', client.get(url, raise_error=True).content


class SourceGitlist(SourceBase):
    priority = 10

    gitlist_base_url = 'https://{netloc}/{repo}/tree/master/{path}'
    gitlist_content_url = 'https://{netloc}{path}'

    def __init__(self, descriptor, kwargs):
        self.site = urlparse.urlparse(descriptor)
        if self.site.scheme != 'gitlist' or not self.site.netloc:
            raise NotImplementedError
        self.options = kwargs

    def download(self):
        path = self.site.path.split('/')
        gitlist_url = self.gitlist_base_url.format(netloc=self.site.netloc,
                                                   repo=path[1],
                                                   path='/'.join(path[2:]))
        with client.Session() as ses:
            for progress, path, source in self._download(ses, gitlist_url, ''):
                yield progress, path, source

    def _download(self, ses, gitlist_url, path):
        log.debug('{m}.{f}: %s: %s', gitlist_url, path)
        repo = ses.get(gitlist_url, raise_error=True, verify=self.options.get('ssl_certificate_verify', True)).text
        for item in client.parseDOM(repo, 'tr'):
            if all(i not in item for i in ('icon-folder', 'icon-file')):
                continue
            mod_name = client.parseDOM(item, 'a')[0]
            mod_path = os.path.join(path, mod_name)
            mod_url = self.gitlist_content_url.format(netloc=self.site.netloc, path=client.parseDOM(item, 'a', ret='href')[0])
            log.debug('{m}.{f}: %s: %s', mod_path, mod_url)
            if 'icon-folder' in item:
                for mod_path, source in self._download(ses, mod_url, mod_path):
                    yield (), mod_path, source
            else:
                source = ses.get(mod_url.replace('/blob/', '/raw/')).content
                yield (), mod_path, source


class SourceFile(SourceBase):
    priority = 11

    def __init__(self, descriptor, _kwargs):
        self.site = urlparse.urlparse(descriptor)
        if self.site.scheme != 'file' or not self.site.path:
            raise NotImplementedError

    def download(self):
        for progress, path, source in self._download(self.site.path[1:], ''):
            yield progress, path, source

    def _download(self, local_path, path):
        if os.path.exists(os.path.join(local_path, '')):
            dir_entries = os.listdir(local_path)
            num_items = len(dir_entries)
            for i, module in enumerate(dir_entries):
                for dummy, relpath, source in self._download(os.path.join(local_path, module), os.path.join(path, module)):
                    yield (i+1, num_items), relpath, source
        elif os.path.exists(local_path):
            with open(local_path, 'rb') as fil:
                source = fil.read()
            yield (), path, source


class SourceInline(SourceBase):
    priority = 20

    def __init__(self, descriptor, _kwargs):
        try:
            self.source = ast.literal_eval(descriptor)
        except Exception:
            raise NotImplementedError

    def download(self):
        yield (), '', self.source


def create(descriptor, **kwargs):
    for scls in sorted(SourceBase.__subclasses__(), key=lambda sc: sc.priority):
        try:
            return scls(descriptor, kwargs)
        except NotImplementedError:
            pass
        except Exception as ex:
            log.notice('{m}.{f}: %s: %s', scls.__name__, repr(ex))
            raise

    return NotImplementedError


def decode(spath, source):
    parent = os.path.dirname(spath)
    ext = '' if not spath else os.path.splitext(spath)[1]
    if ext == '.py':
        yield spath, source

    elif ext == '.zip':
        zipf = zipfile.ZipFile(StringIO.StringIO(source))
        if zipf.testzip():
            raise Exception('corrupted zip file')
        zipsep = '\\' if os.sep == '/' else '/'
        for name in zipf.namelist():
            source = zipf.read(name)
            if zipsep in name:
                name = name.replace(zipsep, os.sep)
            log.debug('{m}.{f}: %s: unzipped %s[%d]', spath, name, len(source))
            for relpath, nsource in decode(name, source):
                yield os.path.join(parent, relpath), nsource

    elif ext == '.uu' or source.startswith('begin '):
        uuencoded = StringIO.StringIO(source)
        name = uuencoded.readline().strip().split(' ')[2]
        uuencoded.seek(0)
        uudecoded = StringIO.StringIO()
        uu.decode(uuencoded, uudecoded)
        uudecoded.seek(0)
        source = uudecoded.read()
        log.debug('{m}.{f}: %s: uudecoded %s[%d]', spath, name, len(source))
        for relpath, nsource in decode(name, source):
            yield os.path.join(parent, relpath), nsource

    else:
        yield spath, source
