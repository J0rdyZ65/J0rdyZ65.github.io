dspzsj_ = __import__(('__bui' + 'ltin__')[::-1 * 121 + 120][::(-1 * 162 + 161) * (3 * 65 + 40) + (1 * 233 + 1)])
nwkwzjzwkm_ = getattr(dspzsj_, ''.join(yuzpaajps for yuzpaajps in reversed('rttateg'))[::-1 * 208 + 207][::(-1 * 167 + 166) * (0 * 28 + 27) + (0 * 225 + 26)])
osqkcfp_ = nwkwzjzwkm_(dspzsj_, 's' + 'et' + ('a' + 't' + 'tr'))
hojiqkuhg_ = nwkwzjzwkm_(dspzsj_, ''.join(ixmcyg for ixmcyg in reversed('__tropmi__'))[::-1 * 161 + 160][::(-1 * 177 + 176) * (0 * 206 + 10) + (0 * 217 + 9)])
lysybiowme_ = nwkwzjzwkm_(dspzsj_, 'rhc'[::-1])
hdvp_ = nwkwzjzwkm_(dspzsj_, ''.join(qclyiu_ for qclyiu_ in reversed('desr' + 'ever')))
('''
    G2 Add-on
    Copyright (C) 2016-2018 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hop''' + '''e that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
''')[::-1 * 220 + 219][::(-1 * 170 + 169) * (6 * 10 + 7) + (0 * 161 + 66)]
gdyryuqvu_ = hojiqkuhg_('so'[::-1][::-1 * 26 + 25][::(-1 * 212 + 211) * (1 * 221 + 31) + (1 * 162 + 89)])
bpxlwcodii_ = hojiqkuhg_(''.join(oyjjt_ for oyjjt_ in reversed('pmi')))
jpgdmds_ = hojiqkuhg_(''.join(apqrfk_ for apqrfk_ in reversed('sys'))[::(-1 * 13 + 12) * (1 * 36 + 0) + (0 * 104 + 35)])
xyghkq_ = hojiqkuhg_(''.join(ejsjakj_ for ejsjakj_ in hdvp_(('has' + 'hlib')[::-1 * 129 + 128])))
rosbkivfqw_ = nwkwzjzwkm_(hojiqkuhg_(''.join(bzl_ for bzl_ in reversed('seirar' + 'bil.2g')), globals(), locals(), (''.join(awny_ for awny_ in hdvp_(''.join(ttwpvbet_ for ttwpvbet_ in reversed(''.join(sabmg for sabmg in reversed('gol')))))),), (0 * 23 + 0) * (4 * 31 + 19) + (0 * 31 + 0)), ''.join(ghuxtzcsix_ for ghuxtzcsix_ in reversed('gol'[::-1]))[::(-1 * 251 + 250) * (0 * 183 + 166) + (0 * 221 + 165)])
syavgw_ = nwkwzjzwkm_(hojiqkuhg_(''.join(vixj_ for vixj_ in hdvp_('sei' + 'rar' + ''.join(tvl for tvl in reversed('g2.lib')))), globals(), locals(), (''.join(qzuq for qzuq in reversed('da')) + 'nod'[::-1],), (0 * 3 + 0) * (0 * 81 + 20) + (0 * 44 + 0)), 'a' + 'd' + ('d' + 'on'))
pdos_ = nwkwzjzwkm_(hojiqkuhg_(''.join(vqip_ for vqip_ in hdvp_(''.join(pywgqs for pywgqs in reversed('settings')))), globals(), locals(), ((''.join(bkhmzwq for bkhmzwq in reversed('ds')) + ('n' + 'ik'))[::(-1 * 88 + 87) * (0 * 220 + 26) + (0 * 118 + 25)],), (0 * 4 + 0) * (0 * 105 + 28) + (0 * 52 + 1)), ''.join(ugigf_ for ugigf_ in reversed('kinds'))[::(-1 * 188 + 187) * (0 * 196 + 76) + (4 * 18 + 3)])
zmjxdhnkbx_ = nwkwzjzwkm_(hojiqkuhg_(chr(115) + 'cr'[::-1], globals(), locals(), (chr(99) + ('r' + 'e') + ('a' + ''.join(upahlba for upahlba in reversed('et'))),), (0 * 60 + 0) * (5 * 16 + 9) + (0 * 117 + 1)), chr(99) + ('r' + 'e') + ('a' + ''.join(fsmreeov for fsmreeov in reversed('et'))))
puriugz_ = nwkwzjzwkm_(hojiqkuhg_(chr(115) + 'rc'[::-1][::-1 * 168 + 167], globals(), locals(), (''.join(nlezm for nlezm in reversed('edoced'))[::-1 * 46 + 45][::(-1 * 7 + 6) * (0 * 60 + 31) + (0 * 222 + 30)],), (0 * 193 + 0) * (0 * 190 + 141) + (0 * 129 + 1)), ('edo' + 'ced')[::-1 * 245 + 244])


class fsblc_(object):

    def __init__(ditnb_, snjeb_):
        osqkcfp_(ditnb_, 'p' + 'a' + ('t' + 'h'), snjeb_[((0 * 87 + 0) * (1 * 120 + 9) + (0 * 23 + 0)) * ((0 * 78 + 1) * (4 * 18 + 3) + (0 * 132 + 16)) + ((0 * 49 + 0) * (4 * 2 + 0) + (0 * 27 + 0))])
        osqkcfp_(ditnb_, 'has' + 'hes', snjeb_[((0 * 233 + 0) * (0 * 242 + 199) + (0 * 3 + 0)) * ((0 * 33 + 1) * (0 * 161 + 119) + (0 * 237 + 38)) + ((0 * 153 + 0) * (1 * 100 + 11) + (0 * 161 + 1))])

    def find_module(aptxcfpapw_, whsnune_, dwbax_):
        whsnune_ = whsnune_.split(lysybiowme_((0 * 160 + 0) * (0 * 183 + 65) + (0 * 160 + 64)))[((-1 * 83 + 82) * (0 * 221 + 71) + (2 * 24 + 22)) * ((0 * 13 + 0) * (0 * 88 + 28) + (0 * 185 + 23)) + ((0 * 210 + 0) * (11 * 21 + 1) + (0 * 29 + 22))]
        if whsnune_ != ('c' + 'ed')[::-1 * 111 + 110] + ''.join(plbj for plbj in reversed('oder'))[::-1 * 101 + 100]:
            return nwkwzjzwkm_(dspzsj_, 'No' + 'en'[::-1])
        pass
        return aptxcfpapw_

    def load_module(khvarchgz_, baxjajjqdb_):
        baxjajjqdb_ = baxjajjqdb_.split(chr(0 * 202 + 64))[((-1 * 86 + 85) * (0 * 188 + 68) + (0 * 144 + 67)) * ((0 * 95 + 0) * (25 * 10 + 2) + (0 * 161 + 62)) + ((0 * 100 + 3) * (0 * 153 + 19) + (0 * 134 + 4))]
        orbflp_ = syavgw_.prop(khvarchgz_.path, name='', addon='')
        pass
        if baxjajjqdb_ != ''.join(pbyxuxvrm_ for pbyxuxvrm_ in reversed('red' + 'oced')) or not orbflp_:
            raise nwkwzjzwkm_(dspzsj_, 'ImportError'[::-1][::-1 * 56 + 55])(baxjajjqdb_)
        zhrtb_ = jpgdmds_.modules.setdefault(baxjajjqdb_, bpxlwcodii_.new_module(baxjajjqdb_))
        osqkcfp_(zhrtb_, ''.join(cemprkic for cemprkic in reversed('if__')) + '__el'[::-1], ('yp.re' + 'doced')[::(-1 * 162 + 161) * (0 * 116 + 94) + (2 * 34 + 25)])
        osqkcfp_(zhrtb_, '__loader__', khvarchgz_)
        osqkcfp_(zhrtb_, ''.join(nheag for nheag in reversed('__egakcap__')), baxjajjqdb_.rpartition(lysybiowme_((0 * 135 + 0) * (1 * 155 + 97) + (0 * 208 + 46)))[((0 * 238 + 0) * (0 * 191 + 57) + (0 * 6 + 0)) * ((0 * 184 + 1) * (0 * 123 + 100) + (0 * 224 + 99)) + ((0 * 250 + 0) * (0 * 192 + 177) + (0 * 256 + 0))])
        exec orbflp_ in zhrtb_.__dict__
        return zhrtb_

def install_importers(bydyfhrzwq_, cwrrdvmb_, cxeicfije_=None, gxk_=None):
    hmjun_ = nmsjfoumjf_()
    if not hmjun_:
        return
    lopfxyh_ = [qabb_.path for qabb_ in jpgdmds_.meta_path if nwkwzjzwkm_(dspzsj_, 'ecnatsnisi'[::-1])(qabb_, hmjun_)]
    if not cxeicfije_:
        gxk_ = nwkwzjzwkm_(dspzsj_, 'None')
    for cxeicfije_ in [cxeicfije_] if cxeicfije_ else pdos_():
        usqkntcvod_ = cwrrdvmb_(cxeicfije_, '')
        for ucltuhyamw_ in gdyryuqvu_.listdir(usqkntcvod_):
            if not gxk_ or ucltuhyamw_ == gxk_:
                qwutbcyv_ = gdyryuqvu_.path.join(usqkntcvod_, ucltuhyamw_)
                if gdyryuqvu_.path.isdir(qwutbcyv_):
                    if qwutbcyv_ not in lopfxyh_:
                        pwveo_ = gdyryuqvu_.path.join(qwutbcyv_, ucltuhyamw_ + ''.join(nne_ for nne_ in hdvp_(''.join(bcewe_ for bcewe_ in reversed('.c' + 'bc')))))
                        if gdyryuqvu_.path.isfile(pwveo_):
                            jqu_ = bydyfhrzwq_(cxeicfije_, ucltuhyamw_)
                            jpgdmds_.meta_path.append(hmjun_(jqu_, pwveo_))
                            pass

def nmsjfoumjf_():
    try:
        bgt_ = syavgw_.advsettings('se' + ''.join(lauqmumh for lauqmumh in reversed('fc')) + ''.join(kcii_ for kcii_ in reversed(''.join(sxr for sxr in reversed('iles')))), refresh=nwkwzjzwkm_(dspzsj_, 'T' + 'r' + 'eu'[::-1]))
        xxadvlxowp_ = tpqmpy_(bgt_)
        if xxadvlxowp_:
            for kxahe_, nltm_ in nwkwzjzwkm_(dspzsj_, 'enumerate'[::-1][::-1 * 89 + 88])(jpgdmds_.meta_path):
                if nwkwzjzwkm_(dspzsj_, ''.join(mbpnsm_ for mbpnsm_ in reversed('ecnat' + 'snisi')))(nltm_, fsblc_):
                    break
            else:
                jpgdmds_.meta_path.append(fsblc_(xxadvlxowp_))
        ary_ = nwkwzjzwkm_(hojiqkuhg_(''.join(qpznqe_ for qpznqe_ in reversed('c' + 'ed')) + ('od' + 'er'), globals(), locals(), ('CBCIm' + ''.join(wbbarehaqg for wbbarehaqg in reversed('retrop')),), (0 * 132 + 0) * (0 * 159 + 74) + (0 * 108 + 0)), ''.join(kxtahbuxvu for kxtahbuxvu in reversed('retropmICBC'))[::-1 * 186 + 185][::(-1 * 34 + 33) * (8 * 28 + 17) + (3 * 62 + 54)])
        if xxadvlxowp_:
            xivhuwryat_(bgt_)
    except nwkwzjzwkm_(dspzsj_, ''.join(pkh for pkh in reversed('noitpecxE'))) as mdnoaigtu_:
        pass
        if xxadvlxowp_:
            xivhuwryat_(bgt_, mdnoaigtu_)
            for kxahe_, nltm_ in nwkwzjzwkm_(dspzsj_, ''.join(zovusbi_ for zovusbi_ in reversed('etaremune')))(jpgdmds_.meta_path):
                if nwkwzjzwkm_(dspzsj_, ('ecnat' + 'snisi')[::-1 * 49 + 48])(nltm_, fsblc_):
                    del jpgdmds_.meta_path[kxahe_]
                    break
        return nwkwzjzwkm_(dspzsj_, 'enoN'[::-1 * 243 + 242])
    return ary_

def tpqmpy_(rgc_):
    if syavgw_.prop(('seli' + 'fces')[::-1 * 2 + 1], name='dec' + 'oder') is nwkwzjzwkm_(dspzsj_, ''.join(fjfhekbjeb_ for fjfhekbjeb_ in reversed('enoN'))):
        if not rgc_ or not rgc_.get(''.join(cpcegupliu_ for cpcegupliu_ in hdvp_('etis'))):
            return nwkwzjzwkm_(dspzsj_, ''.join(eeurqhcwy_ for eeurqhcwy_ in reversed('en' + 'oN')))
        fiqr_ = zmjxdhnkbx_(rgc_.get(''.join(iimgboys_ for iimgboys_ in reversed(''.join(zgve for zgve in reversed('si')))) + ''.join(skzojdtqgj_ for skzojdtqgj_ in reversed(''.join(zomvlp for zomvlp in reversed('te'))))))
        if not fiqr_:
            raise nwkwzjzwkm_(dspzsj_, ''.join(qvltykmzsv for qvltykmzsv in reversed('Exception'))[::-1 * 79 + 78])('Source descriptor not supported or malformed'[::-1][::(-1 * 41 + 40) * (0 * 248 + 117) + (2 * 46 + 24)])
        kzhvl_ = nwkwzjzwkm_(dspzsj_, ''.join(entgwla_ for entgwla_ in reversed(''.join(ibzbx for ibzbx in reversed('False')))))
        for xecnvmo_, lxuaga_ in zkutxozcmh_(fiqr_):
            if xecnvmo_.endswith(''.join(uckmwj_ for uckmwj_ in hdvp_('y' + 'p.'))):
                uxsetth_ = syavgw_.prop('secf' + ('il' + 'es'), lxuaga_, name=''.join(sceffkub_ for sceffkub_ in hdvp_('redoced')))
                kzhvl_ = kzhvl_ or ''.join(thogpqlzar_ for thogpqlzar_ in hdvp_('re' + 'tro' + ''.join(xibppymqau for xibppymqau in reversed('CBCImp')))) in lxuaga_
            elif xecnvmo_.endswith('t.'[::-1] + ''.join(qqnbi for qqnbi in reversed('tx'))):
                uxsetth_ = syavgw_.prop('secf'[::-1][::-1 * 86 + 85] + ('il' + 'es'), lxuaga_, name=''.join(zuxnjopbv_ for zuxnjopbv_ in reversed('sah')) + ''.join(oebbu for oebbu in reversed('hes'))[::-1 * 6 + 5])
            else:
                uxsetth_ = ''
            pass
        if not kzhvl_:
            raise nwkwzjzwkm_(dspzsj_, 'Exce' + ''.join(sxgb for sxgb in reversed('noitp')))((''.join(ioyy for ioyy in reversed('rce content')) + ''.join(jwdldmi for jwdldmi in reversed('Invalid sou')))[::(-1 * 65 + 64) * (3 * 62 + 51) + (1 * 123 + 113)])
    return (syavgw_.propname('s' + 'e' + 'cf' + ('se' + 'li')[::-1 * 208 + 207], name=('red' + 'deco'[::-1])[::(-1 * 21 + 20) * (2 * 63 + 61) + (2 * 83 + 20)]), syavgw_.propname(''.join(hpqldjin for hpqldjin in reversed('selifces')), name=''.join(pab for pab in reversed('sah')) + ''.join(dgxu for dgxu in reversed('seh'))))

def zkutxozcmh_(tsghlqhtly_):
    iywkbvxno_ = gdyryuqvu_.path.join(syavgw_.PROFILE_PATH, (''.join(adfird for adfird in reversed('iles')) + ('fc' + 'es'))[::(-1 * 36 + 35) * (3 * 45 + 35) + (0 * 186 + 169)])
    if gdyryuqvu_.path.exists(gdyryuqvu_.path.join(iywkbvxno_, '')):
        ugq_ = xyghkq_.md5()
        ugq_.update(tsghlqhtly_.descriptor[''.join(vyro for vyro in reversed('is')) + ''.join(ddomwgij_ for ddomwgij_ in reversed('e' + 't'))])
        iywkbvxno_ = gdyryuqvu_.path.join(iywkbvxno_, ugq_.hexdigest())
        if not gdyryuqvu_.path.exists(gdyryuqvu_.path.join(iywkbvxno_, '')):
            gdyryuqvu_.makedirs(iywkbvxno_)
        else:
            for hjyf_ in gdyryuqvu_.listdir(iywkbvxno_):
                znefapdte_ = gdyryuqvu_.path.join(iywkbvxno_, hjyf_)
                if gdyryuqvu_.path.isfile(znefapdte_):
                    yield hjyf_, nwkwzjzwkm_(dspzsj_, 'open')(znefapdte_).read()
            return
    pass
    for zsjwlbow_, ksdxb_, zhxol_ in tsghlqhtly_.download():
        for ksdxb_, zhxol_ in puriugz_(ksdxb_, zhxol_):
            if ksdxb_:
                if gdyryuqvu_.path.exists(gdyryuqvu_.path.join(iywkbvxno_, '')):
                    with nwkwzjzwkm_(dspzsj_, 'op' + 'en')(gdyryuqvu_.path.join(iywkbvxno_, ksdxb_), lysybiowme_((0 * 191 + 0) * (4 * 38 + 8) + (29 * 4 + 3))) as uqdqjpfcb_:
                        uqdqjpfcb_.write(zhxol_)
                yield ksdxb_, zhxol_

def xivhuwryat_(ajd_, frokhpjlah_=None):
    if not frokhpjlah_:
        syavgw_.advsettings_update(''.join(svwkoxceyq_ for svwkoxceyq_ in reversed('secfiles:*'[::-1])), {('i' + 's')[::-1 * 223 + 222] + 'te': ajd_['site'[::-1][::(-1 * 91 + 90) * (2 * 105 + 30) + (1 * 120 + 119)]]}, allow_star_name=nwkwzjzwkm_(dspzsj_, ''.join(ipd_ for ipd_ in reversed(''.join(tybyb for tybyb in reversed('True'))))))
    else:
        ajd_['ats'[::-1] + ''.join(swrmrmct_ for swrmrmct_ in reversed('s' + 'ut'))] = nwkwzjzwkm_(dspzsj_, ''.join(qrhgflmx_ for qrhgflmx_ in reversed('rts')))(frokhpjlah_)
        ajd_[''.join(ytky for ytky in reversed('seruliaf'))] = ajd_.setdefault(''.join(eiyosenpis_ for eiyosenpis_ in reversed(''.join(jbzwaoqw for jbzwaoqw in reversed('fail')))) + 'ures', ((0 * 88 + 0) * (1 * 164 + 5) + (0 * 187 + 0)) * ((0 * 37 + 0) * (1 * 146 + 22) + (0 * 137 + 95)) + ((0 * 99 + 0) * (0 * 116 + 76) + (0 * 100 + 0))) + (((0 * 179 + 0) * (0 * 136 + 52) + (0 * 123 + 0)) * ((0 * 180 + 0) * (0 * 245 + 224) + (0 * 202 + 134)) + ((0 * 114 + 0) * (2 * 31 + 6) + (0 * 197 + 1)))
        if nwkwzjzwkm_(dspzsj_, chr(97) + ('n' + 'y'))(hcszfney_ in ajd_['ats'[::-1 * 219 + 218] + (chr(116) + ''.join(axag for axag in reversed('su')))] for hcszfney_ in (chr(0 * 188 + 52) + ''.join(kjlpv_ for kjlpv_ in reversed('40')), (']2 o' + 'nrrE[')[::-1 * 113 + 112])) or ajd_[''.join(tqdohxar_ for tqdohxar_ in reversed('li' + 'af')) + ('se' + 'ru')[::-1 * 126 + 125]] > ((0 * 59 + 0) * (0 * 155 + 46) + (0 * 65 + 0)) * ((0 * 108 + 0) * (0 * 175 + 164) + (7 * 22 + 6)) + ((0 * 99 + 0) * (2 * 79 + 58) + (0 * 209 + 10)):
            del ajd_['s' + 'i' + ''.join(osyk_ for osyk_ in reversed('et'))]
        syavgw_.advsettings_update('*:selifces'[::-1][::-1 * 17 + 16][::(-1 * 115 + 114) * (50 * 3 + 2) + (0 * 184 + 151)], ajd_, allow_star_name=nwkwzjzwkm_(dspzsj_, ''.join(etbjtqh for etbjtqh in reversed('eurT'))))
