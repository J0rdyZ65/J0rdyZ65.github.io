# -*- coding: utf-8 -*-

'''
Copyright (C) 2016-2019 J0rdyZ65
'''

import os
import imp
import sys
import hashlib

from g2.libraries import log
from g2.libraries import advsettings

from g2.platforms import addon
from g2.platforms.settings import kinds

from .src import create
from .src import decode


class _PkgSrcDecImporter(object):
    def __init__(self, propnames):
        self.path = propnames[0]
        self.hashes = propnames[1]

    def find_module(self, fullname, path):
        fullname = fullname.split('@')[-1]
        if fullname != 'decoder':
            return None
        log.debug('{m}.{f}: %s [%s]', fullname, path)
        return self

    def load_module(self, fullname):
        fullname = fullname.split('@')[-1]
        source = addon.prop(self.path, name='', addon='')
        log.debug('{m}.{f}: %s, %s[%d]', fullname, self.path, len(source or []))
        if fullname != 'decoder' or not source:
            raise ImportError(fullname)
        mod = sys.modules.setdefault(fullname, imp.new_module(fullname))
        mod.__file__ = 'decoder.py'
        mod.__loader__ = self
        mod.__package__ = fullname.rpartition('.')[0]
        exec source in mod.__dict__ # pylint: disable=exec-used
        return mod


def install_importers(pkgfullname, pkgpath, kind=None, name=None):
    cbcimporter_class = _import_cbcimporter_class()
    if not cbcimporter_class:
        return

    installed_importers = [i.path for i in sys.meta_path if isinstance(i, cbcimporter_class)]
    if not kind:
        name = None
    for kind in [kind] if kind else kinds():
        kindpath = pkgpath(kind, '')
        for pkgname in os.listdir(kindpath):
            if not name or pkgname == name:
                pkgdirpath = os.path.join(kindpath, pkgname)
                if os.path.isdir(pkgdirpath):
                    if pkgdirpath not in installed_importers:
                        pkgcbcpath = os.path.join(pkgdirpath, pkgname+'.cbc')
                        if os.path.isfile(pkgcbcpath):
                            fullname = pkgfullname(kind, pkgname)
                            sys.meta_path.append(cbcimporter_class(fullname, pkgcbcpath))
                            log.debug('{m}.{f}: installed %s(%s, %s)', cbcimporter_class.__name__, fullname, pkgcbcpath)


def _import_cbcimporter_class():
    try:
        secfiles = advsettings.setting('secfiles', refresh=True)
        propnames = _decoder_install(secfiles)
        if propnames:
            for i, mimp in enumerate(sys.meta_path):
                if isinstance(mimp, _PkgSrcDecImporter):
                    break
            else:
                sys.meta_path.append(_PkgSrcDecImporter(propnames))

        from decoder import CBCImporter

        if propnames:
            _decoder_update_advsettings(secfiles)
    except Exception as ex:
        log.debug('{m}.{f}: %s', repr(ex), trace=True)
        if propnames:
            _decoder_update_advsettings(secfiles, ex)
            for i, mimp in enumerate(sys.meta_path):
                if isinstance(mimp, _PkgSrcDecImporter):
                    del sys.meta_path[i]
                    break
        return None

    return CBCImporter


def _decoder_install(secfiles):
    if addon.prop('secfiles', name='decoder') is None:
        if not secfiles or not secfiles.get('site'):
            return None

        decsource = create(secfiles.get('site'))
        if not decsource:
            raise Exception('Source descriptor not supported or malformed')

        decoder_installed = False
        for relpath, source in _decoder_download(decsource):
            propname = ''
            if relpath.endswith('.py'):
                decoder_propname = propname = addon.prop('secfiles', source, name='decoder')
                decoder_installed = decoder_installed or 'CBCImporter' in source
            elif relpath.endswith('.txt'):
                hashes_propname = propname = addon.prop('secfiles', source, name='hashes')
            log.debug('{m}.{f}: %s[%d]: %s', relpath, len(source), 'ignored' if not propname else 'installed in %s' % propname)

        if not decoder_installed:
            raise Exception('Invalid source content')

    return decoder_propname, hashes_propname


def _decoder_download(decsource):
    secfiles_cache = os.path.join(addon.info('profile'), 'secfiles')
    if os.path.exists(os.path.join(secfiles_cache, '')):
        site_hash = hashlib.md5()
        site_hash.update(decsource.descriptor['site'])
        secfiles_cache = os.path.join(secfiles_cache, site_hash.hexdigest())
        if not os.path.exists(os.path.join(secfiles_cache, '')):
            os.makedirs(secfiles_cache)
        else:
            for filename in os.listdir(secfiles_cache):
                filepath = os.path.join(secfiles_cache, filename)
                if os.path.isfile(filepath):
                    yield filename, open(filepath).read()
            return

    log.debug('{m}.{f}: downloading security files from source (%s)', decsource.site)
    for dummy, relpath, source in decsource.download():
        for relpath, source in decode(relpath, source):
            if relpath:
                if os.path.exists(os.path.join(secfiles_cache, '')):
                    with open(os.path.join(secfiles_cache, relpath), 'w') as fil:
                        fil.write(source)
                yield relpath, source


def _decoder_update_advsettings(secfiles, ex=None):
    if not ex:
        advsettings.update('secfiles:*', {'site': secfiles['site']}, allow_star_name=True)
    else:
        secfiles['status'] = str(ex)
        secfiles['failures'] = secfiles.setdefault('failures', 0) + 1
        if any(rc in secfiles['status'] for rc in ('404', '[Errno 2]')) or secfiles['failures'] > 10:
            del secfiles['site']
        advsettings.update('secfiles:*', secfiles, allow_star_name=True)
