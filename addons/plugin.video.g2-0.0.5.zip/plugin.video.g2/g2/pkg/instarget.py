# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2018 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import abc
import errno

from g2.libraries import log
from g2.libraries import addon


from . import src


class InsTargetBase(object):
    __metaclass__ = abc.ABCMeta

    def __init__(self, source, target):
        self.source = source
        self.target = target

    @abc.abstractmethod
    def install(self, ui_update=lambda *a, **kwa: True):
        raise NotImplementedError

    @abc.abstractmethod
    def uninstall(self):
        raise NotImplementedError


class InsTargetNamedSettings(InsTargetBase):
    def __init__(self, *args, **kwargs):
        super(InsTargetNamedSettings, self).__init__(*args, **kwargs)
        if self.target != 'profile':
            raise NotImplementedError

    def install(self, ui_update=lambda *a, **kwa: True):
        for dummy, dpath, dsource in self.source.download():
            for relpath, source in src.decode(dpath, dsource):
                try:
                    log.debug('{m}.{f}: %s: updating advanced settings: "%.100s"', relpath, source)
                    if addon.advsettings_update_sections(source):
                        log.debug('{m}.{f}: %s: installed [%d]', relpath, len(source))
                        return len(source)
                except Exception as ex:
                    log.error('{m}.{f}: %s: %s', relpath, repr(ex), trace=True)

    def uninstall(self):
        pass


class InsTargetFileSystem(InsTargetBase):
    def __init__(self, *args, **kwargs):
        super(InsTargetFileSystem, self).__init__(*args, **kwargs)
        # Allows a single level of directory creation
        if not os.path.exists(os.path.dirname(self.target)):
            raise NotImplementedError

    def install(self, ui_update=lambda *a, **kwa: True):
        parent_dirs_created = {}
        def make_parent_dirs(path):
            parent = os.path.dirname(path)
            if parent not in parent_dirs_created:
                try:
                    os.makedirs(parent)
                    log.debug('{m}.{f}: created directory %s', parent)
                except Exception:
                    pass
                finally:
                    parent_dirs_created[parent] = True

        try:
            for progress, dpath, dsource in self.source.download():
                for relpath, source in src.decode(dpath, dsource):
                    path = os.path.join(self.target, relpath)
                    make_parent_dirs(path)
                    with open(path, 'wb') as fil:
                        fil.write(source)
                    log.debug('{m}.{f}: %s[%d] installed in %s', relpath, len(source), path)
                try:
                    ui_update(progress[0], progress[1])
                except Exception:
                    pass
            return self.target
        except Exception as ex:
            log.error('{m}.{f}: %s: %s', self.target, repr(ex), trace=True)
            self.uninstall()

    def uninstall(self):
        self._remove(self.target)

    def _remove(self, path):
        try:
            if not os.path.isdir(path):
                os.remove(path)
            else:
                for name in os.listdir(path):
                    name_path = os.path.join(path, name)
                    if os.path.isdir(name_path):
                        self._remove(name_path)
                    else:
                        os.remove(path)
                os.rmdir(path)
        except OSError as ex:
            if ex.errno != errno.ENOENT:
                raise
