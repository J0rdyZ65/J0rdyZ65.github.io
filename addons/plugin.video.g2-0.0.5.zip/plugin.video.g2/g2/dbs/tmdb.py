# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import os
import re
import urllib
import datetime

from g2 import defs

from g2.libraries import log
from g2.libraries import client
from g2.libraries import workers
from g2.libraries.language import _

from g2 import platforms
from g2.platforms import addon

from .lib import normalize_imdb


info = {
    'domains': ['api.themoviedb.org'],
    'methods': ['resolve', 'movies', 'tvshows', 'meta', 'persons', 'genres', 'certifications'],
}

_TMDB_IMAGE = 'http://image.tmdb.org/t/p/original/'
_TMDB_POSTER = 'http://image.tmdb.org/t/p/w500/'
_BASE_URL = 'http://api.themoviedb.org/3'
_COMMON_PARAMS = '&api_key=@APIKEY@&include_adult={include_adult}'
_URLS = {
    'movies{title}': '/search/movie?query={title}&language={content_language}|168',
    'movies{year}': '/discover/movie?primary_release_year={year}&language={content_language}|168',
    'movies{person_id}':
        '/discover/movie?sort_by=primary_release_date.desc&with_people={person_id}&language={content_language}|168',
    'movies{genre_id}': '/discover/movie?with_genres={genre_id}&language={content_language}|168',
    'movies{certification}':
        '/discover/movie?certification={certification}&certification_country=US&language={content_language}|168',
    'movies{title}{year}': '/search/movie?query={title}&year={year}&language={content_language}|24',
    'movie_meta{tmdb_id}{lang}': '/movie/{tmdb_id}?append_to_response=credits,releases&language={lang}|168',
    'movie_meta{imdb_id}{lang}': '/movie/{imdb_id}?append_to_response=credits,releases&language={lang}|168',
    'persons{name}': '/search/person?query={name}&language={content_language}|720',
    'movies_featured{}': ('/discover/movie?'
                          'primary_release_date.gte={one_year_ago}&primary_release_date.lte={two_months_ago}&'
                          'sort_by=primary_release_date.desc&language={content_language}|720'),
    'movies_popular{}': '/movie/popular?language={content_language}|168',
    'movies_toprated{}': '/movie/top_rated?language={content_language}|168',
    'movies_theaters{}': '/movie/now_playing?language={content_language}|168',
    'movie_genres{}': '/genre/movie/list?language={platform_language}|720',
    'certifications{}': '/certification/movie/list?language={platform_language}|720',

    'tvshows{year}': '/discover/tv?first_air_date_year={year}&language={content_language}|168',
    'tvshow_genres{}': '/genre/tv/list?language={platform_language}|720',
    'tvshows{genre_id}': '/discover/tv?with_genres={genre_id}&language={content_language}|168',
    'tvshows_featured{}': ('/discover/tv?'
                           'air_date.gte={one_year_ago}&air_date.lte={two_months_ago}&'
                           'sort_by=primary_release_date.desc&language={content_language}|720'),
    'tvshows_popular{}': '/tv/popular?language={content_language}|168',
    'tvshows_toprated{}': '/tv/top_rated?language={content_language}|168',
    'tvshows_onair{}': '/tv/on_the_air?language={content_language}|168',
}


def apikey():
    return addon.setting('tmdb_user_apikey') or addon.setting('tmdb_addon_apikey') or defs.TMDB_APIKEY


def apikey_flavor():
    return (_('User configured apikey') if addon.setting('tmdb_user_apikey') else
            _('{themoviedb} addon apikey',
              themoviedb=addon.info2('metadata.themoviedb.org', 'name')) if addon.setting('tmdb_addon_apikey') else
            _('{g2} hardcoded apikey', g2=addon.info('name')))


def fetch_addon_apikey():
    try:
        with open(os.path.join(addon.info2('metadata.themoviedb.org', 'path'), 'tmdb.xml')) as fil:
            api_key = re.search(r'api_key=([0-9a-fA-F]+)', fil.read()).group(1)
        log.debug('{m}.{f}: fetched metadata.themoviedb.org API key: %s', api_key)
        addon.setting('tmdb_addon_apikey', api_key)
    except Exception:
        pass


def resolve(kind=None, **kwargs):
    if not kind:
        return _URLS.keys()
    if kind not in _URLS or not apikey():
        return None

    for key, val in {
            'content_language': addon.content_language(),
            'platform_language': platforms.info('language'),
            'include_adult': 'true' if defs.TMDB_INCLUDE_ADULT else 'false',
            'one_year_ago': (datetime.datetime.now() - datetime.timedelta(days=365)).strftime('%Y-%m-%d'),
            'two_months_ago': (datetime.datetime.now() - datetime.timedelta(days=60)).strftime('%Y-%m-%d'),
        }.iteritems():
        if key not in kwargs:
            kwargs[key] = val

    for key, val in kwargs.iteritems():
        kwargs[key] = urllib.quote_plus(str(val))

    url, timeout = _URLS[kind].split('|')[0:2]
    return _BASE_URL+(url+_COMMON_PARAMS).format(**kwargs)+'|'+timeout


def movies(url):
    url, timeout = url.split('|')[0:2]
    result = client.get(url.replace('@APIKEY@', apikey(), 1)).json()
    results = result['results']

    log.debug('{m}.{f}: %s: %d movies', url.replace(_BASE_URL, ''), len(results))

    next_url, next_page, max_pages = _tmdb_next_item(url, timeout, result)

    items = []
    for i, item in enumerate(results):
        try:
            title = item['title']
            title = client.replaceHTMLCodes(title)
            title = title.encode('utf-8')

            year = item['release_date']
            year = re.compile(r'(\d{4})').findall(year)[-1]
            year = year.encode('utf-8')

            tmdb = item['id']
            tmdb = re.sub('[^0-9]', '', str(tmdb))
            tmdb = tmdb.encode('utf-8')

            poster = item['poster_path']
            if poster:
                poster = '%s%s' % (_TMDB_POSTER, poster)
                poster = poster.encode('utf-8')

            fanart = item['backdrop_path']
            if not fanart:
                fanart = '0'
            if fanart != '0':
                fanart = '%s%s' % (_TMDB_IMAGE, fanart)
            fanart = fanart.encode('utf-8')

            premiered = item['release_date']
            try:
                premiered = re.compile(r'(\d{4}-\d{2}-\d{2})').findall(premiered)[0]
            except Exception:
                premiered = '0'
            premiered = premiered.encode('utf-8')

            rating = str(item['vote_average'])
            if not rating:
                rating = '0'
            rating = rating.encode('utf-8')

            votes = str(item['vote_count'])
            try:
                votes = str(format(int(votes), ',d'))
            except Exception:
                pass
            if not votes:
                votes = '0'
            votes = votes.encode('utf-8')

            plot = item['overview']
            if not plot:
                plot = '0'
            plot = client.replaceHTMLCodes(plot)
            plot = plot.encode('utf-8')

            tagline = re.compile(r'[.!?][\s]{1,2}(?=[A-Z])').split(plot)[0]
            try:
                tagline = tagline.encode('utf-8')
            except Exception:
                pass

            items.append({
                'title': title,
                'originaltitle': title,
                'year': year,
                'premiered': premiered,
                'studio': '0',
                'genre': '0',
                'duration': '0',
                'rating': rating,
                'votes': votes,
                'mpaa': '0',
                'director': '0',
                'writer': '0',
                'cast': '0',
                'plot': plot,
                'tagline': tagline,
                'code': '0',
                'imdb': '0',
                'tmdb': tmdb,
                'tvdb': '0',
                'tvrage': '0',
                'poster': poster,
                'banner': '0',
                'fanart': fanart,
                'next_url': next_url,
                'next_page': next_page,
                'max_pages': max_pages,
            })
        except Exception as ex:
            log.error('{m}.{f}: %s: %s', i, repr(ex))

    return items


def tvshows(url):
    url, timeout = url.split('|')[0:2]
    result = client.get(url.replace('@APIKEY@', apikey(), 1)).json()
    results = result['results']

    log.debug('{m}.{f}: %s: %d tvshows', url.replace(_BASE_URL, ''), len(results))

    next_url, next_page, max_pages = _tmdb_next_item(url, timeout, result)

    items = []
    for i, item in enumerate(results):
        try:
            title = item['name']
            title = client.replaceHTMLCodes(title)
            title = title.encode('utf-8')

            original_title = item['original_name']
            original_title = client.replaceHTMLCodes(original_title)
            original_title = original_title.encode('utf-8')

            year = item['first_air_date']
            year = re.compile(r'(\d{4})').findall(year)[-1]
            year = year.encode('utf-8')

            tmdb = item['id']
            tmdb = re.sub('[^0-9]', '', str(tmdb))
            tmdb = tmdb.encode('utf-8')

            poster = item['poster_path']
            if poster:
                poster = '%s%s' % (_TMDB_POSTER, poster)
                poster = poster.encode('utf-8')

            fanart = item['backdrop_path']
            if not fanart:
                fanart = '0'
            if fanart != '0':
                fanart = '%s%s' % (_TMDB_IMAGE, fanart)
            fanart = fanart.encode('utf-8')

            rating = str(item['vote_average'])
            if not rating:
                rating = '0'
            rating = rating.encode('utf-8')

            votes = str(item['vote_count'])
            try:
                votes = str(format(int(votes), ',d'))
            except Exception:
                pass
            if not votes:
                votes = '0'
            votes = votes.encode('utf-8')

            plot = item['overview']
            if not plot:
                plot = '0'
            plot = client.replaceHTMLCodes(plot)
            plot = plot.encode('utf-8')

            tagline = re.compile(r'[.!?][\s]{1,2}(?=[A-Z])').split(plot)[0]
            try:
                tagline = tagline.encode('utf-8')
            except Exception:
                pass

            items.append({
                'title': title,
                'originaltitle': original_title,
                'year': year,
                'studio': '0',
                'genre': '0',
                'duration': '0',
                'rating': rating,
                'votes': votes,
                'mpaa': '0',
                'director': '0',
                'writer': '0',
                'cast': '0',
                'plot': plot,
                'tagline': tagline,
                'code': '0',
                'imdb': '0',
                'tmdb': tmdb,
                'tvdb': '0',
                'tvrage': '0',
                'poster': poster,
                'banner': '0',
                'fanart': fanart,
                'next_url': next_url,
                'next_page': next_page,
                'max_pages': max_pages,
            })
        except Exception as ex:
            log.error('{m}.{f}: %s: %s', i, repr(ex))

    return items


def meta(metas):
    max_concurrent_threads = addon.max_concurrent_threads()
    for i in range(0, len(metas), max_concurrent_threads):
        if max_concurrent_threads == 1:
            try:
                _meta_worker(metas[i])
            except Exception as ex:
                log.debug('{m}.{f}: %s: %s', metas[i].get('url', '').replace(_BASE_URL, ''), ex)
        else:
            threads = [workers.Thread(_meta_worker, metas[j], name=metas[j].get('url', '').replace(_BASE_URL, ''))
                       for j in range(i, min(len(metas), i+max_concurrent_threads))]
            dummy = [t.start() for t in threads]
            dummy = [t.join() for t in threads]
            dummy = [log.debug('{m}.{f}: %s: %s', t.name, t.exc) for t in threads if t.exc]


def _meta_worker(meta):
    if meta['item']:
        return

    url = meta['url'].split('|')[0]
    result = client.get(url.replace('@APIKEY@', apikey(), 1), timeout=10).json()

    log.debug('{m}.{f}: %s: %s', url.replace(_BASE_URL, ''), result)

    item = {}

    # (fixme) really really repetitive code...
    title = result.get('title', '')
    title = client.replaceHTMLCodes(title)
    title = title.encode('utf-8')
    if title:
        item.update({'title': title})

    year = result.get('release_date', '')
    try:
        # Update the release date with the local release date if existing
        content_language = addon.content_language()
        for localrel in result['releases']['countries']:
            if localrel['iso_3166_1'].lower() == content_language:
                localyear = localrel.get('release_date')
                if localyear:
                    year = localyear
                    break
    except Exception:
        pass
    try:
        year = re.compile(r'(\d{4})').findall(year)[-1]
    except Exception:
        year = ''
    year = year.encode('utf-8')
    if year:
        item.update({'year': year})

    name = title if not year else '%s (%s)'%(title, year)
    try:
        name = name.encode('utf-8')
    except Exception:
        pass
    if name:
        item.update({'name': name})

    tmdb = result.get('id')
    if not tmdb:
        tmdb = '0'
    tmdb = re.sub('[^0-9]', '', str(tmdb))
    tmdb = tmdb.encode('utf-8')
    if tmdb != '0':
        item.update({'tmdb': tmdb})

    imdb = result.get('imdb_id')
    if imdb:
        imdb = normalize_imdb(imdb)
        item.update({'imdb': imdb, 'code': imdb})

    poster = result.get('poster_path')
    if not poster:
        poster = '0'
    if poster != '0':
        poster = '%s%s' % (_TMDB_POSTER, poster)
    poster = poster.encode('utf-8')
    if poster != '0':
        item.update({'poster': poster})

    fanart = result.get('backdrop_path')
    if not fanart:
        fanart = '0'
    if fanart != '0':
        fanart = '%s%s' % (_TMDB_IMAGE, fanart)
    fanart = fanart.encode('utf-8')
    if fanart != '0':
        item.update({'fanart': fanart})

    premiered = result.get('release_date')
    try:
        premiered = re.compile(r'(\d{4}-\d{2}-\d{2})').findall(premiered)[0]
    except Exception:
        premiered = '0'
    if not premiered:
        premiered = '0'
    premiered = premiered.encode('utf-8')
    if premiered != '0':
        item.update({'premiered': premiered})

    studio = result.get('production_companies')
    try:
        studio = [x['name'] for x in studio][0]
    except Exception:
        studio = '0'
    if not studio:
        studio = '0'
    studio = studio.encode('utf-8')
    if studio != '0':
        item.update({'studio': studio})

    genre = result.get('genres')
    try:
        genre = [x['name'] for x in genre]
    except Exception:
        genre = ''
    genre = '0' if not genre else ' / '.join(genre)
    genre = genre.encode('utf-8')
    if genre != '0':
        item.update({'genre': genre})

    duration = str(result.get('runtime', 0))
    if not duration:
        duration = '0'
    duration = duration.encode('utf-8')
    if duration != '0':
        item.update({'duration': duration})

    rating = str(result.get('vote_average', 0))
    if not rating:
        rating = '0'
    rating = rating.encode('utf-8')
    if rating != '0':
        item.update({'rating': rating})

    votes = str(result.get('vote_count', 0))
    try:
        votes = str(format(int(votes), ',d'))
    except Exception:
        pass
    if not votes:
        votes = '0'
    votes = votes.encode('utf-8')
    if votes != '0':
        item.update({'votes': votes})

    try:
        mpaa = result['releases']['countries']
        try:
            mpaa = [x for x in mpaa if not x['certification'] == '']
        except Exception:
            mpaa = '0'
        try:
            mpaa = ([x for x in mpaa if x['iso_3166_1'].encode('utf-8') == 'US'] +
                    [x for x in mpaa if x['iso_3166_1'].encode('utf-8') != 'US'])[0]['certification']
        except Exception:
            mpaa = '0'
        mpaa = mpaa.encode('utf-8')
    except Exception:
        mpaa = '0'
    if mpaa != '0':
        item.update({'mpaa': mpaa})

    try:
        director = result['credits']['crew']
        try:
            director = [x['name'] for x in director if x['job'].encode('utf-8') == 'Director']
        except Exception:
            director = ''
        director = '0' if not director else ' / '.join(director)
        director = director.encode('utf-8')
    except Exception:
        director = '0'
    if director != '0':
        item.update({'director': director})

    try:
        writer = result['credits']['crew']
        try:
            writer = [x['name'] for x in writer if x['job'].encode('utf-8') in ['Writer', 'Screenplay']]
        except Exception:
            writer = ''
        try:
            writer = [x for n, x in enumerate(writer) if x not in writer[:n]]
        except Exception:
            writer = ''
        writer = '0' if not writer else ' / '.join(writer)
        writer = writer.encode('utf-8')
    except Exception:
        writer = '0'
    if writer != '0':
        item.update({'writer': writer})

    try:
        cast = result['credits']['cast']
        try:
            cast = [(x['name'].encode('utf-8'), x['character'].encode('utf-8')) for x in cast]
        except Exception:
            cast = []
        if cast:
            item.update({'cast': cast})
    except Exception:
        pass

    plot = result.get('overview')
    if not plot:
        plot = '0'
    plot = plot.encode('utf-8')
    if plot != '0':
        item.update({'plot': plot})

    tagline = result.get('tagline')
    if not tagline and plot != '0':
        tagline = re.compile(r'[.!?][\s]{1,2}(?=[A-Z])').split(plot)[0]
    elif not tagline:
        tagline = '0'
    try:
        tagline = tagline.encode('utf-8')
    except Exception:
        pass
    if tagline != '0':
        item.update({'tagline': tagline})

    meta['item'] = item
    meta['url'] = None


def persons(url):
    url, timeout = url.split('|')[0:2]
    result = client.get(url.replace('@APIKEY@', apikey(), 1)).json()
    results = result['results']

    log.debug('{m}.{f}: %s: %d persons', url.replace(_BASE_URL, ''), len(results))

    next_url, next_page, max_pages = _tmdb_next_item(url, timeout, result)

    items = []
    for item in results:
        try:
            name = item['name']
            name = name.encode('utf-8')

            person_id = str(item['id'])
            person_id = person_id.encode('utf-8')

            image = '%s%s' % (_TMDB_IMAGE, item['profile_path'])
            image = image.encode('utf-8')

            items.append({
                'name': name,
                'id': person_id,
                'image': image,
                'next_url': next_url,
                'next_page': next_page,
                'max_pages': max_pages,
            })
        except Exception as ex:
            log.error('{m}.{f}: %s: %s', item, repr(ex))

    return items


def _tmdb_next_item(url, timeout, result):
    page = str(result['page'])
    total = str(result['total_pages'])
    if page == total:
        return ('', 0, 0)
    page = int(page) + 1
    next_url = '%s&page=%s%s' % (url.split('&page=', 1)[0], page, '' if not timeout else '|'+timeout)
    return (next_url.encode('utf-8'), page, total)


def genres(url):
    url = url.split('|')[0]
    result = client.get(url.replace('@APIKEY@', apikey(), 1)).json()
    results = result['genres']

    log.debug('{m}.{f}: %d genres', len(results))

    items = []
    for item in results:
        try:
            name = item['name']
            name = name.encode('utf-8')

            genre_id = str(item['id'])
            genre_id = genre_id.encode('utf-8')

            items.append({
                'name': name,
                'id': genre_id,
            })
        except Exception as ex:
            log.error('{m}.{f}: %s: %s', item, repr(ex))

    return items


def certifications(url, country):
    url = url.split('|')[0]
    result = client.get(url.replace('@APIKEY@', apikey(), 1)).json()
    results = result['certifications'][country]

    log.debug('{m}{f}: %s: %d certifications', country, len(results))

    items = []
    for item in results:
        try:
            name = item['certification']
            name = name.encode('utf-8')

            meaning = item['meaning']
            meaning = meaning.encode('utf-8')

            order = item['order']

            items.append({
                'name': name,
                'meaning': meaning,
                'order': order,
            })
        except Exception as ex:
            log.error('{m}.{f}: %s: %s', item, repr(ex))

    return items
