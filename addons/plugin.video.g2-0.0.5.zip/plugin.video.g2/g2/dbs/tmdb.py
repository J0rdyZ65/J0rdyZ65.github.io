# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import os
import re
import urllib
import datetime
from io import open
from six.moves import urllib

from g2 import defs

from g2.libraries import client
from g2.libraries import workers

from g2 import platforms
from g2.platforms import log
from g2.platforms import addon

from .lib import kwargs_quote


info = {
    'domains': ['api.themoviedb.org'],
    'methods': ['resolve', 'movies', 'tvshows', 'meta', 'persons', 'genres', 'certifications'],
}

_TMDB_IMAGE_BASE_URL = 'https://image.tmdb.org/t/p/original/'
_TMDB_POSTER_BASE_URL = 'https://image.tmdb.org/t/p/w500/'
_BASE_URL = 'https://api.themoviedb.org'
_COMMON_PARAMS = '&api_key=@APIKEY@&include_adult={include_adult}'
_URLS = {
    'movies{title}': '3/search/movie?query={title}&language={content_language}|168',
    'movies{year}': '3/discover/movie?primary_release_year={year}&language={content_language}|168',
    'movies{person_id}':
        '3/discover/movie?sort_by=primary_release_date.desc&with_people={person_id}&language={content_language}|168',
    'movies{genre_id}': '3/discover/movie?with_genres={genre_id}&language={content_language}|168',
    'movies{certification}':
        '3/discover/movie?certification={certification}&certification_country=US&language={content_language}|168',
    'movies{title}{year}': '3/search/movie?query={title}&year={year}&language={content_language}|24',
    'movie_meta{tmdb}{lang}': '3/movie/{tmdb}?append_to_response=credits,releases&language={lang}|168',
    'movie_meta{imdb}{lang}': '3/movie/{imdb}?append_to_response=credits,releases&language={lang}|168',
    'persons{name}': '3/search/person?query={name}&language={content_language}|720',
    'movies_featured{}': ('3/discover/movie?'
                          'primary_release_date.gte={one_year_ago}&primary_release_date.lte={two_months_ago}&'
                          'sort_by=primary_release_date.desc&language={content_language}|720'),
    'movies_popular{}': '3/movie/popular?language={content_language}|168',
    'movies_toprated{}': '3/movie/top_rated?language={content_language}|168',
    'movies_theaters{}': '3/movie/now_playing?language={content_language}|168',
    'movie_genres{}': '3/genre/movie/list?language={platform_language}|720',
    'certifications{}': '3/certification/movie/list?language={platform_language}|720',

    'tvshows{year}': '3/discover/tv?first_air_date_year={year}&language={content_language}|168',
    'tvshow_genres{}': '3/genre/tv/list?language={platform_language}|720',
    'tvshows{genre_id}': '3/discover/tv?with_genres={genre_id}&language={content_language}|168',
    'tvshows_featured{}': ('3/discover/tv?'
                           'air_date.gte={one_year_ago}&air_date.lte={two_months_ago}&'
                           'sort_by=primary_release_date.desc&language={content_language}|720'),
    'tvshows_popular{}': '3/tv/popular?language={content_language}|168',
    'tvshows_toprated{}': '3/tv/top_rated?language={content_language}|168',
    'tvshows_onair{}': '3/tv/on_the_air?language={content_language}|168',
}


def apikey():
    return addon.setting('tmdb_user_apikey') or addon.setting('tmdb_addon_apikey') or defs.TMDB_APIKEY


def apikey_flavor():
    return ('user' if addon.setting('tmdb_user_apikey') else
            'themoviedb' if addon.setting('tmdb_addon_apikey') else
            'addon')


def fetch_addon_apikey():
    try:
        with open(os.path.join(addon.info2('metadata.themoviedb.org', 'path'), 'tmdb.xml'), encoding='utf-8') as fil:
            api_key = re.search(r'api_key=([0-9a-fA-F]+)', fil.read()).group(1)
        log.debug('{m}.{f}: fetched metadata.themoviedb.org API key: %s', api_key)
        addon.setting('tmdb_addon_apikey', api_key)
    except Exception:
        pass


def resolve(kind=None, **kwargs):
    if not kind:
        return _URLS.keys()
    if kind not in _URLS or not apikey():
        return None

    kwargs_quote(kwargs, {
        'content_language': addon.content_language(),
        'platform_language': platforms.info('language'),
        'include_adult': 'true' if defs.TMDB_INCLUDE_ADULT else 'false',
        'one_year_ago': (datetime.datetime.now() - datetime.timedelta(days=365)).strftime('%Y-%m-%d'),
        'two_months_ago': (datetime.datetime.now() - datetime.timedelta(days=60)).strftime('%Y-%m-%d'),
        })

    url, expire = _URLS[kind].split('|')[0:2]
    return urllib.parse.urljoin(_BASE_URL, (url + _COMMON_PARAMS).format(**kwargs) + '|' + expire)


def movies(url):
    return _videos('movie', url)


def tvshows(url):
    return _videos('tvshow', url)


def meta(metas):
    max_concurrent_threads = addon.max_concurrent_threads()
    for i in range(0, len(metas), max_concurrent_threads):
        if max_concurrent_threads == 1:
            try:
                _meta_worker(metas[i])
            except Exception as ex:
                log.debug('{m}.{f}: %s: %s', metas[i].get('url', '').replace(_BASE_URL, ''), ex)
        else:
            threads = [workers.Thread(_meta_worker, metas[j], name=metas[j].get('url', '').replace(_BASE_URL, ''))
                       for j in range(i, min(len(metas), i+max_concurrent_threads))]
            dummy = [t.start() for t in threads]
            dummy = [t.join() for t in threads]
            dummy = [log.debug('{m}.{f}: %s: %s', t.name, t.exc) for t in threads if t.exc]


def persons(url):
    url, expire = url.split('|')[0:2]
    result = client.get(url.replace('@APIKEY@', apikey(), 1)).json()
    next_url, next_page, max_pages = _tmdb_next_page(url, expire, result)
    items = result['results']

    log.debug('{m}.{f}: %s: %d persons', url.replace(_BASE_URL, ''), len(items))

    matches = []
    for item in items:
        try:
            person = {
                'name': item['name'],
                'id': item['id'],
                'next_url': next_url,
                'next_page': next_page,
                'max_pages': max_pages,
            }

            try:
                person['image'] = _TMDB_IMAGE_BASE_URL + item['profile_path']
            except Exception:
                pass

            matches.append(person)
        except Exception as ex:
            log.debug('{m}.{f}: %s: %s', item, repr(ex))

    return matches


def genres(url):
    url = url.split('|')[0]
    result = client.get(url.replace('@APIKEY@', apikey(), 1)).json()
    items = result['genres']

    log.debug('{m}.{f}: %d genres', len(items))

    matches = []
    for item in items:
        try:
            genre = {
                'name': item['name'],
                'id': item['id'],
            }

            matches.append(genre)
        except Exception as ex:
            log.debug('{m}.{f}: %s: %s', item, repr(ex))

    return matches


def certifications(url, country):
    url = url.split('|')[0]
    result = client.get(url.replace('@APIKEY@', apikey(), 1)).json()
    items = result['certifications'][country]

    log.debug('{m}{f}: %s: %d certifications', country, len(items))

    matches = []
    for item in items:
        try:
            certification = {
                'name': item['certification'],
                'meaning': item['meaning'],
                'order': item['order'],
            }
            matches.append(certification)
        except Exception as ex:
            log.debug('{m}.{f}: %s: %s', item, repr(ex))

    return matches


def _videos(content, url):
    url, expire = url.split('|')[0:2]
    result = client.get(url.replace('@APIKEY@', apikey(), 1)).json()
    next_url, next_page, max_pages = _tmdb_next_page(url, expire, result)
    items = result['results']

    log.debug('{m}.{f}: %s: %d %ss', url.replace(_BASE_URL, ''), len(items), content)

    videos = []
    for item in items:
        try:
            video = {
                'tmdb': item['id'],
                'next_url': next_url,
                'next_page': next_page,
                'max_pages': max_pages,
            }

            if content == 'movie':
                video['title'] = item['title']
                video['originaltitle'] = item['original_title']
                year = item.get('release_date')
            elif content == 'tvshow':
                video['title'] = item['name']
                video['originaltitle'] = item['original_name']
                year = item.get('first_air_date')

            for tag, src in {
                    'year': lambda t: int(re.search(r'(\d{4})', year).group(1)),
                    'premiered': lambda t: re.search(r'(\d{4}-\d{2}-\d{2})', item['release_date']).group(1),
                    'poster': lambda t: _TMDB_POSTER_BASE_URL + item['poster_path'],
                    'fanart': lambda t: _TMDB_IMAGE_BASE_URL + item['backdrop_path'],
                    'rating': 'vote_average',
                    'votes': 'vote_count',
                    'plot': 'overview',
                    'tagline': lambda t: re.search(r'[.!?][\s]{1,2}(?=[A-Z])', item['overview']).split()[0],
            }.items():
                try:
                    video[tag] = item[src] if not callable(src) else src(tag)
                except Exception:
                    pass

            if 'rating' in video:
                video['rating_source'] = 'tmdb'

            videos.append(video)
        except Exception as ex:
            log.debug('{m}.{f}: %s %s: %s', content, item, repr(ex))

    return videos


def _meta_worker(meta):
    if meta['item']:
        return

    url = meta['url'].split('|')[0]
    item = client.get(url.replace('@APIKEY@', apikey(), 1), timeout=10).json()

    # NOTE: movie only

    video = {
        'tmdb': item['id'],
        'title': item['title'],
        'originaltitle': item['original_title'],
    }

    content_language = addon.content_language()
    for localrel in item.get('releases', {}).get('countries', []):
        if localrel.get('iso_3166_1', '').lower() == content_language:
            localyear = localrel.get('release_date')
            if localyear:
                year = localyear
                break
    else:
        year = item.get('release_date')

    for tag, src in {
            'imdb': 'imdb_id',
            'year': lambda t: int(re.search(r'(\d{4})', year).group(1)),
            'premiered': lambda t: re.search(r'(\d{4}-\d{2}-\d{2})', item['release_date']).group(1),
            'poster': lambda t: _TMDB_POSTER_BASE_URL + item['poster_path'],
            'fanart': lambda t: _TMDB_IMAGE_BASE_URL + item['backdrop_path'],
            'studio': lambda t: item['production_companies'][0]['name'],
            'genre': lambda t: ' / '.join([g['name'] for g in item.get('genres', [])]),
            'director': lambda t: ' / '.join([x['name'] for x in item['credits']['crew'] if x['job'].lower() == 'director']),
            'cast': lambda t: [[x['name'], x['character']] for x in item['credits']['cast']],
            'duration': 'runtime',
            'rating': 'vote_average',
            'votes': 'vote_count',
            'plot': 'overview',
            'tagline': lambda t: re.search(r'[.!?][\s]{1,2}(?=[A-Z])', item['overview']).split()[0],
    }.items():
        try:
            video[tag] = item[src] if not callable(src) else src(tag)
        except Exception:
            pass

    if 'rating' in video:
        video['rating_source'] = 'tmdb'

    try:
        mpaa = [x for x in item['releases']['countries'] if not x['certification'] == '']
        video['mpaa'] = ([x for x in mpaa if x['iso_3166_1'].upper() == 'US'] +
                         [x for x in mpaa if x['iso_3166_1'].upper() != 'US'])[0]['certification']
    except Exception:
        pass

    try:
        writer = [x['name'] for x in item['credits']['crew'] if x['job'].lower() in ['writer', 'screenplay']]
        video['writer'] = ' / '.join([x for n, x in enumerate(writer) if x not in writer[:n]])
    except Exception:
        pass

    meta['item'] = video
    meta['url'] = None


def _tmdb_next_page(url, expire, result):
    page = result['page']
    total = result['total_pages']
    if page == total:
        return '', 0, 0
    page += 1
    next_url = '%s&page=%s%s' % (url.split('&page=', 1)[0], page, '' if not expire else '|' + expire)
    return next_url, page, total
