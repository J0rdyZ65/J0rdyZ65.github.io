# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import re
from six.moves import urllib

from g2 import defs
from g2 import dbs

from g2.libraries import client

from g2.platforms import log
from g2.platforms import addon


info = {
    'priority': defs.DEFAULT_PACKAGE_PRIORITY - 1,
    'domains': ['predb.me'],
    'methods': ['resolve', 'movies'],
}

_BASE_URL = 'http://predb.me'
_URLS = {
    'movies_recently_added{}': '?search=-MD&cats=movies&language={content_language}&page=1|24',
}


def resolve(kind=None, **kwargs):
    if not kind:
        return _URLS.keys()
    if kind not in _URLS:
        return None

    for key, val in {
            'content_language': addon.content_language(fmt='English'),
    }.iteritems():
        if key not in kwargs:
            kwargs[key] = val

    for key, val in kwargs.iteritems():
        kwargs[key] = urllib.parse.quote_plus(str(val))

    return urllib.parse.urljoin(_BASE_URL, _URLS[kind].format(**kwargs))


def movies(url):
    url, timeout = url.split('|')[0:2]
    result = client.get(url, cfbypass=True).text
    results = client.parseDOM(result, 'div', attrs={'class': 'post'})
    results = [(client.parseDOM(i, 'a', attrs={'class': 'p-title.*?'}),
                re.compile(r'(\d{4}-\d{2}-\d{2})').findall(i)) for i in results]
    results = [(i[0][0], i[1][0]) for i in results if len(i[0]) > 0 and len(i[1]) > 0]
    results = [(re.sub(r'(\.|\(|\[|\s)(\d{4}|S\d*E\d*|3D)(\.|\)|\]|\s)(.+)', '', i[0]),
                re.compile(r'[\.|\(|\[|\s](\d{4})[\.|\)|\]|\s]').findall(i[0]), re.sub('[^0-9]', '', i[1])) for i in results]
    results = [(i[0], i[1][-1], i[2]) for i in results if len(i[1]) > 0]
    results = [(re.sub(r'(\.|\(|\[|LIMITED|UNCUT)', ' ', i[0]).strip().lower(), i[1]) for i in results]
    results = [x for y, x in enumerate(results) if x not in results[0:y]]

    log.debug('{m}.{f}: %s: %s listings', url.replace(_BASE_URL, ''), len(results))

    items = {}
    def resolve_item(i, title_year):
        try:
            title, year = title_year
            matches = dbs.movies('movies{title}{year}', title=title, year=year)
            if not matches or not matches[0]:
                log.debug('{m}.{f}: %s (%s): no matching movies', title, year)
            else:
                match = matches[0]
                for key in ('imdb', 'tmdb'):
                    if match.get(key):
                        break
                else:
                    key = 'title'
                if match[key] not in items:
                    match['position'] = i
                    items[match[key]] = match
        except Exception as ex:
            log.notice('{m}.{f}: %s (%s): %s', title_year, repr(ex))

    max_pages = 0
    try:
        page = int(re.search(r'&page=(\d+)', url).group(1))
        next_page = page + 1
        next_url = url.replace('&page=%d'%page, '&page=%d'%next_page) + ('' if not timeout else '|'+timeout)
        try:
            max_pages = int(client.parseDOM(result, 'a', attrs={'class': 'page-button last-page'})[0].split(' ')[0])
        except Exception as ex:
            log.debug('{m}.{f}: %s: %s', url.replace(_BASE_URL, ''), repr(ex))
    except Exception as ex:
        log.debug('{m}.{f}: %s: %s', url.replace(_BASE_URL, ''), repr(ex))
        next_url = ''
        next_page = 0

    log.debug('{m}.{f}: %s: next_url=%s, next_page=%s, max_pages=%s',
              url.replace(_BASE_URL, ''), next_url.replace(_BASE_URL, ''), next_page, max_pages)

    for i, item in enumerate(results):
        resolve_item(i, item)

    for i in items.itervalues():
        i['next_url'] = next_url
        i['next_page'] = next_page
        i['max_pages'] = max_pages

    return sorted([i for i in items.itervalues()], key=lambda i: i['position'])
