# -*- coding: utf-8 -*-

kind = 'dbs'
