# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import json
import time
from six.moves import urllib

from g2 import defs

from g2.libraries import cache
from g2.libraries import client

from g2.platforms import log
from g2.platforms import addon

from .lib import kwargs_quote


info = {
    'domains': ['api.trakt.tv'],
    'methods': ['resolve', 'movies', 'tvshows', 'watched'],
}

_COMMON_POST_VARS = {
    'client_id': defs.TRAKT_CLIENT_ID,
    'client_secret': '9899db3e81158f6ebbb7b5afbce043b99caa13fba98c527c00c44ca44eca72c5',
    'redirect_uri': 'urn:ietf:wg:oauth:2.0:oob',
}

_COMMON_HEADERS = {
    'Content-Type': 'application/json',
    'trakt-api-key': defs.TRAKT_CLIENT_ID,
    'trakt-api-version': '2',
}

_BASE_URL = 'https://api.trakt.tv'
_URLS = {
    # Public query
    'movies_trending{}': 'movies/trending?limit=20|168',
    'tvshows_trending{}': 'shows/trending?limit=20|168',

    'movie_ids{imdb}': 'search/imdb/{imdb}',
    'movie_ids{tmdb}': 'search/tmdb/{tmdb}?type=movie',
    'tvshow_ids{imdb}': 'search/imdb/{imdb}',
    'tvshow_ids{tmdb}': 'search/tmdb/{tmdb}?type=show',
    'tvshow_ids{tvdb}': 'search/tvdb/{tvdb}?type=show',

    # For the below urls trakt must be enabled and with a valid token
    'movies_recommendations{}':
        'recommendations/movies?limit=%d -- {trakt_enabled}{trakt_token}' % defs.TRAKT_MAX_RECOMMENDATIONS,
    'tvshows_recommendations{}':
        'recommendations/shows?limit=%d -- {trakt_enabled}{trakt_token}' % defs.TRAKT_MAX_RECOMMENDATIONS,
}


def resolve(kind=None, **kwargs):
    if not kind:
        return _URLS.keys()
    if kind not in _URLS:
        return None

    kwargs_quote(kwargs, {
        '' if addon.setting('trakt_enabled') == 'false' else 'trakt_enabled': True,
        'trakt_token': addon.setting('trakt.token'),
        })

    try:
        return urllib.parse.urljoin(_BASE_URL, _URLS[kind].format(**kwargs).split(' ')[0])
    except Exception:
        return None


def content_ids(content, met):
    for dbid in ('tmdb', 'tvdb', 'imdb'):
        if met.get(dbid) and _ids(resolve('%s_ids{%s}' % (content, dbid), **{dbid: met[dbid]}), met):
            break


def _ids(url, met):
    def traktreq(url):
        return _traktreq(url).content

    if not url:
        return False

    res = cache.get(traktreq, url, cacheopt_expire=60*24*365, cacheopt_table='rel_trakt')

    for i in json.loads(res):
        ids = i.get(i.get('type'), {}).get('ids', {})
        for dbid, dbvalue in ids.iteritems():
            if met.get(dbid) == dbvalue:
                met.update(ids)
                return True

    return False


def movies(url):
    return _content(url, 'movie')


def tvshows(url):
    return _content(url, 'show')


def _content(url, content='movie'):
    if '|' not in url:
        expire = 0
    else:
        url, expire = url.split('|')[0:2]

    res = _traktreq(url)
    next_url, next_page, max_pages = _trakt_next_page(url, expire, res)
    results = res.json()
    items = [i[content] for i in results if content in i]
    if not items:
        items = results

    log.debug('{m}.{f}: %s: %d %s: next_url=%s, next_page=%s, max_pages=%s',
              url.replace(_BASE_URL, ''), len(items), content, next_url.replace(_BASE_URL, ''), next_page, max_pages)

    videos = []
    for item in items:
        try:
            video = {
                'next_url': next_url,
                'next_page': next_page,
                'max_pages': max_pages,
            }

            for dbid in ('imdb', 'tmdb', 'tvdb'):
                if item['ids'].get(dbid):
                    video[dbid] = item['ids'][dbid]

            for tag, src in {
                    'title': 'title',
                    'originaltitle': 'title',
                    'year': 'year',
            }.items():
                try:
                    video[tag] = item[src]
                except Exception:
                    pass

            videos.append(video)
        except Exception as ex:
            log.debug('{m}.{f}: %s: %s', item, repr(ex))

    return videos


def watched(content, meta, seen):
    if addon.setting('trakt_enabled') == 'false' or not addon.setting('trakt.token') or not meta.get('imdb'):
        return None
    if content == 'movie':
        trakt_content = 'movie'
    elif content in ('tvshow', 'season', 'episode'):
        trakt_content = 'show'
    else:
        return None
    imdb = meta['imdb']

    if isinstance(seen, set):
        indicators = _history_sync(trakt_content, timeout=30)
        indicators = [i for i in indicators if trakt_content in i and i[trakt_content]['ids']['imdb'] == imdb]

        seenlen = len(seen)
        if content == 'movie':
            seen.update([True] if indicators else [])
        elif content == 'tvshow':
            seasons = [s for i in indicators if 'seasons' in i for s in i['seasons']]
            seen.update([(e['number'], s['number']) for s in seasons if 'episodes' in s for e in s['episodes']])
        elif content == 'season':
            seasons = [s for i in indicators if 'seasons' in i for s in i['seasons'] if s['number'] == meta['season']]
            seen.update([(e['number'], s['number']) for s in seasons if 'episodes' in s for e in s['episodes']])
        elif content == 'episode':
            seasons = [s for i in indicators if 'seasons' in i for s in i['seasons'] if s['number'] == meta['season']]
            episodes = [e for s in seasons if 'episodes' in s for e in s['episodes'] if e['number'] == meta['episode']]
            seen.update([True] if episodes else [])
        if seenlen != len(seen):
            log.debug('{m}.{f}: %s %s/%s/%s: %s [%d]',
                      content, imdb, meta.get('season'), meta.get('episode'), seen, len(seen))

    else:
        post_url = '/sync/history' if seen else '/sync/history/remove'
        post_data = {
            trakt_content+'s': [{
                'ids': {
                    'imdb': imdb
                }
            }]
        }
        if trakt_content == 'show' and meta.get('season'):
            post_data[trakt_content+'s'][0].update({
                'seasons': [{
                    'number': meta['season'],
                }]
            })
            if meta.get('episode'):
                post_data[trakt_content+'s'][0]['seasons'][0].update({
                    'episodes': [{
                        'number': meta['episode'],
                    }]
                })

        res = _traktreq(post_url, post_data)
        log.debug('{m}.{f}: %s imdb=%s: %s, %s, res:%s', content, imdb, post_url, post_data, res.status_code)
        if res.status_code in [client.codes.ok, client.codes.created, client.codes.no_content]: #pylint: disable=E1101
            _history_sync(trakt_content)

    return None


def auth_device(ui_update):
    try:
        phase = 'code generation'
        with client.Session(headers=_COMMON_HEADERS) as session:
            res = session.post(urllib.parse.urljoin(_BASE_URL, '/oauth/device/code'), json=_COMMON_POST_VARS).json()

            code = res['user_code']
            url = res['verification_url']
            device_code = res['device_code']
            expires_in = res['expires_in']
            interval = res['interval']

            post = _COMMON_POST_VARS
            post.update({
                'code': str(device_code),
            })

            phase = 'device authorization'
            start_time = time.time()
            next_check_at = start_time + interval
            while time.time()-start_time < expires_in:
                if not ui_update(code, url, time.time()-start_time, expires_in):
                    raise Exception('user aborted')
                if time.time() < next_check_at:
                    continue

                res = session.post(urllib.parse.urljoin(_BASE_URL, '/oauth/device/token'), json=post)
                next_check_at = time.time() + interval

                if res.status_code in [400, 429]:
                    pass

                elif res.status_code != client.codes.ok: #pylint: disable=E1101
                    res.raise_for_status()

                else:
                    tokens = res.json()
                    addon.setting('trakt.token', str(tokens['access_token']))
                    addon.setting('trakt.refresh', str(tokens['refresh_token']))

                    authorization = {'Authorization': 'Bearer %s'%str(tokens['access_token'])}

                    res = session.get(urllib.parse.urljoin(_BASE_URL, '/users/settings'),
                                      headers=authorization, raise_error=True).json()
                    return res['user']['username']

        raise Exception('code expired')

    except Exception as ex:
        log.notice('{m}.{f}: %s: %s', phase, repr(ex))
        raise Exception('%s: %s' % (phase, repr(ex)))


def _trakt_next_page(url, expire, res):
    max_pages = 0
    try:
        page = int(res.headers['X-Pagination-Page'])
        max_pages = int(res.headers['X-Pagination-Page-Count'])
        if max_pages and page >= max_pages:
            raise Exception('last page reached')

        page += 1
        query = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(url).query))
        query.update({'page': page})
        query = urllib.parse.urlencode(query).replace('%2C', ',')
        next_url = url.replace('?' + urllib.parse.urlparse(url).query, '') + '?' + query + ('' if not expire else '|' + expire)
        next_page = page
    except Exception:
        next_url = ''
        next_page = 0

    return next_url, next_page, max_pages


def _history_sync(content, timeout=-1):
    def traktreq(url):
        return _traktreq(url).content

    try:
        if time.time() - _history_sync.cache_time[content] <= timeout * 60:
            return _history_sync.cache_history[content]
    except AttributeError:
        _history_sync.cache_history = {}
        _history_sync.cache_time = {}
    except KeyError:
        pass

    content_history = cache.get(traktreq, '/users/%s/watched/%ss' % (addon.setting('trakt_user'), content),
                                cacheopt_expire=timeout, cacheopt_table='rel_trakt')
    _history_sync.cache_history[content] = json.loads(content_history)
    _history_sync.cache_time[content] = time.time()

    return _history_sync.cache_history[content]


def _traktreq(url, post=None, **kwargs):
    with client.Session(headers=_COMMON_HEADERS, **kwargs) as session:
        token = addon.setting('trakt.token')
        refresh_token = addon.setting('trakt.refresh')

        if not addon.setting('trakt_user') or not token:
            return session.request(url, json=post, raise_error=True)

        authorization = {'Authorization': 'Bearer %s'%token}

        url = urllib.parse.urljoin(_BASE_URL, url)
        res = session.request(url, json=post, headers=authorization)
        if res.status_code in [client.codes.ok, client.codes.created, client.codes.no_content]: #pylint: disable=E1101
            return res

        if res.status_code not in [401, 405]:
            res.raise_for_status()

        # Token expired, refresh it
        oauth = urllib.parse.urljoin(_BASE_URL, '/oauth/token')
        opost = _COMMON_POST_VARS
        opost.update({
            'grant_type': 'refresh_token',
            'refresh_token': refresh_token,
        })

        res = session.post(oauth, json=opost, raise_error=True).json()

        token = str(res['access_token'])
        refresh = str(res['refresh_token'])

        addon.setting('trakt.token', token)
        addon.setting('trakt.refresh', refresh)

        authorization = {'Authorization': 'Bearer %s'%token}

        return session.request(url, json=post, headers=authorization, raise_error=True)
