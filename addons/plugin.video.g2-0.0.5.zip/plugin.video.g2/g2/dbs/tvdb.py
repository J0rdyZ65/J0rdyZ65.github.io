# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
import urllib
import zipfile
import StringIO

from xml.dom import minidom

from g2 import defs

from g2.libraries import log
from g2.libraries import client
from g2.libraries import workers

from g2.platforms import addon


info = {
    'domains': ['thetvdb.com'],
    'methods': ['resolve', 'tvshows', 'meta'],
}

_TVDB_IMAGE = 'http://thetvdb.com/banners/'
_TVDB_POSTER = 'http://thetvdb.com/banners/_cache/'

_BASE_URL = 'http://thetvdb.com/api'
_URLS = {
    'tvshows{title}': '/GetSeries.php?seriesname={title}&language={content_language}',
    'tvshow_meta{tvdb}{lang}': '/@APIKEY@/series/{tvdb}/all/{lang}.zip',
}


def resolve(kind=None, **kwargs):
    if not kind:
        return _URLS.keys()
    if kind not in _URLS:
        return None

    for key, val in {
            'content_language': addon.content_language(),
    }.iteritems():
        if key not in kwargs:
            kwargs[key] = val

    for key, val in kwargs.iteritems():
        kwargs[key] = urllib.quote_plus(str(val))

    return _BASE_URL+_URLS[kind].format(**kwargs)


_SERIE_MAPPINGS_XML_DESC = [
    {'name': 'title',
     'tag': 'SeriesName',
    },
    {'name': 'year',
     'tag': 'FirstAired',
     'map': lambda i, v: re.search(r'(\d{4})', v).group(1),
     'optional': True,
    },
    {'name': 'imdb',
     'tag': 'IMDB_ID',
     'default': '0',
    },
    {'name': 'tvdb',
     'tag': 'id',
     'default': '0',
    },
    {'name': 'tmdb',
     'default': '0',
    },
    {'name': 'plot',
     'tag': 'Overview',
     'optional': True,
    },
    {'name': 'studio',
     'tag': 'Network',
     'optional': True,
    },
    {'name': 'banner',
     'tag': 'banner',
     'optional': True,
     'default': '0',
     'map': lambda i, v: '0' if not v else _TVDB_IMAGE+v,
    },
    {'name': 'fanart',
     'tag': 'fanart',
     'optional': True,
     'default': '0',
     'map': lambda i, v: '0' if not v else _TVDB_IMAGE+v,
    },
    {'name': 'poster',
     'tag': 'poster',
     'optional': True,
     'default': '0',
     'map': lambda i, v: '0' if not v else _TVDB_IMAGE+v,
    },
    {'name': 'premiered',
     'tag': 'FirstAired',
     'optional': True,
     'default': '0',
    },
    {'name': 'genre',
     'tag': 'Genre',
     'optional': True,
     'default': '0',
     'map': lambda i, v: ' / '.join([x for x in v.split('|') if x]),
    },
    {'name': 'duration',
     'tag': 'Runtime',
     'optional': True,
     'default': '0',
    },
    {'name': 'rating',
     'tag': 'Rating',
     'optional': True,
     'default': '0',
    },
    {'name': 'votes',
     'tag': 'RatingCount',
     'optional': True,
     'default': '0',
    },
    {'name': 'mpaa',
     'tag': 'ContentRating',
     'optional': True,
     'default': '0',
    },
    {'name': 'cast',
     'tag': 'Actors',
     'optional': True,
     'default': [],
     'map': lambda i, v: [x.encode('utf-8') for x in v.split('|') if x],
    },
]

_EPISODE_MAPPINGS_XML_DESC = [
    {'name': 'tvdb_episode_id',
     'tag': 'id',
     'optional': True,
    },
    {'name': 'tvdb_season_id',
     'tag': 'seasonid',
     'optional': True,
    },
    {'name': 'title',
     'tag': 'EpisodeName',
     'optional': True,
    },
    {'name': 'premiered',
     'tag': 'FirstAired',
     'map': lambda i, v: '0' if not v or '-00' in v else v,
    },
    {'name': 'season',
     'tag': 'SeasonNumber',
     'map': lambda i, v: str(int(re.sub(r'[^0-9]', '', v))),
    },
    {'name': 'episode',
     'tag': 'EpisodeNumber',
     'map': lambda i, v: str(int(re.sub(r'[^0-9]', '', v))),
    },
    {'name': 'plot',
     'tag': 'Overview',
     'optional': True,
    },
    {'name': 'poster',
     'tag': 'filename',
     'optional': True,
     'map': lambda i, v: '0' if not v else _TVDB_IMAGE+v,
     'default': '0',
    },
    {'name': 'rating',
     'tag': 'Rating',
     'optional': True,
     'default': '0',
    },
    {'name': 'votes',
     'tag': 'RatingCount',
     'optional': True,
     'default': '0',
    },
    {'name': 'director',
     'tag': 'Director',
     'optional': True,
     'map': lambda i, v: ' / '.join([x for x in v.split('|') if x]),
     'default': '0',
    },
    {'name': 'writer',
     'tag': 'Writer',
     'optional': True,
     'map': lambda i, v: ' / '.join([x for x in v.split('|') if x]),
     'default': '0',
    },
]

_BANNER_MAPPINGS_XML_DESC = [
    {'name': 'language',
     'tag': 'Language',
    },
    {'name': 'type',
     'tag': 'BannerType',
    },
    {'name': 'season',
     'tag': 'Season',
     'optional': True,
    },
    {'name': 'path',
     'tag': 'BannerPath'},
]


def tvshows(url):
    url = url.split('|')[0]
    meta_xml = client.get(url).content
    meta_doc = minidom.parseString(meta_xml)

    lang = addon.content_language()
    tvshow_elements = meta_doc.getElementsByTagName('Series')
    tvshow_elements = [e for e in tvshow_elements
                       if _gettextnodes(e.getElementsByTagName('language')) == [lang]
                       or _gettextnodes(e.getElementsByTagName('Language')) == [lang]]

    log.debug('{m}.{f}: %s: %d tvshows', url.replace(_BASE_URL, ''), len(tvshow_elements))

    items = []
    for tvshow_element in tvshow_elements:
        try:
            item = _fields_mapping_xml(tvshow_element, _SERIE_MAPPINGS_XML_DESC)
            items.append(item)
        except Exception as ex:
            log.debug('{m}.{f}: %s: %s', tvshow_element, repr(ex))

    return items


def meta(metas):
    max_concurrent_threads = addon.max_concurrent_threads()
    for i in range(0, len(metas), max_concurrent_threads):
        if max_concurrent_threads == 1:
            try:
                _meta_worker(metas[i])
            except Exception as ex:
                log.debug('{m}.{f}: %s: %s', metas[i].get('url', '').replace(_BASE_URL, ''), ex)
        else:
            threads = [workers.Thread(_meta_worker, metas[j], name=metas[j].get('url', '').replace(_BASE_URL, ''))
                       for j in range(i, min(len(metas), i+max_concurrent_threads))]
            dummy = [t.start() for t in threads]
            dummy = [t.join() for t in threads]
            dummy = [log.debug('{m}.{f}: %s: %s', t.name, t.exc) for t in threads if t.exc]


def _meta_worker(meta):
    if meta['item']:
        return

    url = meta['url'].split('|')[0]
    lang = meta['lang']

    result = client.get(url.replace('@APIKEY@', addon.setting('tvdb_apikey') or defs.TVDB_APIKEY, 1)).content

    log.debug('{m}.{f}: %s: %d bytes', url.replace(_BASE_URL, ''), len(result))

    zipdata = zipfile.ZipFile(StringIO.StringIO(result))
    meta_xml = zipdata.read(lang + '.xml')
    banner_xml = zipdata.read('banners.xml')
    zipdata.close()

    meta_doc = minidom.parseString(meta_xml)
    banner_doc = minidom.parseString(banner_xml)

    tvshow_elements = meta_doc.getElementsByTagName('Series')
    tvshow_elements = [e for e in tvshow_elements
                       if _gettextnodes(e.getElementsByTagName('language')) == [lang]
                       or _gettextnodes(e.getElementsByTagName('Language')) == [lang]]

    log.debug('{m}.{f}: %s: %d tvshows meta for %s lang', url.replace(_BASE_URL, ''), len(tvshow_elements), lang)

    if not tvshow_elements:
        return

    tvshow = _fields_mapping_xml(tvshow_elements[0], _SERIE_MAPPINGS_XML_DESC)
    tvshow['seasons'] = []
    tvshow['episodes'] = []

    season_banners = {}
    for banner_elements in banner_doc.getElementsByTagName('Banner'):
        banner = _fields_mapping_xml(banner_elements, _BANNER_MAPPINGS_XML_DESC)
        # The banners per season are mostly present only in the 'en' language
        if banner['language'] == 'en' and banner['type'] == 'season':
            try:
                season_banners[banner['season']].append(banner)
            except Exception:
                season_banners[banner['season']] = [banner]

    log.debug('{m}.{f}: %s: %d banners (en)', url.replace(_BASE_URL, ''), len(season_banners.keys()))

    tvshow_poster = tvshow['poster'] if tvshow['poster'] != '0' else tvshow['fanart'].replace(_TVDB_IMAGE, _TVDB_POSTER)

    episode_elements = meta_doc.getElementsByTagName('Episode')

    log.debug('{m}.{f}: %s: %d episodes', url.replace(_BASE_URL, ''), len(episode_elements))

    seasons_episodes = {}
    for episode_element in episode_elements:
        episode = _fields_mapping_xml(episode_element, _EPISODE_MAPPINGS_XML_DESC)

        if episode.get('season', '0') == '0' or episode.get('episode', '0') == '0' or not episode.get('title'):
            continue

        episode['tvshowtitle'] = tvshow['title']

        episode_id = int(episode['episode'])
        if seasons_episodes.get(episode['season'], 0) < episode_id:
            seasons_episodes[episode['season']] = episode_id

        if episode_id == 1:
            try:
                season_poster = _TVDB_IMAGE + season_banners[episode['season']][0]['path']
            except Exception:
                season_poster = tvshow_poster

            season = {
                'title': tvshow['title'],
                'season': episode['season'],
                'premiered': episode['premiered'],
                'poster': season_poster,
                'fanart': tvshow['fanart'],
            }
            for dbid in ('tvdb', 'imdb', 'tmdb'):
                season[dbid] = meta[dbid]

            tvshow['seasons'].append(season)

        if episode['poster'] == '0':
            episode['poster'] = season_poster

        for dbid in ['tvdb', 'imdb', 'tmdb']:
            episode[dbid] = meta[dbid]

        tvshow['episodes'].append(episode)

    tvshow_episodes = 0
    for season in tvshow['seasons']:
        season['season_episodes'] = str(seasons_episodes[season['season']])
        tvshow_episodes += seasons_episodes[season['season']]
    tvshow['tvshow_episodes'] = str(tvshow_episodes)

    log.debug('{m}.{f}: %s: %d seasons', url.replace(_BASE_URL, ''), len(seasons_episodes))

    meta['item'] = tvshow
    meta['url'] = None


def _gettextnodes(ele):
    return [] if not ele else [e.data for e in ele[0].childNodes if e.nodeType == e.TEXT_NODE]


def _fields_mapping_xml(doc, mappings_desc):
    item = {}
    for desc in mappings_desc:
        name = desc['name']
        value = ''
        if 'tag' in desc:
            doc_elements = doc.getElementsByTagName(desc['tag'])
            if doc_elements and doc_elements[0].childNodes and \
                doc_elements[0].childNodes[0].nodeType == doc_elements[0].childNodes[0].TEXT_NODE:
                value = doc_elements[0].childNodes[0].data
                if value is None:
                    value = ''
                value = client.replaceHTMLCodes(value)
        if callable(desc.get('map')):
            try:
                value = desc['map'](item, value)
            except Exception:
                if not desc.get('optional'):
                    raise
                value = desc.get('default', '')
        if not value:
            value = desc.get('default', '' if isinstance(value, basestring) else [])
        if value:
            if isinstance(value, basestring):
                try:
                    # (fixme) this should be a decode, not an encode!!!
                    value = value.encode('utf-8', 'ignore')
                except Exception:
                    pass
            item[name] = value
        elif not desc.get('optional'):
            item['language'] = 'en'
            log.debug('Mandatory %s field missing (english language assigned)' % name)
            #raise Exception('mandatory %s field missing'%name)
        elif value == []:
            item[name] = value

    return item
