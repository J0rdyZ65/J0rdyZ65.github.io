# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import time
import urlparse

from g2 import pkg
from g2 import defs

from g2.libraries import cache
from g2.libraries.database import Database

from g2.platforms import log
from g2.platforms import addon

from .trakt import content_ids


class MetaDB(Database):
    name = 'meta'


class Meta(MetaDB):
    def __init__(self):
        super(Meta, self).__init__(
            'meta',
            ('lang', 'imdb', 'tmdb', 'tvdb'),
            'item',
            table_constraints=lambda kcns: ''.join([', UNIQUE(lang, {kcn})'.format(kcn=kcn) for kcn in kcns[1:]]),
            where_clause=self.where_clause,
            expire=defs.METADATA_CACHE_LIFETIME*3600,
            version=1)

    @staticmethod
    def where_clause(kcs):
        if len(kcs) <= 1 or kcs[0][1] != 'lang':
            raise KeyError
        return ' WHERE lang IS ? ' + \
               '   AND ( ' + ' OR '.join(['({kcn} IS ? AND {kcn} IS NOT NULL)'.format(kcn=kc[1]) for kc in kcs[1:]]) + ' )'


def info(package, module):
    if not hasattr(module, 'info'):
        nfo = []
    elif callable(module.info):
        nfo = module.info(package, module)
    else:
        nfo = module.info
    return [dict(nfo)] if isinstance(nfo, dict) else list(nfo)


def resolve(kind=None, **kwargs):
    url = _alldbs_method('resolve', None, kind, **kwargs)
    return url or ''


def movies(url, **kwargs):
    url = resolve(url, **kwargs) or url
    return _alldbs_method('movies', url, url)


def tvshows(url, **kwargs):
    url = resolve(url, **kwargs) or url
    return _alldbs_method('tvshows', url, url)


def meta(items, content='movie', lang=None):
    lang = lang or addon.content_language()

    metadb = Meta()

    started = time.time()
    dbmods = sorted([d for d in pkg.info('dbs').itervalues() if 'meta' in d.get('methods', [])],
                    key=lambda d: d.get('priority', defs.DEFAULT_PACKAGE_PRIORITY))

    witems = []
    scheduled = 0
    for item in items:
        witem = {
            'lang': lang,
            'item': None,
        }
        witem.update({
            k:None if not item.get(k) else item[k] for k in ('imdb', 'tmdb', 'tvdb')
        })

        try:
            witem['item'] = metadb[witem]
            log.debug('{m}.{f}: %s: fetched meta', {k:witem.get(k) for k in ('lang', 'imdb', 'tmdb', 'tvdb')})
        except KeyError:
            url = None
            if content == 'movie':
                if witem['tmdb']:
                    url = resolve('%s_meta{tmdb}{lang}' % content, tmdb=witem['tmdb'], lang=lang)
            else:
                if not witem['tvdb']:
                    content_ids(content, witem)
                if witem['tvdb']:
                    url = resolve('%s_meta{tvdb}{lang}' % content, tvdb=witem['tvdb'], lang=lang)
            if not url and witem['imdb']:
                url = resolve('%s_meta{imdb}{lang}' % content, imdb=witem['imdb'], lang=lang)
            if url:
                log.debug('{m}.{f}: %s: fetching meta at %s', witem, url)
                witem['url'] = url
                witem['content'] = content
                scheduled += 1

        witems.append(witem)

    for dbm in dbmods:
        dbwitems = [w for w in witems if w.get('url') and urlparse.urlparse(w['url']).netloc.lower() in dbm['domains']]
        if dbwitems:
            _db_method(dbm, 'meta', dbwitems)

    completed = 0
    for item, witem in zip(items, witems):
        if not witem['item']:
            continue
        if 'url' in witem:
            log.debug('{m}.{f}: %s: saving meta', {k:witem.get(k) for k in ('lang', 'imdb', 'tmdb', 'tvdb')})
            metadb[witem] = witem['item']
            completed += 1

        try:
            votes = int(item['votes'])
        except Exception:
            votes = 0
        try:
            if int(witem['item']['votes']) <= votes:
                raise Exception
            dont_update_rating = []
        except Exception:
            dont_update_rating = ('rating', 'votes', 'rating_source')

        item.update({k:v for k, v in witem['item'].iteritems() if v and k not in dont_update_rating})

    log.debug('{m}.{f}: %d submitted, %d scheduled, %d completed in %.2f seconds',
              len(items), scheduled, completed, time.time()-started)


def persons(url, **kwargs):
    url = resolve(url, **kwargs) or url
    return _alldbs_method('persons', url, url)


def genres(content='movie'):
    url = resolve('%s_genres{}' % content)
    return _alldbs_method('genres', url, url) or []


def certifications(country='US'):
    url = resolve('certifications{}')
    return _alldbs_method('certifications', url, url, country)


def watched(content, meta_, seen=None):
    if seen is None:
        seen = set()
    _alldbs_method('watched', None, content, meta_, seen)
    return seen


def _alldbs_method(method, url, urlarg, *args, **kwargs):
    def kwargs_get_n_del(kwarg, default=None):
        if kwarg not in kwargs:
            return default
        value = kwargs[kwarg]
        del kwargs[kwarg]
        return value

    netloc = urlparse.urlparse(url).netloc.lower() if url else None
    dbmods = sorted([d for d in pkg.info('dbs').itervalues()
                     if method in d.get('methods', []) and (not netloc or netloc in d['domains'])],
                    key=lambda d: d.get('priority', defs.DEFAULT_PACKAGE_PRIORITY))
    expire = 0 if '|' not in urlarg else int(urlarg.split('|')[1]) * 60
    dbsopt_provider = kwargs_get_n_del('dbsopt_provider')
    for dbm in dbmods:
        if not expire:
            result = _db_method(dbm, method, urlarg, *args, **kwargs)
        else:
            result = cache.get(_db_method, dbm, method, urlarg, *args, cacheopt_expire=expire, **kwargs)
        if result is not None:
            return result if not dbsopt_provider else dbm['name']

    return None


def _db_method(dbm, method, *args, **kwargs):
    result = None
    try:
        with dbm.context() as modules:
            result = getattr(modules[0], method)(*args, **kwargs)
    except Exception as ex:
        log.debug('{m}.{f}: %s.%s: %s', dbm, method, repr(ex))

    return result
