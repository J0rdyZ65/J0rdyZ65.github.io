# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import hashlib
import inspect

from g2.libraries import log
from g2.libraries import database


_CACHE_DB_NAME = 'cache'
_CACHE_DICTS = {}


def get(func, *args, **kwargs):
    def kwargs_get_n_del(kwarg, default=None):
        if kwarg not in kwargs:
            return default
        value = kwargs[kwarg]
        del kwargs[kwarg]
        return value

    info = kwargs_get_n_del('cacheopt_info', {})
    table = kwargs_get_n_del('cacheopt_table', 'rel_list')
    expire = kwargs_get_n_del('cacheopt_expire', 0) * 60
    delete_if_none = kwargs_get_n_del('cacheopt_delete_if_none', False)

    if table not in _CACHE_DICTS:
        _CACHE_DICTS[table] = database.DictDatabase(_CACHE_DB_NAME, table, 'funcall', 'result', timestamp=True)
    cache = _CACHE_DICTS[table]
    cache.expire = expire

    try:
        funcall = _funcall(func, args, kwargs)
        res = cache[funcall]
        info['cached'] = True
        log.debug('{m}.{f}: %s(%s, %s): retrieved cached entry: %.80s', _obj2str(func), args, kwargs, res)
        return res
    except KeyError:
        pass

    try:
        res = func(*args, **kwargs)
    except Exception as ex:
        log.debug('{m}.{f}: %s(%s, %s): refreshing cache entry: %s', _obj2str(func), args, kwargs, repr(ex), trace=True)
        raise

    if res is None and delete_if_none:
        del cache[funcall]
        log.debug('{m}.{f}: %s(%s, %s): deleted cache entry', _obj2str(func), args, kwargs)
    else:
        cache[funcall] = res
        log.debug('{m}.{f}: %s(%s, %s): refreshed cache entry: %.80s', _obj2str(func), args, kwargs, res)

    return res


def clear():
    database.remove(_CACHE_DB_NAME)


def _funcall(func, args, kwargs):
    funcall_key = ', '.join([str(func), str(args), str(kwargs)])
    try:
        return _funcall.cache[funcall_key]
    except AttributeError:
        _funcall.cache = {}
    except KeyError:
        pass
    args_hash = hashlib.md5()
    for arg in args:
        args_hash.update(_obj2str(arg))
    for key, arg in kwargs:
        args_hash.update(key + '=' + _obj2str(arg))
    _funcall.cache[funcall_key] = _obj2str(func) + '.' + str(args_hash.hexdigest())
    return _funcall.cache[funcall_key]


def _obj2str(arg):
    if not callable(arg):
        return str(arg)
    try:
        return _obj2str.cache[arg]
    except AttributeError:
        _obj2str.cache = {}
    except KeyError:
        pass
    _obj2str.cache[arg] = [m for m in inspect.getmembers(arg) if m[0] == 'func_name'][0][1]
    return _obj2str.cache[arg]
