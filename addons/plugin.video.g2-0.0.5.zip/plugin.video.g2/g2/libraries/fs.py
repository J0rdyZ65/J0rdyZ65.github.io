# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import errno

import xbmc
import xbmcvfs


translatePath = xbmc.translatePath
Stat = xbmcvfs.Stat
makeDir = xbmcvfs.mkdirs
listDir = xbmcvfs.listdir
removeDir = xbmcvfs.rmdir
removeFile = xbmcvfs.delete
exists = os.path.exists
def existsDir(dir):
    return exists(os.path.join(dir, ''))
copyFile = xbmcvfs.copy
renameFile = xbmcvfs.rename


class File:
    def __init__(self, filepath, mode='r', ignore_exc=True):
        self.filepath = filepath
        self.mode = mode
        self.ignore_exc = ignore_exc
        self.fil = None

    def __enter__(self):
        try:
            # Not strictly required but this check avoids Kodi to spit out
            # an error message on behalf of the xbmcvfs.File builtin
            if 'r' in self.mode and not exists(self.filepath):
                raise OSError(errno.ENOENT, os.strerror(errno.ENOENT), self.filepath)
            self.fil = xbmcvfs.File(self.filepath, self.mode)
        except Exception:
            if not self.ignore_exc:
                raise
        return self.fil

    def __exit__(self, exc_type, exc_value, traceback):
        if self.fil:
            self.fil.close()
        return self.ignore_exc or not exc_value
