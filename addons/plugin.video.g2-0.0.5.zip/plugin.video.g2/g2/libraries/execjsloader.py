# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2017-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from g2.platforms import log
from g2.platforms import addon

try:
    # Try with the local Node.js first
    import execjs
except ImportError as ex:
    try:
        # Let's see if a remote Node.js can be reached
        __nodejs = addon.setting('nodejs')
        if not __nodejs:
            raise ImportError('missing nodejs setting')

        import rpyc
        __conn = rpyc.utils.factory.ssl_connect(__nodejs.split(':')[0], port=__nodejs.split(':')[1])
        if __conn:
            log.notice('{m}: connected to remote Node.js on %s', __nodejs)

        # Monkey patching the sys.modules
        import new
        import sys
        __execjs = new.module('execjs')
        __execjs.__dict__['get'] = lambda node: __conn.root.get(node)
        sys.modules['execjs'] = __execjs
    except Exception as ex:
        log.debug('{m}: rpyc execjs: %s', repr(ex))
        raise
