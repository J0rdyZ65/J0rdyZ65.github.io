# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2018 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import re
import json
import urllib

import xbmc

from g2 import dbs

from g2.libraries import fs
from g2.libraries import log
from g2.libraries import addon
from g2.libraries import portalocker


_NFO_URLS = {
    'movie': (
        'https://www.themoviedb.org/movie/{tmdb}',
        'http://www.imdb.com/title/{imdb}/',
    ),
    'tvshow': (
        'http://thetvdb.com/?tab=series&id={tvdb}',
        'http://www.imdb.com/title/{imdb}/',
    ),
}


def add(content, title, meta):
    if content == 'movie':
        return _add_movie(content, title, meta)
    if content == 'tvshow':
        return _add_tvshow(content, title, meta)

    return 0


def update(content, title=None, meta=None):
    if content == 'tvshows':
        return _update_tvshow(title, meta)

    return 0


def scan():
    while xbmc.getCondVisibility('Library.IsScanningVideo'):
        xbmc.sleep(1000)
    xbmc.executebuiltin('UpdateLibrary(video)')


def _update_tvshow(title=None, meta=None):
    folder_path = addon.setting('videolibrary.tvshows')
    if not folder_path:
        return 0

    total_eps_added = 0
    for tvshow_dir in [_name_format(('{title_} ({year})',), title_=title, meta=meta).encode('utf-8')] if title else \
                      fs.listDir(folder_path)[0]:
        eps_added = _add_episodes(os.path.join(folder_path, tvshow_dir.decode('utf-8')), title, meta)
        total_eps_added += eps_added
        if eps_added > 0:
            log.notice('{m}.update: tvshow "%s": %s new episode(s) added', tvshow_dir, eps_added)

    return total_eps_added


def _add_movie(content, title, meta):
    folder_path = addon.setting('videolibrary.movies')
    if not folder_path:
        return 0

    movie_dir = _name_format(('{title_} ({year})',), title_=title, meta=meta)
    movie_path = os.path.join(folder_path, movie_dir) if 'year' not in meta else \
                 os.path.join(folder_path, meta['year'], movie_dir)
    fs.makeDir(fs.makeLegalFilename(movie_path))
    _create_strm(os.path.join(movie_path, title + '.strm'), content, meta)
    _create_nfo(os.path.join(movie_path, title + '.nfo'), content, meta)

    return 1


def _add_tvshow(content, tvshowtitle, meta):
    folder_path = addon.setting('videolibrary.tvshows')
    if not folder_path:
        return 0

    tvshow_dir = _name_format(('{title_} ({year})',), title_=tvshowtitle, meta=meta)
    tvshow_path = os.path.join(folder_path, tvshow_dir)
    fs.makeDir(fs.makeLegalFilename(tvshow_path))
    _create_nfo(os.path.join(tvshow_path, 'tvshow.nfo'), content, meta)

    return 1


def _add_episodes(tvshow_path, title=None, meta=None):
    eps_added = 0
    # (fixme) When settings.xml is actually created?
    # (fixme) handle portalocker execption if already blocked and notify the caller
    with portalocker.Lock(os.path.join(addon.PROFILE_PATH, 'settings.xml'), 'r'):
        if not meta:
            with fs.File(os.path.join(tvshow_path, 'tvshow.nfo'), ignore_exc=False) as fil:
                meta = _scan_nfo('tvshow', fil.read())

        item = {
            'tvdb': meta.get('tvdb'),
            'imdb': meta.get('imdb'),
        }
        dbs.meta([item], content='tvshow_seasons')
        if not title:
            # (fixme) this  has to be fixed in tvdb!!!
            title = item['title'].decode('utf-8')

        db_eps = {sn:sorted([int(e.get('episode', '0')) for e in item.get('episodes', [])
                             if e.get('season') == sn])
                  for sn in [s['season'] for s in item.get('seasons', []) if s.get('season')]}

        library_eps = _fetch_local_content('episodes', item)
        eps_added = sum([
            _add_episode(tvshow_path, title, ep, db_eps.get(ep.get('season'), []))
            for ep in item.get('episodes', []) if (int(ep.get('season')), int(ep.get('episode'))) not in library_eps])

    return eps_added


def _add_episode(tvshow_path, tvshowtitle, meta, season_eps):
    if len(season_eps) >= 2:
        episode_dirpath = os.path.join(tvshow_path,
                                       u'{tvshowtitle} S{season:02d}e{first_ep:02d}-{last_ep:02d}'.format(
                                           tvshowtitle=tvshowtitle,
                                           season=int(meta['season']),
                                           first_ep=int(season_eps[0]),
                                           last_ep=int(season_eps[-1])))
    else:
        episode_dirpath = os.path.join(tvshow_path,
                                       u'{tvshowtitle} S{season:02d}e{episode:02d}'.format(
                                           tvshowtitle=tvshowtitle,
                                           season=int(meta['season']),
                                           episode=int(meta['episode'])))
    episode_basename = os.path.join(episode_dirpath,
                                    u'{tvshowtitle} - {season}x{episode:02d} - {title}'.format(
                                        tvshowtitle=tvshowtitle,
                                        season=meta['season'],
                                        episode=int(meta['episode']),
                                        title=meta['title'].decode('utf-8')))
    fs.makeDir(fs.makeLegalFilename(episode_dirpath))
    _create_strm(episode_basename + '.strm', 'episode', meta, ('tvshowtitle', 'season', 'episode'))

    return 1


def _name_format(fmts, title_, meta):
    for fmt in fmts:
        try:
            return fmt.format(title_=title_, **meta)
        except Exception:
            pass
    return title_


def _create_strm(path, content, meta, tags=()):
    meta = {tag:meta[tag] for tag in ('title', 'year', 'imdb', 'tmdb', 'poster') + tags if tag in meta}
    strm_content = addon.itemaction('sources.dialog',
                                    name=urllib.quote_plus(meta['title']),
                                    content=content,
                                    meta=urllib.quote_plus(json.dumps(meta)))
    with fs.File(fs.makeLegalFilename(path), 'w') as fil:
        fil.write(strm_content.encode('utf-8') + '\n')


def _create_nfo(path, content, meta):
    for url in _NFO_URLS.get(content, ()):
        try:
            nfo_content = url.format(**meta)
            with fs.File(fs.makeLegalFilename(path), 'w') as fil:
                fil.write(nfo_content + '\n')
            break
        except Exception:
            pass


def _scan_nfo(content, nfo):
    meta = {}
    for url in _NFO_URLS.get(content, ()):
        try:
            placeholders = []
            def scan_placeholder(match):
                placeholders.append(match.group(1))
                return '(.*)'

            pat = re.sub(r'\\{([a-zA-Z_]*)\\}', scan_placeholder, re.escape(url))
            match = re.search(pat, nfo)
            if match:
                for value in match.groups():
                    meta.update({placeholders.pop(0): value})
        except Exception:
            pass

    return meta


_JSON_QUERIES = {
    'movies': '{{"jsonrpc": "2.0", \
        "id": "libMovies", \
        "method": "VideoLibrary.GetMovies", \
        "params": {{ \
            "sort": {{"order": "ascending", "method": "title"}}, \
            "filter": {{"operator": "is", "field": "title", "value": "{title}"}}, \
            "properties": ["file", "year"] \
        }} \
    }}',
    'tvshows': '{{"jsonrpc": "2.0", \
        "id": "libTVShows", \
        "method": "VideoLibrary.GetTVShows", \
        "params": {{ \
            "sort": {{"order": "ascending", "method": "title"}}, \
            "filter": {{"operator": "is", "field": "title", "value": "{title}"}}, \
            "properties": ["year"] \
        }} \
    }}',
    'episodes': '{{"jsonrpc": "2.0", \
        "id": "libEpisodes", \
        "method": "VideoLibrary.GetEpisodes", \
        "params": {{ \
            "sort": {{"order": "ascending", "method": "title"}}, \
            "tvshowid": {tvshowid}, \
            "properties": ["file", "season", "episode"] \
        }} \
    }}',
}


def _fetch_local_content(content, meta):
    try:
        year = int(meta['year'])
    except Exception:
        year = 0

    try:
        if content == 'movie':
            query = _JSON_QUERIES['movies'].format(**meta)
            res = addon.jsonRPC(query)['result']['movies']
            return [i['file'] for i in res if not year or any(y == i.get('year') for y in range(year-1, year+2))]

        if content == 'episodes':
            query = _JSON_QUERIES['tvshows'].format(**meta)
            res = addon.jsonRPC(query)['result']['tvshows']
            tvshowid = [i['tvshowid'] for i in res if not year or any(y == i.get('year') for y in range(year-1, year+2))][0]
            query = _JSON_QUERIES['episodes'].format(tvshowid=tvshowid, **meta)
            res = addon.jsonRPC(query)['result']['episodes']
            return [(i['season'], i['episode']) for i in res]

    except Exception as ex:
        log.debug('{m}.{f}: %s "%s": %s', content, meta.get('title'), repr(ex))

    return []
