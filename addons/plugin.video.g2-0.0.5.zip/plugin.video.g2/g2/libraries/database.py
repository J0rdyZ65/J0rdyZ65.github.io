# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import os
import ast
import sys
import time
import errno
from sqlite3 import dbapi2 as database
from collections import OrderedDict

try:
    from g2.platforms import addon # py2
except Exception:
    pass

rfc = str
if sys.version_info.major == 2:
    str = unicode


def unzip_0th(lsts):
    return next(iter(zip(*lsts)))


TIMESTAMP_COLUMN_NAME = 'timestamp'

_DEFAULT_DB_TIMEOUT = 10


class Database(object):
    """Database class abstract a sqlite table as a mapping"""

    sql_cmds_templates = {
        'create': 'CREATE TABLE IF NOT EXISTS {table} ({columns_def}{table_constraints})',
        'replace': 'REPLACE INTO {table} ({columns}) VALUES ({values})',
        'select': 'SELECT {{select_columns}} FROM {table}',
        'delete': 'DELETE FROM {table}',
    }
    sql_cmds_default_params = {
        'table_constraints': lambda kcns: ', UNIQUE(%s)' % (', '.join(list(kcns))),
        'where_clause': lambda kcs: ' WHERE ' + ' AND '.join([
            '{kcn} {kop} ?'.format(kcn=kc[1], kop='IS' if kc[0] is None else '=' if kc[2] else '!=') for kc in kcs
        ]),
        'order_clause': None,
    }

    def __init__(self, name, table, key_columns=None, value_columns=None, **kwargs):
        def columns_spec(columns, default):
            if columns is None:
                return [(default, 'TEXT', None)]
            if isinstance(columns, str):
                return [(columns, 'TEXT', None)]
            if isinstance(columns, (list, tuple)):
                return [(c, 'TEXT', None) if isinstance(c, str) else
                        (c[0], c[1] if len(c) > 1 else 'TEXT', c[2] if len(c) > 2 else None)
                        for c in columns if c and isinstance(c, (str, list, tuple))]
            raise NotImplementedError

        self.key_columns = columns_spec(key_columns, 'key')
        self.value_columns = columns_spec(value_columns, 'value')
        self.sql_cmd_params = {p:kwargs.get(p, self.sql_cmds_default_params[p]) for p in self.sql_cmds_default_params}
        self.expire = kwargs.get('expire', 0)

        self.columns = self.key_columns + self.value_columns + \
                       ([(TIMESTAMP_COLUMN_NAME, 'INTEGER', 0)] if kwargs.get('timestamp', False) or self.expire else [])

        key_columns_names = unzip_0th(self.key_columns)
        columns_def = ', '.join([' '.join(c[0:2]) for c in self.columns])
        columns = ', '.join([c[0] for c in self.columns])
        values = ', '.join(['?' for c in self.columns])
        self.sql_cmds = {}
        for sql_cmd in self.sql_cmds_templates:
            self.sql_cmds[sql_cmd] = self.sql_cmds_templates[sql_cmd].format(
                table=table,
                columns_def=columns_def,
                columns=columns,
                values=values,
                table_constraints=self.sql_cmd_params['table_constraints'](key_columns_names),
            )

        db_dir = kwargs['db_dir'] if 'db_dir' in kwargs else addon.info('profile')
        self.dbcon = database.connect(_database_path(db_dir, name), kwargs.get('timeout', _DEFAULT_DB_TIMEOUT))
        self.dbcon.row_factory = database.Row
        with self.dbcon as dbcon:
            dbcon.execute(self.sql_cmds['create'])

    def __contains__(self, key):
        return bool(self.get_row(key))

    def __getitem__(self, key):
        row = self.get_row(key)
        if not row:
            raise KeyError
        return self.row_value(row)

    def __setitem__(self, key, value):
        key_list = self.key_list(key, listallkeys=True)
        with self.dbcon as dbcon:
            dbcon.execute(self.sql_cmds['replace'],
                          unzip_0th(key_list) + tuple(self.value_list(value)) +
                          ((time.time(),) if TIMESTAMP_COLUMN_NAME in unzip_0th(self.columns) else ()))

    def __delitem__(self, key):
        key_list = self.key_list(key)
        with self.dbcon as dbcon:
            if not key_list:
                dbcon.execute(self.sql_cmds['delete'])
            else:
                dbcon.execute(self.sql_cmds['delete'] + self.sql_cmd_params['where_clause'](key_list), unzip_0th(key_list))

    def __iter__(self):
        return self.iterkeys()

    def __len__(self):
        return self.__call__()

    def __call__(self, *argskey):
        if not argskey:
            dbcur = self.dbcon.execute(self.sql_select(select_columns='COUNT(*)'))
        else:
            key_list = self.key_list(argskey[0])
            dbcur = self.dbcon.execute(self.sql_select(select_columns='COUNT(*)', where_key_list=key_list), unzip_0th(key_list))
        return dbcur.fetchone()[0]

    def clear(self):
        del self[()]

    def get(self, key, default=None):
        try:
            return self[key]
        except KeyError:
            return default

    def iterkeys(self, *argskey):
        return DatabaseIterkeys(self, argskey)

    keys = iterkeys

    def itervalues(self, *argskey):
        return DatabaseItervalues(self, argskey)

    values = itervalues

    def iteritems(self, *argskey):
        return DatabaseIteritems(self, argskey)

    items = iteritems

    def get_row(self, key):
        key_list = self.key_list(key)
        dbcur = self.dbcon.execute(self.sql_select(where_key_list=key_list), unzip_0th(key_list))
        while True:
            row = dbcur.fetchone()
            if not row:
                return None
            if not self.expire or row[rfc(TIMESTAMP_COLUMN_NAME)] + self.expire >= time.time(): # py2: Row factory needs str
                return row

    def row_key(self, row):
        if len(self.key_columns) == 1:
            return row[rfc(self.key_columns[0][0])] # py2: Row factory needs str
        return OrderedDict(((cn, row[rfc(cn)]) for cn, ct, _cd in self.key_columns)) # py2: Row factory needs str

    def row_value(self, row):
        if len(self.value_columns) == 1:
            return self._db2val(row[rfc(self.value_columns[0][0])], self.value_columns[0][1]) # py2: Row factory needs str
        return OrderedDict(((cn, self._db2val(row[rfc(cn)], ct)) for cn, ct, _cd in self.value_columns)) # py2: Row factory...

    def sql_select(self, select_columns='*', where_key_list=None):
        sql_select = self.sql_cmds['select'].format(select_columns=select_columns)
        if where_key_list:
            sql_select += self.sql_cmd_params['where_clause'](where_key_list)
        if callable(self.sql_cmd_params['order_clause']):
            sql_select += self.sql_cmd_params['order_clause'](unzip_0th(self.columns))
        return sql_select

    def key_list(self, key, listallkeys=False):
        if isinstance(key, dict):
            return [(key.get(cn, key.get('~' + cn, cd)), cn, ('~' + cn) not in key)
                    for cn, _ct, cd in self.key_columns if cn in key or ('~' + cn) in key or listallkeys]
        elif isinstance(key, (list, tuple)):
            return [(cv, cn, True) for cv, (cn, _ct, _cd) in zip(key, self.key_columns)] + \
                   ([(cd, cn, True) for cn, _ct, cd in self.key_columns[len(key):]] if listallkeys else [])
        return [(key, self.key_columns[0][0], True)] + \
               ([(cd, cn, True) for cn, _ct, cd in self.key_columns[1:]] if listallkeys else [])

    def value_list(self, value):
        if len(self.value_columns) == 1:
            return [self._val2db(value, self.value_columns[0][1])]
        if isinstance(value, dict):
            return [self._val2db(value.get(cn, cd), ct) for cn, ct, cd in self.value_columns]
        if isinstance(value, (list, tuple)):
            return [self._val2db(cv, ct) for cv, (cn, ct, _cd) in zip(value, self.value_columns)] + \
                   [(cd, ct) for _cn, ct, cd in self.value_columns[len(value):]]
        return [self._val2db(value, self.value_columns[0][1])] + \
               [self._val2db(cd, ct) for _cn, ct, cd in self.value_columns[1:]]

    @staticmethod
    def _val2db(value, dbtype):
        if value is None:
            return None
        dbtype = dbtype.upper()
        if dbtype == 'TEXT':
            return repr(value)
        elif dbtype == 'INTEGER':
            return int(value)
        elif dbtype == 'REAL':
            return float(value)
        raise NotImplementedError

    @staticmethod
    def _db2val(value, dbtype):
        if value is None:
            return None
        dbtype = dbtype.upper()
        if dbtype == 'TEXT':
            return ast.literal_eval(value)
        if dbtype in ('INTEGER', 'REAL'):
            return value
        raise NotImplementedError


class DatabaseIter(object):
    def __init__(self, dbobj, argskey):
        self.dbobj = dbobj
        self.argskey = argskey
        self.dbcur = None

    def __iter__(self):
        return self

    def __next__(self):
        if not self.dbcur:
            if not self.argskey:
                self.dbcur = self.dbobj.dbcon.execute(self.dbobj.sql_select(), ())
            else:
                key_list = self.dbobj.key_list(self.argskey[0])
                self.dbcur = self.dbobj.dbcon.execute(self.dbobj.sql_select(where_key_list=key_list), unzip_0th(key_list))
        row = self.dbcur.fetchone()
        if not row:
            raise StopIteration
        return row

    def next(self):
        return self.__next__()


class DatabaseIterkeys(DatabaseIter):
    def __next__(self):
        return self.dbobj.row_key(super(DatabaseIterkeys, self).__next__())


class DatabaseItervalues(DatabaseIter):
    def __next__(self):
        return self.dbobj.row_value(super(DatabaseItervalues, self).__next__())


class DatabaseIteritems(DatabaseIter):
    def __next__(self):
        row = super(DatabaseIteritems, self).__next__()
        return self.dbobj.row_key(row), self.dbobj.row_value(row)


class SettingsDatabase(Database):
    def __init__(self):
        super(SettingsDatabase, self).__init__('settings', 'settings', 'name', 'value')


def remove(name, db_dir=None):
    try:
        os.remove(_database_path(db_dir or addon.info('profile'), name))
    except OSError as ex:
        if ex.errno != errno.ENOENT:
            raise


def _database_path(db_dir, name):
    return os.path.join(db_dir, name + '.db')
