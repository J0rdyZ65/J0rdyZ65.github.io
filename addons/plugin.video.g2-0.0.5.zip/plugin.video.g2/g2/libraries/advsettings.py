# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import ast

try:
    from collections import OrderedDict
except Exception:
    OrderedDict = dict

from g2.libraries import log

from g2.platforms import addon


def setting(setid, refresh=False):
    value = None if refresh else addon.prop('advsettings', name=setid)
    if not value:
        value = _load_advsettings(setid)
        addon.prop('advsettings', value, name=setid)
    return value


def _load_advsettings(setid):
    setvalue = OrderedDict()
    for setpath in (addon.info('profile'), addon.info('resources')):
        try:
            with open(os.path.join(setpath, 'settings.py')) as fil:
                for section in fil.read().split('[@'):
                    if section.strip():
                        name, literal = section.split(']', 1)
                        name = name.split(':')
                        if name[0].strip().lower() == setid:
                            literal = ast.literal_eval(literal.strip())
                            if isinstance(literal, dict):
                                setvalue.update(literal)
        except IOError:
            pass
        except Exception as ex:
            log.error('{m}: %s', ex)

    return setvalue


def update(setid, setvalue=None, allow_star_name=False):
    def repr_dict(vdict):
        if vdict is None:
            return ''
        vdict_repr = '{\n'
        for key, val in vdict.iteritems():
            vdict_repr += "    '%s': %s,\n" % (key, repr(val))
        vdict_repr += '}\n'
        return vdict_repr

    return update_sections('[@%s] %s' % (setid, repr_dict(setvalue)), allow_star_name=allow_star_name)


def update_sections(settings, allow_star_name=False):
    update_settings = {}
    for frag in settings.split('[@'):
        if frag.strip():
            try:
                setid, literal = frag.split(']', 1)
                if ':' not in setid:
                    raise Exception
                if not allow_star_name and setid.endswith(':*'):
                    raise Exception
                if not setid.endswith(':*') and literal.strip() and not isinstance(ast.literal_eval(literal.strip()), dict):
                    raise Exception
                update_settings[setid] = literal
            except Exception:
                pass

    def updated_value(setid):
        for usetid, usetvalue in update_settings.iteritems():
            if setid == usetid or usetid.endswith(':*') and setid.split(':')[0] == usetid.split(':')[0]:
                update_settings[usetid] = '' if usetid.endswith(':*') else None
                return usetvalue
        return None

    if not update_settings:
        return False

    settings_filename = os.path.join(addon.info('profile'), 'settings.py')
    with open(settings_filename) as fil:
        old_settings = fil.read()

    new_sections = []
    for section in old_settings.split('[@'):
        if not section.strip():
            new_sections.append(section)
            continue
        setid = section.split(']', 1)[0].strip()
        newvalue = updated_value(setid)
        if newvalue is None:
            new_sections.append(section.strip() + '\n\n')
        elif newvalue.strip():
            new_sections.append('%s] %s' % (setid, newvalue.strip()) + '\n\n')

    for setid, literal in update_settings.iteritems():
        if literal and literal.strip():
            if setid.endswith(':*'):
                setid = setid.split(':')[0]
            new_sections.append('%s] %s' % (setid, literal.strip()) + '\n\n')

    new_settings = '[@'.join(new_sections)
    if old_settings == new_settings:
        return False

    with open(settings_filename, 'w') as fil:
        fil.write(new_settings)

    return True
