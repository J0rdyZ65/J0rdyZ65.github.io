# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import os
import re
import ast
from io import open
from collections import OrderedDict

from g2.platforms import addon


def setting(secname, refresh=False, settings_paths=None):
    value = None if refresh else addon.prop('advsettings', name=secname)
    if value is None:
        for path in settings_paths or [addon.info('profile'), addon.info('resources')]:
            try:
                with open(os.path.join(path, 'settings.py'), encoding='utf-8') as fil:
                    sections = fil.read()
            except Exception:
                continue
            for isecname, literal in _iter_sections(sections):
                if literal and isecname.split(':')[0].strip().lower() == secname:
                    if value is None:
                        value = OrderedDict()
                    try:
                        value.update(dict(ast.literal_eval(literal)))
                    except Exception:
                        pass
        if value is not None:
            addon.prop('advsettings', value, name=secname)
    return value


def update(secname, value=None, allow_star_name=False, profile_path=None):
    section = '[@%s]' % secname
    if value is None:
        pass
    elif isinstance(value, dict):
        section += ' {\n'
        if hasattr(value, '__section_doc__'):
            for line in value.__section_doc__.splitlines():
                section += '    # %s\n' % line
        for key, val in value.iteritems():
            section += "    '%s': %s,\n" % (key, repr(val))
        section += '}'
    else:
        raise Exception('value must be a dict (got %s)' % type(value))

    return update_sections(section + '\n', allow_star_name=allow_star_name, profile_path=profile_path)


def update_sections(sections, allow_star_name=False, profile_path=None):
    updated_sections = {}
    for secname, literal in _iter_sections(sections):
        if ':' not in secname:
            raise Exception('%s: not a fully qualified section name' % secname)
        if not allow_star_name and secname.endswith(':*'):
            raise Exception('%s: updating all section instances requires allow_star_name=True' % secname)
        if literal:
            dict(ast.literal_eval(literal))
        updated_sections[secname] = literal

    if not updated_sections:
        return False

    def consume_updated_sections(secname):
        if not secname:
            return None
        for usecname, literal in updated_sections.iteritems():
            if secname == usecname or usecname.endswith(':*') and secname.split(':')[0] == usecname.split(':')[0]:
                updated_sections[usecname] = '' if usecname.endswith(':*') else None
                return literal
        return None

    settings = os.path.join(profile_path or addon.info('profile'), 'settings.py')
    with open(settings, encoding='utf-8') as fil:
        old_sections = fil.read()

    new_sections = []
    for secname, literal in _iter_sections(old_sections, skip_headings=False):
        new_literal = consume_updated_sections(secname)
        if new_literal is None:
            if secname or literal:
                new_sections.append((secname, literal))
        elif new_literal:
            new_sections.append((secname, new_literal))

    for secname, literal in updated_sections.iteritems():
        if literal:
            new_sections.append((secname, literal))

    new_sections = '\n\n'.join([l if not n else ('[@%s] %s' % (n if not n.endswith(':*') else n.split(':')[0], l))
                                for n, l in new_sections]) + '\n'

    if old_sections != new_sections:
        with open(settings, 'w', encoding='utf-8') as fil:
            fil.write(new_sections)

    return True


def _iter_sections(sections, skip_headings=True):
    secname = None
    section = ''
    for line in sections.splitlines():
        match = re.match(r'\s*\[@\s*(\w+?)(:\w+|:\*)?\s*\]', line)
        if not match:
            section += ('\n' if section else '') + line
        else:
            if secname or not skip_headings:
                yield secname, section.strip()
            secname = match.group(1) + (match.group(2) or '')
            section = line[match.end():]

    if secname or not skip_headings:
        yield secname, section.strip()
