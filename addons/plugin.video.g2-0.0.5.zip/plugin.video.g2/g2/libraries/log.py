# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2018 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import re
import sys
import inspect
import traceback
import threading

from g2 import platforms
from g2.platforms import addon

from .addon import advsettings


_ADDON_ID = addon.info('id')
_ADDON_VERSION = addon.info('version')

_SPECIAL_TAGS = [
    'p',    # package name
    'm',    # module name
    'f',    # function name
    't',    # thread start time
    'cf',   # calling module.function
    'v',    # addon version
]

_CONFIG = {}


def debug(msg, *args, **kwargs):
    return _log(msg, platforms.LOGDEBUG, *args, **kwargs)


def notice(msg, *args, **kwargs):
    return _log(msg, platforms.LOGNOTICE, *args, **kwargs)


def error(msg, *args, **kwargs):
    return _log(msg, platforms.LOGERROR, *args, **kwargs)


def perfactive():
    ids = _fetch_ids(1)
    # Log performance related stats for...
    config = (_CONFIG.get(ids['m']+'.'+ids['f']) or
              _CONFIG.get(ids['cf']+'.'+ids['m']+'.'+ids['f']))
    try:
        return 'P' in config
    except Exception:
        return False


def debugactive(ids=None):
    if ids is None:
        ids = {}
    ids.update(_fetch_ids(1 if ids else 3))
    # Debug...
    return (_CONFIG.get(ids['p']) or                    # the entire package
            _CONFIG.get(ids['f']) or                    # a specific function
            _CONFIG.get(ids['p']+'.'+ids['m']) or       # a specific package.module
            _CONFIG.get(ids['m']+'.'+ids['f']) or       # a specific module.function
            _CONFIG.get(ids['cf']+'.'+ids['f']))        # a specific function when called by a specific module.function


def _log(msg, level, *args, **kwargs):
    try:
        thread_id = int(sys.argv[1])
    except Exception:
        thread_id = -1
    debug_opt = kwargs.get('debug')
    trace_opt = kwargs.get('trace')
    try:
        ids = {}
        orig_level = ''
        if level == platforms.LOGDEBUG and (debug_opt or debugactive(ids)):
            level = platforms.LOGNOTICE
            orig_level = 'DEBUG'

        if any('{%s}'%tag in msg for tag in _SPECIAL_TAGS):
            if not ids:
                ids = _fetch_ids()
            for tag in _SPECIAL_TAGS:
                msg = msg.replace('{%s}'%tag, ids.get(tag, '---'))

        if args:
            msg = msg % args
        if isinstance(msg, unicode):
            msg = msg.encode('utf-8') + ' (utf-8)'

        platforms.log('%s[%s%s] %s' % (orig_level, _ADDON_ID, ('' if thread_id < 0 else ':%d'%thread_id), msg), level)
    except Exception:
        try:
            platforms.log('log.%s(%s, %s, %s): %s' % (orig_level.lower(), msg, args, kwargs, traceback.format_exc()),
                          platforms.LOGNOTICE)
        except Exception:
            pass
    if trace_opt:
        try:
            stacktrace = traceback.format_exc()
            if stacktrace and not stacktrace.startswith('None'):
                platforms.log('[%s%s] %s' % (_ADDON_ID, ('' if thread_id < 0 else ':%d'%thread_id), stacktrace), level)
        except Exception:
            pass

    return msg


def _fetch_ids(ids_level=2):
    def module_name(path):
        return os.path.basename(os.path.dirname(path)) if path.endswith('__init__.py') else \
               os.path.splitext(os.path.basename(path))[0]

    ids = {
        'v': _ADDON_VERSION,
    }
    stack = None
    try:
        ids_level += 1
        stack = inspect.stack(0)
        if len(stack) <= ids_level:
            raise Exception()
        module = stack[ids_level][1]
        function = stack[ids_level][3]
        ids.update({
            'p': os.path.basename(os.path.dirname(module)),
            'm': module_name(module),
            'f': function,
        })
        if len(stack) > ids_level+1:
            calling_module = stack[ids_level+1][1]
            calling_function = stack[ids_level+1][3]
            ids.update({
                'cf': '%s.%s'%(module_name(calling_module), calling_function),
            })
    except Exception:
        ids.update({
            'p': '',
            'm': '',
            'f': '',
            'cf': '',
        })
    finally:
        del stack
    try:
        # platforms.log('fetching {t}: %s'%str(threading.current_thread()), platforms.LOGNOTICE)
        ids.update({
            't': re.search(r'\s+started\s+(?:[a-z]+\s+)?([\d]+)', str(threading.current_thread())).group(1),
        })
    except Exception:
        pass

    return ids


try:
    _CONFIG = advsettings('logging', refresh=True)
    if not isinstance(_CONFIG, dict):
        raise Exception('the advanced logging configuration should be a single python dict')
except Exception as ex:
    error('{m}: %s', repr(ex))
