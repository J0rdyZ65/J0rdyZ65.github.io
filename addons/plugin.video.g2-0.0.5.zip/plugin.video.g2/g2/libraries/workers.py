# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import sys

import datetime
import threading
from threading import current_thread, Lock #pylint: disable=W0611
from contextlib import contextmanager


class WouldBlockError(Exception):
    pass


class Thread(threading.Thread):
    def __init__(self, target, *args, **kwargs):
        if 'threadopt_callback' not in kwargs:
            callback = (None, (), {})
        else:
            callback = kwargs['threadopt_callback']
            del kwargs['threadopt_callback']
        if 'name' not in kwargs:
            name = None
        else:
            name = kwargs['name']
            del kwargs['name']
        if target:
            super(Thread, self).__init__(name=name, target=target, args=args, kwargs=kwargs)
        self.started = None
        self.stopped = None
        self.result = None
        self.exc = None
        self.exc_traceback = None
        self.die = False
        self._callback = callback
        if not self.is_alive():
            self.daemon = True # Don't block kodi in case a thread runaways

    def init(self):
        self.__init__(None)

    def start(self):
        super(Thread, self).start()
        return self

    def run(self):
        try:
            self.started = datetime.datetime.now()
            if self.__target:
                self.result = self.__target(*self.__args, **self.__kwargs)
        except Exception as ex:
            self.exc = ex
            self.exc_traceback = sys.exc_traceback
        finally:
            self.stopped = datetime.datetime.now()
            # Avoid a refcycle if the thread is running a function with
            # an argument that has a member that points to the thread.
            del self.__target, self.__args, self.__kwargs
        try:
            if callable(self._callback[0]):
                self._callback[0](*self._callback[1], **self._callback[2]) #pylint: disable=E1102
        except Exception:
            pass

    def elapsed(self):
        if not self.started:
            return None
        elapsed = (self.stopped if self.stopped else datetime.datetime.now()) - self.started
        return elapsed.days*86400 + elapsed.seconds + float(elapsed.microseconds)/1000000


def promote(thread):
    if not isinstance(thread, threading.Thread):
        return False
    if not isinstance(thread, Thread):
        thread.__class__ = Thread
        thread.init()
        if thread.is_alive():
            thread.started = datetime.datetime.now()
    return True


@contextmanager
def non_blocking(lock):
    if not lock.acquire(False):
        raise WouldBlockError
    try:
        yield lock
    finally:
        lock.release()
