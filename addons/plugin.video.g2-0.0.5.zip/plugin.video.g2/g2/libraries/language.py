# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


from g2 import platforms
from g2.platforms import language

from . import log


_PLATFORM_LANGUAGE = platforms.info('language')


def xgettext(msgid):
    return msgid


def _(msgid, *args, **kwargs):
    lmsgid = language.lmsg(msgid, 'str')
    try:
        return lmsgid.format(*args, **kwargs)
    except Exception as ex:
        log.notice('{m}.{f}: %s: %s', lmsgid, repr(ex))
        try:
            return str(msgid).format(*args, **kwargs)
        except Exception as ex:
            log.notice('{m}.{f}: %s: %s', msgid, repr(ex))
            return str(msgid) + '...'


def msgcode(msgid):
    return language.lmsg(msgid, 'code')


_LANGUAGES = {
    'en': {
        'en': 'English',
        'it': 'Inglese',
    },
    'it': {
        'en': 'Italian',
        'it': 'Italiano',
    }
}

def name(lang, fmt=_PLATFORM_LANGUAGE):
    return _LANGUAGES.get(lang, {}).get(fmt, lang)
