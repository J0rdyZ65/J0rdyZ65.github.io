# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import os
import re

import xbmc

from . import fs
from . import log
from . import addon


def _read_msgs():
    msgs = {}
    pofile = os.path.join(addon.info('path'), 'resources', 'language', 'English', 'strings.po')
    with fs.File(pofile, 'r') as pof:
        msgctxt = None
        for line in pof.read().splitlines():
            try:
                # msgctxt "#30006"
                msgctxt = int(re.match(r'msgctxt\s*"#(\d+)"', line).group(1))
                continue
            except Exception:
                pass
            try:
                # msgid "Latest Episodes"
                msgid = re.match(r'msgid\s*"([^"]+)"', line).group(1)
                if not msgid:
                    raise
                if msgctxt:
                    if msgid not in msgs:
                        msgs[msgid] = []
                    msgs[msgid].append(msgctxt)
                continue
            except Exception:
                pass
            if re.match(r'\s*$', line):
                msgctxt = None

    for msgid, codes in msgs.iteritems():
        if len(codes) > 1:
            log.notice('{m}: "%s": multiple codes: %s', msgid, ', '.join([str(x) for x in codes]))
        else:
            log.debug('{m}.{f}: %s: %s', msgid, codes)

    log.debug('{m}.{f}: %d language strings found', len(msgs))

    addon.prop('language', msgs, name='msgs')

    return msgs


def xgettext(msgid):
    return msgid


def _(msgid, *args, **kwargs):
    mcode = msgcode(msgid)
    lmsgid = mcode if isinstance(mcode, basestring) else addon.localizedString(mcode)
    try:
        return lmsgid.encode('utf-8').format(*args, **kwargs)
    except Exception as ex:
        log.notice('{m}.{f}: %s: %s', lmsgid, repr(ex))
        try:
            return str(msgid).encode('utf-8').format(*args, **kwargs)
        except Exception as ex:
            log.notice('{m}.{f}: %s: %s', msgid, repr(ex))
            return str(msgid).encode('utf-8') + '...'


def msgcode(msgid):
    if not hasattr(msgcode, 'msgs'):
        msgcode.msgs = addon.prop('language', name='msgs')

    if not msgcode.msgs:
        msgcode.msgs = _read_msgs()

    log.debug('{m}.{f}: %s: %s', msgid, msgcode.msgs.get(msgid, [msgid])[0])

    return msgcode.msgs.get(msgid, [msgid])[0]


def name(language):
    return xbmc.convertLanguage(language, xbmc.ENGLISH_NAME)
