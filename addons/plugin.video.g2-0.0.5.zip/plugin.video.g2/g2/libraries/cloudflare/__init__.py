# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2017-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import sys
import abc
import new
import datetime
import urlparse

import requests

from g2.platforms import log
from g2.platforms import addon


class CloudflareBase(object):
    __metaclass__ = abc.ABCMeta

    @property
    @abc.abstractmethod
    def priority(self):
        raise NotImplementedError

    @abc.abstractmethod
    def check(self, res):
        raise NotImplementedError

    @abc.abstractmethod
    def bypass(self, res, user_agent, cookiesjar):
        raise NotImplementedError


class CloudflarePelis(CloudflareBase):
    priority = 1

    def __init__(self, res):
        self.sysmodulespatch = False

        if 'platformcode' not in sys.modules:
            # Monkey patching the sys.modules
            class Logger(object):
                def debug(self, msg, *args, **kwargs):
                    log.debug(msg, *args, **kwargs)

            platformcode = new.module(str('platformcode'))
            platformcode.__dict__['logger'] = Logger()
            sys.modules['platformcode'] = platformcode
            self.sysmodulespatch = True

        from . import pelis
        response = {
            'url': res.url,
            'data': res.content,
            'headers': res.headers,
        }
        self.cloudflare = pelis.Cloudflare(response)

    def __del__(self):
        if self.sysmodulespatch:
            del sys.modules['platformcode']

    def check(self, res):
        return self.cloudflare.is_cloudflare

    def bypass(self, res, user_agent, cookiesjar):
        submit_url = self.cloudflare.get_url()
        parsed_url = urlparse.urlparse(res.url)
        method = res.request.method
        with requests.Session() as ses:
            ses.headers['User-Agent'] = user_agent
            ses.cookies = cookiesjar
            redirect = ses.request(method, submit_url, headers={'Referer': res.url}, allow_redirects=False)
            redirect_location = urlparse.urlparse(redirect.headers['Location'])
            log.debug('{m}.{f}: redirect_location=%s', redirect_location)
            if not redirect_location.netloc:
                redirect_url = "%s://%s%s" % (parsed_url.scheme, parsed_url.netloc, redirect_location.path)
                return ses.request(method, redirect_url)
            return ses.request(method, redirect.headers['Location'])


class CloudflareCfscrape(CloudflareBase):
    priority = 2

    def __init__(self, _res):
        # First try with the installed execjs module
        try:
            import execjs
            log.debug('{m}: execjs module loaded')
            return
        except ImportError:
            pass

        # Let's see if a remote Node.js can be reached
        nodejs = addon.setting('nodejs')
        if not nodejs:
            raise ImportError('missing nodejs setting')

        import rpyc
        conn = rpyc.utils.factory.ssl_connect(nodejs.split(':')[0], port=str(nodejs.split(':')[1]))
        if conn:
            log.notice('{m}: connected to remote Node.js on %s', nodejs)

        # Monkey patching the sys.modules
        execjs = new.module(str('execjs'))
        execjs.__dict__['get'] = conn.root.get
        sys.modules['execjs'] = execjs

    def check(self, res):
        from . import cfscrape
        cfs = cfscrape.create_scraper()
        return cfs.is_cloudflare_challenge(res)

    def bypass(self, res, user_agent, cookiesjar):
        from . import cfscrape
        cfs = cfscrape.create_scraper()
        cfs.headers['User-Agent'] = user_agent
        cfs.cookies = cookiesjar
        res = cfs.solve_cf_challenge(res)
        return res


def bypass(res, user_agent, cookiesjar):
    """Return the requests response object of the target page by applying the available bypass mechanisms.

    If none of the methods detects the cloudflare protection, the original response is returned.
    """

    for cfbypass_class in sorted(CloudflareBase.__subclasses__(), key=lambda c: c.priority):
        try:
            started = datetime.datetime.now()
            cfbypass = cfbypass_class(res)
            if not cfbypass.check(res):
                log.debug('{m}.{f}: %s: no cloudflare protection detected for %s', cfbypass_class.__name__, res.request.url)
            else:
                log.debug('{m}.{f}: %s: cloudflare protection detected for %s', cfbypass_class.__name__, res.request.url)
                res = cfbypass.bypass(res, user_agent, cookiesjar)
                elapsed = datetime.datetime.now() - started
                log.notice('{m}: %s: cloudflare bypass in %.1d secs for %s',
                           cfbypass_class.__name__, elapsed.seconds+elapsed.microseconds/1000000., res.request.url)
        except Exception as ex:
            log.debug('{m}.{f}: %s: %s', cfbypass_class.__name__, repr(ex), trace=True)

    return res
