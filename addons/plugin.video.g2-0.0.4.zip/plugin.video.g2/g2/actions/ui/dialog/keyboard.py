# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import xbmc
import xbmcgui

from g2.libraries import log
from g2.libraries import addon
from g2.libraries.language import _
from g2.libraries.database import DictDatabase

from . import EventHandler


# NOTE: to increase beyond 12, you need either to increase the window height or implement a scrollbar
_MAX_HISTORY_ITEMS = 12


class InputHistory(DictDatabase):
    def __init__(self):
        DictDatabase.__init__(self, 'settings', 'input_history', 'input_type', 'history')


class KeyboardDialog(xbmcgui.WindowXMLDialog):
    evh = EventHandler()
    heading_id = 101
    edit_id = 201
    history_list_id = 401
    history_button_id = 402

    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback, heading=None, history=None, default=None):
        self.default = default
        self.heading = heading or addon.info('id')
        self.history = history
        self.historydb = InputHistory()
        self.history_ctls = {}
        self.value = None

    def onInit(self):
        heading_ctl = self.getControl(self.heading_id)
        edit_ctl = self.getControl(self.edit_id)
        history_list_ctl = self.getControl(self.history_list_id)

        # NOTE (for the skinner): I know, this is violating the skinning paradigm where look&feel aspects
        # shouldn't be hardcoded; however, until someone come up with a good WYSIWYG Kodi Skin Editor,
        # I have no time/patience to edit all those XML details... and, btw, 3 is a magic number here!!! ;)
        history_button_ctl = self.getControl(self.history_button_id)
        origin_x, origin_y = history_list_ctl.getPosition()
        button_width = history_button_ctl.getWidth()
        button_height = history_button_ctl.getHeight()
        button_font = history_button_ctl.getLabel()
        history = self.historydb.get(self.history, [])
        len3_history = len(history)
        if len3_history % 3:
            len3_history += 3 - len3_history%3
        history_ctls_by_idx = []
        for idx in range(0, len3_history):
            try:
                hist = history.pop(0)
            except Exception:
                hist = ''
            hist_ctl = xbmcgui.ControlButton(origin_x+(idx%3)*(button_width+10), origin_y+(idx/3)*button_height,
                                             button_width, button_height, hist, font=button_font, alignment=6)
            self.addControl(hist_ctl)
            history_ctls_by_idx.append(hist_ctl)
            self.history_ctls[hist_ctl.getId()] = hist_ctl
            log.debug('{m}.{f}: added history button for "%s" at %d:%d %dx%d using font "%s" as controlID %d',
                      hist, origin_x+(idx%3)*(button_width+10), origin_y+(idx/3)*button_height,
                      button_width, button_height, button_font, hist_ctl.getId())

        # @evh.click(self.history_ctls.keys()) # run time annotation
        self.evh.click(self.history_ctls.keys())(KeyboardDialog._edit_history)

        for idx, hist_ctl in enumerate(history_ctls_by_idx):
            if idx == 0:
                edit_ctl.controlDown(hist_ctl)
            hist_ctl.controlUp(edit_ctl if idx < 3 else history_ctls_by_idx[idx-3])
            hist_ctl.controlDown(edit_ctl if idx >= len3_history-3 else history_ctls_by_idx[idx+3])
            hist_ctl.controlLeft(history_ctls_by_idx[max(0, idx-1)])
            hist_ctl.controlRight(history_ctls_by_idx[min(len3_history-1, idx+1)])

        heading_ctl.setLabel(self.heading)
        edit_ctl.setLabel(self.default or _('Click here to enter a new term'))
        self.setFocus(edit_ctl)

    def onClick(self, control_id):
        self.evh.onclick(control_id, self)

    @evh.click(edit_id)
    def _edit_default(self, control_id):
        self._edit(self.default)

    # @evh.click(self.history_ctls.keys()) # run time annotation
    def _edit_history(self, control_id):
        self._edit(self.history_ctls[control_id].getLabel())

    def _edit(self, value):
        keyb = xbmc.Keyboard(value or '', self.heading)
        keyb.doModal()
        if keyb.isConfirmed():
            value = keyb.getText()
            if value:
                self.value = value
                history = [value] + [h for h in self.historydb.get(self.history, []) if h != value]
                self.historydb[self.history] = history[:_MAX_HISTORY_ITEMS]
                self.close()

    def isConfirmed(self):
        return self.value is not None

    def getText(self):
        return self.value
