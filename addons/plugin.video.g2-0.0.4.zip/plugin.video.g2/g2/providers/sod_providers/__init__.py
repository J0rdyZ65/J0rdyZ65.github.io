# -*- coding: utf-8 -*-

"""Streamondemand package descriptor and API adapter"""


kind = 'providers'

addons = ['plugin.video.streamondemand', 'script.module.unidecode']

imports = ['channels']


import os
import re
import urllib

from g2.libraries import log
from g2.providers.api import ProviderBase


class SODProviders(ProviderBase):
    """Streamondemand channels API adapter"""

    excluded_channels = [
        'corsaronero',      # torrent only
        'mondolunatico',    # sometimes it fires up a captcha dialog
    ]

    channels_options = {
        'cineblog01': {
            'remove_chars': ':',                # cb01 doesn't like the ':' in the search title
            'ignore_info_tags': ['Streaming HD:', 'Streaming:'],
        },
    }

    def _channel_option(self, channel, option, default=None):
        return self.channels_options.get(channel, {}).get(option, default)

    @property
    def info(self):
        if not self.module:
            return {}

        from core import logger # kodi addon # pylint: disable=import-error
        logger.log_enable(False)

        module_path = os.path.splitext(self.module.__dict__['__file__'])[0]
        module_name = os.path.basename(module_path).lower()
        if module_name in self.excluded_channels or not hasattr(self.module, 'search'):
            return []

        from g2.libraries import client
        try:
            content = []
            with open(module_path+'.xml') as fil:
                xml = fil.read()
            active = client.parseDOM(xml, 'active')
            if not active or active[0].lower() != 'true':
                raise Exception
            for setting in client.parseDOM(xml, 'settings'):
                active = client.parseDOM(setting, 'id')
                if active and active[0].lower() == 'include_in_global_search':
                    break
            else:
                raise Exception
            for categories in client.parseDOM(xml, 'categories'):
                for category in client.parseDOM(categories, 'category'):
                    if category == 'movie':
                        content.append('movie')
                    elif category == 'serie':
                        content.append('episode')
            if not content:
                raise Exception
        except Exception:
            return []

        return [{
            'content': content,
            'language': ['it'],
        }]

    def search(self, content, language, meta):
        from unidecode import unidecode
        from core.item import Item # kodi addon # pylint: disable=import-error
        from core import logger # kodi addon # pylint: disable=import-error

        logger.log_enable(False)

        if content == 'movie':
            search_terms = meta.get('title')
            search_type = 'movie'
        elif content == 'episode':
            search_terms = meta.get('tvshowtitle')
            search_type = 'serie'
        else:
            raise NotImplementedError

        if not search_terms:
            raise Exception('meta is missing the title/tvshowtitle')

        search_terms = unidecode(search_terms)
        if self._channel_option(self.provider['name'], 'remove_chars'):
            search_terms = search_terms.translate(None, self._channel_option(self.provider['name'], 'remove_chars'))
        year = meta.get('year')
        if year and self._channel_option(self.provider['name'], 'use_year'):
            search_terms += self._channel_option(self.provider['name'], 'use_year') % year
        items = self.module.search(Item(extra=search_type), urllib.quote_plus(search_terms))
        matches = []
        for i in items or []:
            if i.action.lower() == 'homepage':
                continue
            for tag in ['streaming', 'ita', 'serie', 'tv']:
                i.fulltitle = re.sub(r'(?i)(^|[^\w])%s([^\w]|$)'%tag, r'\1\2', i.fulltitle)
            matches.append({
                'url': i.url,
                'title': i.fulltitle.strip(),
                '_action': i.action,
                })

        return matches

    def sources(self, content, language, match):
        from unidecode import unidecode

        items = self._fetch_sources(match['_action'], match['url'], 'movie' if content == 'movie' else 'serie')

        sources = {}
        for i in items:
            if i.action != 'play':
                log.debug('{m}.{f}: %s: play action not specified for source: %s', self.provider['name'], i.__dict__)
                continue

            host, info_tags = self._collect_host_n_tags(i)
            if not info_tags:
                info_tags = [i.title.decode('utf-8'), i.fulltitle.decode('utf-8')]

            if not hasattr(self.module, i.action):
                url = i.url
            else:
                # Channel specific resolver to run first
                try:
                    ritems = getattr(self.module, i.action)(i)
                except Exception:
                    ritems = []
                if not len(ritems):
                    log.debug('{m}.{f}: %s.%s: cannot resolve the url: %s', self.provider['name'], i.action, i.url)
                    continue
                url = ritems[0].url

            log.debug('{m}.{f}: %s: host=%s, url=%s: info_tags=%s, action=%s',
                      self.provider['name'], host, url, info_tags, i.action if hasattr(self.module, i.action) else None)

            source = {
                'url': url,
                'source': host,
                'info': ' '.join(info_tags+[match.get('title').decode('utf-8')]),
            }

            # For TV shows, the season and episode numbers must be extracted, otherwise discard the source
            if content == 'episode':
                try:
                    for info in [source['info'], i.title.decode('utf-8'), i.fulltitle.decode('utf-8')]:
                        match = re.search(r'[^\d]?(\d)x(\d{1,2})[^\d]', unidecode(info))
                        source.update({
                            'season': str(int(match.group(1))),
                            'episode': str(int(match.group(2))),
                            })
                        log.debug('{m}.{f}: %s: host=%s, url=%s: season=%s, episode=%s',
                                  self.provider['name'], host, url, match.group(1), match.group(2))
                        break
                    else:
                        raise Exception
                except Exception:
                    continue

            sources[url] = source

        return sources.values()

    def _fetch_sources(self, action, url, search_type):
        from core import servertools # kodi addon # pylint: disable=import-error
        from core.item import Item # kodi addon # pylint: disable=import-error

        item = Item(action=action, url=url, extra=search_type)
        if hasattr(self.module, item.action):
            # Channel specific function to retrieve the sources
            items = getattr(self.module, item.action)(item)
        else:
            # Generic function to retrieve the sources
            item.action = 'servertools.find_video_items'
            items = servertools.find_video_items(item)

        nitems = []
        for i in items:
            if i.action == 'play':
                nitems.append(i)
            elif hasattr(self.module, i.action):
                try:
                    nis = getattr(self.module, i.action)(i)
                    if nis:
                        nitems.extend(nis)
                except Exception as ex:
                    log.debug('{m}.{f}: %s.%s: %s', self.provider['name'], i.action, repr(ex))

        log.debug('{m}.{f}: %s.%s: %d sources fetched', self.provider['name'], action, len(nitems))

        return nitems

    def _collect_host_n_tags(self, item):
        info_tags = []
        def collect_info_tags(match):
            tag = match.group(1).strip()
            if tag and tag.decode('utf-8') and tag not in self._channel_option(self.provider['name'], 'ignore_info_tags', []):
                info_tags.append(tag.decode('utf-8'))
            return ''

        title = item.title
        title = re.sub(r'\[HD\]', collect_info_tags, title)
        title = re.sub(r'\(\d{4}\)', collect_info_tags, title)
        title = re.sub(r'\[COLOR\s+[^\]]+\]([^\[]*)\[/COLOR\]', collect_info_tags, title)
        title = re.sub(r'\[/?COLOR[^\]]*\]', '', title)

        try:
            host = item.server
            if not host.strip():
                raise Exception
        except Exception:
            try:
                host = re.search(r'\s+-\s+\[([^\]]+)\]', title).group(1)
            except Exception:
                try:
                    host = re.search(r'\[([^\]]+)\]', title).group(1)
                except Exception:
                    host = ''
            host = host.split(' ')[-1].translate(None, '@')

        return host, info_tags
