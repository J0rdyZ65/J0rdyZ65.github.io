# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import re
import ast
import sys
import json

import xbmc
import xbmcgui
import xbmcaddon

try:
    from collections import OrderedDict
except:
    OrderedDict = dict

from . import fs


_ADDON = xbmcaddon.Addon()
info = _ADDON.getAddonInfo
localizedString = _ADDON.getLocalizedString

PATH = xbmc.translatePath(info('path')).decode('utf-8')
RESOURCES_PATH = os.path.join(PATH, 'resources')
PROFILE_PATH = xbmc.translatePath(info('profile')).decode('utf-8')
CACHE_DB_FILENAME = os.path.join(PROFILE_PATH, 'cache.db')

URL_EMPTY_ARG = '__***Empty***___'
URL_NONE_ARG = '__***None***___'


class MonitorSettings(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)
        self.addon = None
        self.callbacks = []
        self.onSettingsChanged()

    def onSettingsChanged(self): # Kodi API # pylint: disable=invalid-name
        self.addon = xbmcaddon.Addon()
        for callback in self.callbacks:
            callback()

    def get_setting(self, setid):
        return self.addon.getSetting(setid)

    def set_setting(self, setid, value):
        self.addon.setSetting(setid, value)

    def add_callback(self, callback):
        self.callbacks.append(callback)


_MONITOR_SETTINGS = MonitorSettings()

def on_setting_change(callback):
    _MONITOR_SETTINGS.add_callback(callback)


setting = _MONITOR_SETTINGS.get_setting
setSetting = _MONITOR_SETTINGS.set_setting

LANGUAGE_ISO_639_1 = xbmc.ISO_639_1
LANGUAGE_ISO_639_2 = xbmc.ISO_639_2
LANGUAGE_ENGLISH_NAME = xbmc.ENGLISH_NAME


def language(settingid='infoLang', langfmt=LANGUAGE_ISO_639_1):
    lang = 'AUTO' if settingid is None else setting(settingid)
    lang = xbmc.getLanguage(xbmc.ISO_639_1) if lang == 'AUTO' else (lang or 'en')
    return xbmc.convertLanguage(lang.lower(), langfmt)


def infosys(nfo):
    if nfo == 'name':
        return xbmc.getInfoLabel('System.FriendlyName')
    else:
        raise Exception('%s: not implemented' % nfo)


def exists(addon):
    return xbmc.getCondVisibility('System.HasAddon(%s)' % addon)


def info2(addon, nfo):
    return xbmcaddon.Addon(addon).getAddonInfo(nfo)


def settings(setidpat):
    if not hasattr(settings, 'settings'):
        with fs.File(settingsFile()) as fil:
            settings.settings = re.compile(r'<setting.*?id="([^"]+)"').findall(fil.read())

    return [s for s in settings.settings if re.match(setidpat, s)]


def settingsFile(addon=None):
    return os.path.join(PROFILE_PATH if not addon else xbmc.translatePath(info2(addon, 'profile')).decode('utf-8'),
                        'settings.xml')


def propname(module='', name='status', addon=info('id')):
    prop_name = addon
    if module:
        prop_name += ('.' if prop_name else '') + module
    if name:
        prop_name += ('.' if prop_name else '') + name
    return prop_name


def prop(module='', value=None, name='status', addon=info('id')):
    prop_name = propname(module, name, addon)
    home_win = xbmcgui.Window(10000)
    if value is None:
        value = home_win.getProperty(prop_name)
        try:
            return ast.literal_eval(value) if value else None
        except Exception:
            return None
    elif value == '':
        home_win.clearProperty(prop_name)
    else:
        home_win.setProperty(prop_name, repr(value))
    return prop_name


def runplugin(action, **kwargs):
    xbmc.executebuiltin(action if action.startswith('RunPlugin') else pluginaction(action, **kwargs))


def pluginaction(action, **kwargs):
    return 'RunPlugin(%s)'%itemaction(action, **kwargs)


def itemaction(action, plugin=None, **kwargs):
    return _action('%s?%s'%(plugin or sys.argv[0] or 'plugin://%s/'%info('id'),
                            action if plugin else 'action=%s'%action), **kwargs)


def scriptaction(action, **kwargs):
    return 'RunScript(%s)'%_action(action, args_sep=',', **kwargs)


def _action(action, args_sep='&', **kwargs):
    return args_sep.join([action] +
                         ['%s=%s' % (k,
                                     URL_EMPTY_ARG if not str(v) else
                                     URL_NONE_ARG if v is None else v) for k, v in kwargs.iteritems()])


def jsonRPC(method, raise_ex=False):
    try:
        return json.loads(unicode(xbmc.executeJSONRPC(method), 'utf-8', errors='ignore'))
    except Exception as ex:
        if raise_ex:
            raise ex
        return None


def advsettings(setid, refresh=False):
    setvalue = None if refresh else prop('advsettings', name=setid)
    if not setvalue:
        setvalue = _load_advsettings(setid)
        prop('advsettings', setvalue, name=setid)
    return setvalue


def _load_advsettings(setid):
    setvalue = OrderedDict()
    for setpath in (PROFILE_PATH, RESOURCES_PATH):
        try:
            with fs.File(os.path.join(setpath, 'settings.py')) as fil:
                for section in fil.read().split('[@'):
                    if section.strip():
                        name, literal = section.split(']', 1)
                        name = name.split(':')
                        if name[0].strip().lower() == setid:
                            literal = ast.literal_eval(literal.strip())
                            if type(literal) == dict:
                                setvalue.update(literal)
        except Exception as ex:
            xbmc.log('[%s] %s/settings.py: %s' % (info('id'), setpath, repr(ex)), xbmc.LOGERROR)

    return setvalue


def advsettings_update(setid, setvalue=None, allow_star_name=False):
    def repr_dict(vdict):
        if vdict is None:
            return ''
        vdict_repr = '{\n'
        for key, val in vdict.iteritems():
            vdict_repr += "    '%s': %s,\n" % (key, repr(val))
        vdict_repr += '}\n'
        return vdict_repr

    return advsettings_update_sections('[@%s] %s' % (setid, repr_dict(setvalue)), allow_star_name=allow_star_name)


def advsettings_update_sections(settings, allow_star_name=False):
    update_settings = {}
    for frag in settings.split('[@'):
        if frag.strip():
            try:
                setid, literal = frag.split(']', 1)
                if ':' not in setid:
                    raise Exception
                if not allow_star_name and setid.endswith(':*'):
                    raise Exception
                if not setid.endswith(':*') and literal.strip() and type(ast.literal_eval(literal.strip())) != dict:
                    raise Exception
                update_settings[setid] = literal
            except Exception:
                pass

    def updated_value(setid):
        for usetid, usetvalue in update_settings.iteritems():
            if setid == usetid or usetid.endswith(':*') and setid.split(':')[0] == usetid.split(':')[0]:
                update_settings[usetid] = '' if usetid.endswith(':*') else None
                return usetvalue
        return None

    if not update_settings:
        return False

    # xbmc.log('DEBUG[%s] addon.advsettings_update_sections: %s' % (info('id'), update_settings), xbmc.LOGNOTICE)

    settings_filename = os.path.join(PROFILE_PATH, 'settings.py')
    with fs.File(settings_filename) as fil:
        old_settings = fil.read()

    new_sections = []
    for section in old_settings.split('[@'):
        if not section.strip():
            new_sections.append(section)
            continue
        setid = section.split(']', 1)[0].strip()
        newvalue = updated_value(setid)
        if newvalue is None:
            new_sections.append(section.strip() + '\n\n')
        elif newvalue.strip():
            new_sections.append('%s] %s' % (setid, newvalue.strip()) + '\n\n')

    for setid, literal in update_settings.iteritems():
        if literal and literal.strip():
            if setid.endswith(':*'):
                setid = setid.split(':')[0]
            new_sections.append('%s] %s' % (setid, literal.strip()) + '\n\n')

    new_settings = '[@'.join(new_sections)
    if old_settings == new_settings:
        return False

    with fs.File(settings_filename, 'w') as fil:
        fil.write(new_settings)

    return True
