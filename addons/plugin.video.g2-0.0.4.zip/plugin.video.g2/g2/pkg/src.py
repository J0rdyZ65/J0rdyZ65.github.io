# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import uu
import abc
import hashlib
import zipfile
import StringIO
import urlparse

from g2.libraries import fs
from g2.libraries import log
from g2.libraries import client


class SrcBase(object):
    __metaclass__ = abc.ABCMeta

    priority = 99

    def __init__(self, descriptor):
        self.descriptor = ({} if descriptor is None else
                           descriptor if not isinstance(descriptor, basestring) else
                           {'site': descriptor})
        self.site = urlparse.urlparse(self.descriptor.get('site', ''))

    @abc.abstractmethod
    def download(self):
        raise NotImplementedError


class SrcGithub(SrcBase):
    priority = 1

    github_contents_url = 'https://api.github.com/repos/{netloc}/{repo}/contents/{path}'

    def __init__(self, *args, **kwargs):
        super(SrcGithub, self).__init__(*args, **kwargs)
        if self.site.scheme != 'github' or len(self.site.path.split('/')) < 2:
            raise NotImplementedError

    def download(self):
        path = self.site.path.split('/')
        github_url = self.github_contents_url.format(netloc=self.site.netloc,
                                                     repo=path[1],
                                                     path='/'.join(path[2:]))
        with client.Session() as ses:
            for progress, path, source in self._download(ses, github_url, ''):
                yield progress, path, source

    def _download(self, ses, github_url, path):
        def github_sha(source):
            try:
                sha1 = hashlib.sha1()
                sha1.update("blob " + str(len(source)) + "\0" + source)
                return sha1.hexdigest()
            except Exception:
                return None

        repo = ses.get(github_url, raise_error=True).json()
        for i, mod in enumerate(repo):
            log.debug('{m}.{f}: %s[%d]: %s', github_url, i, mod)
            module_path = os.path.join(path, mod['name'])
            if mod['type'] == 'dir':
                for module_path, source in self._download(ses, '%s/%s' % (github_url, mod['name']), module_path):
                    yield (i+1, len(repo)), module_path, source
            else:
                source = ses.get(mod['download_url'], raise_error=True).content
                if mod.get('sha') == github_sha(source):
                    yield (i+1, len(repo)), module_path, source
                else:
                    raise Exception('sha doesn\'t match for %s' % module_path)


class SrcPaste(SrcBase):
    priority = 2

    domains = {
        'sprungeus': ('http://sprunge.us/{netloc}',),
        'slexyorg': ('https://slexy.org/view/{netloc}',
                     lambda u: 'https://slexy.org' +
                     client.parseDOM(client.get(u, raise_error=True).content,
                                     'a', attrs={'href': '/raw/.*'}, ret='href')[0],),
    }

    def __init__(self, *args, **kwargs):
        super(SrcPaste, self).__init__(*args, **kwargs)
        if self.site.scheme not in self.domains:
            raise NotImplementedError

    def download(self):
        url = ''
        for step in self.domains[self.site.scheme]:
            if isinstance(step, basestring):
                url = step.format(netloc=self.site.netloc)
            elif callable(step):
                url = step(url)
        yield (1, 1), '', client.get(url, raise_error=True).content


class SrcGitlist(SrcBase):
    priority = 10

    gitlist_base_url = 'http://{netloc}/{repo}/tree/master/{path}'
    gitlist_content_url = 'http://{netloc}{path}'

    def __init__(self, *args, **kwargs):
        super(SrcGitlist, self).__init__(*args, **kwargs)
        if self.site.scheme != 'gitlist' or not self.site.netloc:
            raise NotImplementedError

    def download(self):
        path = self.site.path.split('/')
        gitlist_url = self.gitlist_base_url.format(netloc=self.site.netloc,
                                                   repo=path[1],
                                                   path='/'.join(path[2:]))
        with client.Session() as ses:
            for progress, path, source in self._download(ses, gitlist_url, ''):
                yield progress, path, source

    def _download(self, ses, gitlist_url, path):
        log.debug('{m}.{f}: %s: %s', gitlist_url, path)
        repo = ses.get(gitlist_url, raise_error=True).content
        for item in client.parseDOM(repo, 'tr'):
            if all(i not in item for i in ('icon-folder', 'icon-file')):
                continue
            mod_name = client.parseDOM(item, 'a')[0]
            mod_path = os.path.join(path, mod_name)
            mod_url = self.gitlist_content_url.format(netloc=self.site.netloc, path=client.parseDOM(item, 'a', ret='href')[0])
            log.debug('{m}.{f}: %s: %s', mod_path, mod_url)
            if 'icon-folder' in item:
                for mod_path, source in self._download(ses, mod_url, mod_path):
                    yield (), mod_path, source
            else:
                source = ses.get(mod_url.replace('/blob/', '/raw/')).content
                yield (), mod_path, source


class SrcLocal(SrcBase):
    priority = 11

    def __init__(self, *args, **kwargs):
        super(SrcLocal, self).__init__(*args, **kwargs)
        if self.site.scheme and self.site.scheme != 'file' or self.site.netloc or not self.site.path:
            raise NotImplementedError

    def download(self):
        for progress, path, source in self._download(self.site.path, ''):
            yield progress, path, source

    def _download(self, local_path, path):
        if fs.existsDir(local_path):
            directories, filenames = fs.listDir(local_path)
            num_items = len(directories + filenames)
            for i, module in enumerate(directories + filenames):
                for dummy, relpath, source in self._download(os.path.join(local_path, module), os.path.join(path, module)):
                    yield (i+1, num_items), relpath, source
        elif fs.exists(local_path):
            with open(local_path) as fil:
                source = fil.read()
            yield (), path, source
        else:
            open(local_path)


class SrcInline(SrcBase):
    def __init__(self, *args, **kwargs):
        super(SrcInline, self).__init__(*args, **kwargs)
        if not self.descriptor.get('kind'):
            raise NotImplementedError

    def download(self):
        source = ''.join(['%s = %s\n' % (k, repr(v)) for k, v in self.descriptor.iteritems()])
        yield (), '__init__.py', source


def create(descriptor):
    for scls in sorted(SrcBase.__subclasses__(), key=lambda sc: sc.priority): # pylint: disable=no-member
        try:
            return scls(descriptor)
        except NotImplementedError:
            pass
        except Exception as ex:
            log.notice('{m}: %s: %s', scls.__name__, repr(ex))

    return None


def decode(spath, source):
    parent = os.path.dirname(spath)
    ext = '' if not spath else os.path.splitext(spath)[1]
    if ext == '.py':
        yield spath, source

    elif ext == '.zip':
        zipf = zipfile.ZipFile(StringIO.StringIO(source))
        if zipf.testzip():
            raise Exception('corrupted zip file')
        for name in zipf.namelist():
            source = zipf.read(name)
            log.debug('{m}.{f}: %s[zip]: unzipped %s[%d]', spath, name, len(source))
            for relpath, nsource in decode(name, source):
                yield os.path.join(parent, relpath), nsource

    elif ext == '.uu' or source.startswith('begin '):
        uuencoded = StringIO.StringIO(source)
        name = uuencoded.readline().strip().split(' ')[2]
        uuencoded.seek(0)
        uudecoded = StringIO.StringIO()
        uu.decode(uuencoded, uudecoded)
        uudecoded.seek(0)
        source = uudecoded.read()
        log.debug('{m}.{f}: %s[uu]: decoded %s[%d]', spath, name, len(source))
        for relpath, nsource in decode(name, source):
            yield os.path.join(parent, relpath), nsource

    else:
        yield spath, source
