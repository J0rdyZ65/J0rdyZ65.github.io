G2
======================

About
-----
G2 is the Gio's own version of an once famous addon

Features at glance
------------------
- Sources dialog
  - Show the stream sources as they are found by the providers ordered by user preference
  - Check the sources validity and stream resolution (MP4, FLV and M3U formats)
  - Automatic video bookmarking for playing resume
- Movie/TVshow listing and metadata fetching from tmdb, tvdb and imdb
  - Search dialog with history
  - Keep watching directory (list of video bookmarked)
- Integration with your trakt account
  - User lists, watched status, ratings, etc.
- Integration with your pushbullet account
  - Parental control
    - Notification of start/stop video playing including the title, mpaa rating and imdb url
    - Forced stop of the current playing title from any connected device (in case you don't like it)
  - Push of imdb, tvdb movie/episode pages to trigger a source search
- Script.extendedinfo integration
  - Movie/Person information
  - Trailers
- Kodi integration
  - bookmarks
  - local content searching and playing
- External players integration
  - Net\*\*ix, Rai\*\*ay
- Built to be extensible via addon packages

Attributions
---------------------
- Inspired by the original lambda work
- Cloudflare bypass by pelisalacarta and cfscrape | https://github.com/Anorov/cloudflare-scrape
- Fuzzy matching by Adam Cohen | https://github.com/seatgeek/fuzzywuzzy
- MP4 decoding by charsyam@github | https://github.com/charsyam/mp4parser
- Websocket by Sylvain Hellegouarch | https://github.com/Lawouach/WebSocket-for-Python
- Pushbullet by Azelphur | https://github.com/Azelphur/pyPushBullet
- Embossed art by jokster | http://tvaddons.co
- Italian translation by Frep | https://twitter.com/frep90

License
-------
This software is released under the [GPL 3.0 license] [1]

[1]: http://www.gnu.org/licenses/gpl-3.0.html
